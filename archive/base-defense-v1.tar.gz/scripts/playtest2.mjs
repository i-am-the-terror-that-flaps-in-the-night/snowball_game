// Deep playtest: node scripts/playtest2.mjs <phase> [outDir]
// Uses window.__game.tick(dt) to simulate faster than real time (headless sessions here die after ~30s).
// phases: ui | balance | flows
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';

const phase = process.argv[2] || 'balance';
const out = process.argv[3] || '/tmp/snowplow-shots';
mkdirSync(out, { recursive: true });
const port = 5200 + Math.floor(Math.random() * 500);
const server = await createServer({ server: { port, strictPort: true }, logLevel: 'error' });
await server.listen();
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
const errors = [];
page.on('console', (m) => { const t = m.text(); if ((m.type() === 'error' || m.type() === 'warning') && !/GL Driver|GPU stall/.test(t)) errors.push(`[${m.type()}] ${t}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}\n${e.stack}`));
const shot = async (n) => { await ev(() => { const g = window.__game; g.renderer.render(g.ctx.scene, g.ctx.camera); }); await page.screenshot({ path: `${out}/${n}.png` }); };
const ev = (f, a) => page.evaluate(f, a);
const wait = (ms) => page.waitForTimeout(ms);
const log = (...a) => console.log(...a);

const setup = () => ev(() => {
  const g = window.__game, c = g.ctx, inp = c.input;
  g.renderer.setAnimationLoop(null);
  const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
  let wp = 0; const wps = [[-25, 20], [-25, -30], [-10, -30], [-10, 20], [10, 20], [10, -30], [25, -30], [25, 20]];
  window.__bs = { launches: 0 };
  window.__botStep = () => {
    if (g.state !== 'playing' && g.state !== 'countdown') { inp.down.clear(); return; }
    const p = c.plow.position, r = c.plow.heldBallRadius;
    const es = c.enemies.query(0, 0, 500).filter((e) => e.alive);
    let target, launch = false;
    if (r > 0.7 && es.length) {
      es.sort((a, b) => a.position.distanceTo(c.base.position) - b.position.distanceTo(c.base.position));
      const e = es[0]; target = [e.position.x, e.position.z];
      const d = Math.hypot(e.position.x - p.x, e.position.z - p.z);
      if (Math.abs(wrap(Math.atan2(target[0] - p.x, target[1] - p.z) - c.plow.heading)) < 0.12 && d < 26) launch = true;
    } else {
      const w = wps[wp]; if (Math.hypot(w[0] - p.x, w[1] - p.z) < 4) wp = (wp + 1) % wps.length; target = wps[wp];
    }
    const diff = wrap(Math.atan2(target[0] - p.x, target[1] - p.z) - c.plow.heading);
    inp.down.clear(); inp.down.add('KeyW');
    if (diff > 0.05) inp.down.add('KeyA'); else if (diff < -0.05) inp.down.add('KeyD');
    if (launch) { inp.pressed.add('Space'); window.__bs.launches++; }
  };
  window.__sim = (secs, bot = true, until = null) => {
    const n = Math.round(secs * 30);
    for (let i = 0; i < n; i++) { if (bot) window.__botStep(); g.tick(1 / 30); if (until && until.includes(g.state)) break; }
    return window.__snap();
  };
  window.__snap = () => ({ state: g.state, wave: g.waveIndex + 1, base: Math.round(c.base.hp), plowHp: Math.round(c.plow.hp), ball: +c.plow.heldBallRadius.toFixed(2), alive: c.enemies.aliveCount(), rem: c.waves.remaining, coins: c.progression.coins, kills: g.run.kills, launches: window.__bs.launches, t: +c.time.toFixed(1) });
});
const clickBtn = (re) => ev((re) => { const b = [...document.querySelectorAll('button')].find((b) => new RegExp(re, 'i').test(b.textContent) && b.offsetParent); if (!b) return false; b.click(); return true; }, re);

try {
  await page.goto(`http://localhost:${port}/${phase === 'flows' ? '?debug' : ''}`, { waitUntil: 'load' });
  if (phase !== 'flows') { await ev(() => localStorage.clear()); await page.reload({ waitUntil: 'load' }); }
  await wait(1200);
  await setup();

  if (phase === 'ui') {
    await ev(() => window.__sim(1, false)); await shot('10-menu');
    await clickBtn('PLAY'); await wait(400); await shot('11-zones');
    await ev(() => window.__game.ctx.ui.showGarage()); await wait(400); await shot('12-garage');
    await ev(() => window.__game.ctx.ui.showMainMenu()); await clickBtn('HOW TO PLAY'); await wait(400); await shot('13-howto');
    await ev(() => window.__game.startRun(0));
    // ball growth probe, straight plowing, no bot
    const grow = await ev(() => { const r = []; const inp = window.__game.ctx.input; for (let s = 0; s < 6; s++) { for (let i = 0; i < 30; i++) { inp.down.add('KeyW'); window.__game.tick(1 / 30); } r.push(+window.__game.ctx.plow.heldBallRadius.toFixed(2)); } inp.down.clear(); return r; });
    log('ball radius per sec of straight plowing:', grow.join(', '));
    await shot('14-plowing');
  }

  if (phase === 'balance') {
    await ev(() => window.__game.startRun(0));
    let shopShot = false;
    for (let s = 0; s < 400; s += 5) {
      const st = await ev(() => window.__sim(5, true, ['shop', 'gameover', 'victory']));
      log(JSON.stringify(st));
      if (s === 25) await shot('20-bot-play');
      if (st.state === 'shop') {
        if (!shopShot) { await shot('22-shop'); shopShot = true; }
        if (st.wave >= 3) break;
        log('continue ->', await clickBtn('START WAVE'));
      }
      if (st.state === 'gameover') { await shot('23-gameover-bot'); break; }
    }
  }

  if (phase === 'flows') {
    // upgrades change stats
    const before = await ev(() => ({ ...window.__game.ctx.stats }));
    await ev(() => { const g = window.__game, p = g.ctx.progression; ['engine', 'blade', 'compactor', 'hopper', 'cannon', 'packedIce', 'armor', 'cabin'].forEach((id) => p.buy(id)); });
    await ev(() => window.__game.startRun(0));
    const after = await ev(() => ({ ...window.__game.ctx.stats }));
    log('stats changed:', Object.keys(after).filter((k) => JSON.stringify(after[k]) !== JSON.stringify(before[k])).map((k) => `${k}:${before[k]}->${after[k]}`).join(' '));
    log('wave1 start:', JSON.stringify(await ev(() => window.__sim(5, false))));
    // launch a ball into a fresh snowman
    const hit = await ev(() => { const g = window.__game, c = g.ctx; for (let i = 0; i < 120; i++) { c.input.down.add('KeyW'); g.tick(1 / 30); } c.input.down.clear(); for (const e of c.enemies.query(0, 0, 500)) c.enemies.damage(e, 1e6, { source: 'other' }); const p = c.plow.position; const fx = Math.sin(c.plow.heading), fz = Math.cos(c.plow.heading); const e = c.enemies.spawn('snowman', p.x + fx * 10, p.z + fz * 10); const r = c.plow.heldBallRadius; c.input.pressed.add('Space'); g.tick(1 / 30); const active = c.snowballs.activeCount; for (let i = 0; i < 45; i++) g.tick(1 / 30); return { r, active, enemyAlive: e.alive, hp: e.hp }; });
    log('launch probe:', JSON.stringify(hit));
    // enemies walk to cabin and damage it
    const walk = await ev(() => { const g = window.__game, c = g.ctx; const hp0 = c.base.hp; c.enemies.spawn('snowman', 0, -48); for (let i = 0; i < 30 * 50; i++) g.tick(1 / 30); return { hp0, hp1: c.base.hp, state: g.state }; });
    log('enemy reaches cabin:', JSON.stringify(walk));
    // clear wave -> shop
    const cl = await ev(() => { const g = window.__game, c = g.ctx; for (let k = 0; k < 60 && g.state === 'playing'; k++) { for (const e of c.enemies.query(0, 0, 500)) c.enemies.damage(e, 1e6, { source: 'other' }); for (let i = 0; i < 30; i++) g.tick(1 / 30); } return window.__snap(); });
    log('after clearing:', JSON.stringify(cl));
    await shot('40-shop');
    log('start wave click:', await clickBtn('START WAVE'), JSON.stringify(await ev(() => window.__sim(0.2, false))));
    await ev(() => window.__sim(3, false));
    await page.keyboard.press('Escape'); await wait(300); log('after Esc:', await ev(() => window.__game.state)); await shot('41-pause');
    await page.keyboard.press('Escape'); await wait(200); log('after Esc2:', await ev(() => window.__game.state));
    await ev(() => { window.__sim(6, false, ['playing']); window.__game.ctx.base.damage(99999); window.__sim(0.5, false); }); await wait(400); log('after base dmg:', await ev(() => window.__game.state)); await shot('42-gameover');
    // victory
    await ev(() => window.__game.startRun(0));
    const v = await ev(() => { const g = window.__game, c = g.ctx; for (let k = 0; k < 400 && g.state !== 'victory'; k++) { if (g.state === 'shop') { const b = [...document.querySelectorAll('button')].find((b) => /start wave/i.test(b.textContent) && b.offsetParent); b && b.click(); } for (const e of c.enemies.query(0, 0, 500)) c.enemies.damage(e, 1e6, { source: 'other' }); for (let i = 0; i < 30; i++) g.tick(1 / 30); } return { ...window.__snap(), z1: c.progression.isZoneUnlocked(1) }; });
    log('victory run:', JSON.stringify(v));
    await wait(400); await shot('43-victory');
  }
} catch (e) {
  errors.push(`[playtest] ${e.stack || e}`);
}
console.log(errors.length ? `ERRORS (${errors.length}):\n` + errors.slice(0, 30).join('\n') : 'NO CONSOLE ERRORS');
await browser.close().catch(() => {});
await server.close();
process.exit(0);
