// Headless playtest: node scripts/smoke.mjs [outDir]
// Boots the Vite dev server, opens the game in headless Chrome, drives the plow, and reports console errors.
import { createServer } from 'vite';
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';

const out = process.argv[2] || '/tmp/snowplow-shots';
mkdirSync(out, { recursive: true });
const port = 5200 + Math.floor(Math.random() * 500);
const server = await createServer({ server: { port, strictPort: true }, logLevel: 'error' });
await server.listen();
const browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
const errors = [];
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(`[${m.type()}] ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}\n${e.stack}`));
const shot = (n) => page.screenshot({ path: `${out}/${n}.png` });
try {
  await page.goto(`http://localhost:${port}/?debug`, { waitUntil: 'load' });
  await page.waitForTimeout(2500);
  await shot('01-menu');
  await page.evaluate(() => window.__game.startRun(0));
  await page.waitForTimeout(500);
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(2500);
  await shot('02-plowing');
  await page.keyboard.down('KeyA');
  await page.waitForTimeout(800);
  await page.keyboard.up('KeyA');
  await page.waitForTimeout(1500);
  await page.keyboard.up('KeyW');
  const state1 = await page.evaluate(() => { const c = window.__game.ctx; return { ball: c.plow.heldBallRadius, pos: c.plow.position.toArray(), snow: c.snow.totalSnowFraction(), state: window.__game.state }; });
  await page.keyboard.press('Space');
  await page.waitForTimeout(400);
  await shot('03-launch');
  await page.waitForTimeout(4000);
  await shot('04-wave');
  const state2 = await page.evaluate(() => { const c = window.__game.ctx; return { enemies: c.enemies.aliveCount(), remaining: c.waves.remaining, baseHp: c.base.hp, state: window.__game.state, balls: c.snowballs.activeCount }; });
  console.log('STATE after plowing:', JSON.stringify(state1));
  console.log('STATE after wave start:', JSON.stringify(state2));
} catch (e) {
  errors.push(`[smoke] ${e.stack || e}`);
}
console.log(errors.length ? `ERRORS (${errors.length}):\n` + errors.slice(0, 30).join('\n') : 'NO CONSOLE ERRORS');
console.log(`screenshots in ${out}`);
await browser.close();
await server.close();
process.exit(0);
