import * as THREE from 'three';
import type { GameContext, SnowFieldAPI, ZoneDef } from '../core/types';
import { SNOW_FIELD_SIZE } from '../core/types';

const N = 208; // segments per side
const V = N + 1; // vertices per side
const CELL = SNOW_FIELD_SIZE / N; // 0.5 m
const HALF = SNOW_FIELD_SIZE / 2;
const CELL_AREA = CELL * CELL;
const INV_CELL = 1 / CELL;
const EDGE = 2; // edits never touch the outermost vertices (keeps the field rim flush with the outer ground)
const LUT_SIZE = 256;
const LUT_MAX_DEPTH = 0.4;
const REGEN_INTERVAL = 0.25;

const BARE_COLORS: Record<ZoneDef['theme'], number> = {
  meadow: 0x6f7a3f,
  pines: 0x4a3a2b,
  lake: 0x7f9db3,
  blizzard: 0x7f8b99,
  peak: 0x5a4e68,
};

function hash2(x: number, y: number, seed: number): number {
  let h = (x * 374761393 + y * 668265263 + seed * 1442695041) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}

function valueNoise(x: number, y: number, seed: number): number {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

const smooth = (e0: number, e1: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
};

export class SnowField implements SnowFieldAPI {
  readonly size = SNOW_FIELD_SIZE;
  private ctx: GameContext;
  private depth = new Float32Array(V * V);
  private initial = new Float32Array(V * V);
  private sparkle = new Float32Array(V * V);
  private total = 0;
  private initialTotal = 1;
  private zoneDepth = 0.5;
  private addCap = 1.25;

  private geometry: THREE.BufferGeometry;
  private posAttr: THREE.BufferAttribute;
  private normAttr: THREE.BufferAttribute;
  private colAttr: THREE.BufferAttribute;
  private attrs: THREE.BufferAttribute[];
  private mesh: THREE.Mesh;
  private material: THREE.MeshStandardMaterial;
  private outer: THREE.Mesh;
  private outerMat: THREE.MeshStandardMaterial;
  private lut = new Float32Array(LUT_SIZE * 3);

  // dirty rect (vertex indices, inclusive)
  private dMinX = V;
  private dMaxX = -1;
  private dMinZ = V;
  private dMaxZ = -1;
  private regenTimer = 0;

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    const count = V * V;
    const pos = new Float32Array(count * 3);
    const nor = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    for (let iz = 0; iz < V; iz++) {
      for (let ix = 0; ix < V; ix++) {
        const i = iz * V + ix;
        pos[i * 3] = -HALF + ix * CELL;
        pos[i * 3 + 2] = -HALF + iz * CELL;
        nor[i * 3 + 1] = 1;
        this.sparkle[i] = 0.965 + hash2(ix, iz, 99) * 0.05;
      }
    }
    const idx = new Uint32Array(N * N * 6);
    let k = 0;
    for (let iz = 0; iz < N; iz++) {
      for (let ix = 0; ix < N; ix++) {
        const a = iz * V + ix;
        const b = a + 1;
        const c = a + V;
        const d = c + 1;
        // alternate diagonal for less directional artifacts
        if ((ix + iz) & 1) {
          idx[k++] = a; idx[k++] = c; idx[k++] = b;
          idx[k++] = b; idx[k++] = c; idx[k++] = d;
        } else {
          idx[k++] = a; idx[k++] = c; idx[k++] = d;
          idx[k++] = a; idx[k++] = d; idx[k++] = b;
        }
      }
    }
    const geo = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(pos, 3);
    this.normAttr = new THREE.BufferAttribute(nor, 3);
    this.colAttr = new THREE.BufferAttribute(col, 3);
    this.posAttr.setUsage(THREE.DynamicDrawUsage);
    this.normAttr.setUsage(THREE.DynamicDrawUsage);
    this.colAttr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', this.posAttr);
    geo.setAttribute('normal', this.normAttr);
    geo.setAttribute('color', this.colAttr);
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), HALF * Math.SQRT2 + 2);
    geo.boundingBox = new THREE.Box3(new THREE.Vector3(-HALF, -1, -HALF), new THREE.Vector3(HALF, 3, HALF));
    this.geometry = geo;
    this.attrs = [this.posAttr, this.normAttr, this.colAttr];

    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.82, metalness: 0.0 });
    // Subtle glitter: view-dependent sparkle on snowy (bright) surfaces.
    this.material.onBeforeCompile = (shader) => {
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vSnowWorld;')
        .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvSnowWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;');
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vSnowWorld;')
        .replace(
          '#include <dithering_fragment>',
          `#include <dithering_fragment>
          {
            vec3 cellP = floor(vSnowWorld * 9.0);
            float rnd = fract(sin(dot(cellP, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
            vec3 vdir = normalize(cameraPosition - vSnowWorld);
            float tw = fract(rnd * 17.0 + dot(vdir, vec3(3.1, 1.7, 2.3)) * 2.0);
            float s = step(0.985, rnd) * smoothstep(0.75, 1.0, tw) * smoothstep(0.75, 0.95, vColor.r);
            gl_FragColor.rgb += vec3(s * 0.6);
          }`,
        );
    };
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.receiveShadow = true;
    this.mesh.castShadow = false;
    this.mesh.name = 'SnowField';
    ctx.scene.add(this.mesh);

    // Outer ground: huge snowy plane with a square hole where the field is.
    const shape = new THREE.Shape();
    const O = 700;
    shape.moveTo(-O, -O);
    shape.lineTo(O, -O);
    shape.lineTo(O, O);
    shape.lineTo(-O, O);
    shape.lineTo(-O, -O);
    const hole = new THREE.Path();
    const h = HALF - CELL * 0.6;
    hole.moveTo(-h, -h);
    hole.lineTo(-h, h);
    hole.lineTo(h, h);
    hole.lineTo(h, -h);
    hole.lineTo(-h, -h);
    shape.holes.push(hole);
    const og = new THREE.ShapeGeometry(shape);
    og.rotateX(-Math.PI / 2);
    this.outerMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });
    this.outer = new THREE.Mesh(og, this.outerMat);
    this.outer.receiveShadow = true;
    this.outer.name = 'OuterGround';
    ctx.scene.add(this.outer);

    this.reset(ctx.zone);
  }

  /* ------------------------------------------------------------------ setup */

  reset(zone: ZoneDef): void {
    const base = zone.snowDepth;
    this.zoneDepth = base;
    this.addCap = Math.max(base * 2.4, base + 0.6);
    const seed = zone.index * 7919 + 13;
    const d = this.depth;
    const init = this.initial;
    let total = 0;
    for (let iz = 0; iz < V; iz++) {
      const z = -HALF + iz * CELL;
      for (let ix = 0; ix < V; ix++) {
        const x = -HALF + ix * CELL;
        // low-frequency rolling variation
        const n1 = valueNoise(x * 0.045, z * 0.045, seed) * 2 - 1;
        const n2 = valueNoise(x * 0.11 + 31, z * 0.11 - 17, seed + 1) * 2 - 1;
        let m = 1 + n1 * 0.17 + n2 * 0.08;
        // small wind drifts: elongated ridges
        const dr = valueNoise(x * 0.06 + z * 0.02, z * 0.22, seed + 2);
        m += smooth(0.62, 0.9, dr) * 0.22;
        // flush with the outer ground near the field rim
        const edgeDist = Math.min(HALF - Math.abs(x), HALF - Math.abs(z));
        const e = smooth(0.5, 5, edgeDist);
        m = 1 + (m - 1) * e;
        const v = base * m;
        const i = iz * V + ix;
        d[i] = v;
        init[i] = v;
        total += v;
      }
    }
    this.total = total * CELL_AREA;
    this.initialTotal = Math.max(1e-6, this.total);
    this.regenTimer = 0;

    // Color LUT: bare ground -> packed snow -> fresh snow
    const snow = new THREE.Color(zone.snowTint);
    const bare = new THREE.Color(BARE_COLORS[zone.theme] ?? 0x6f7a3f);
    const packed = new THREE.Color(zone.snowTint).multiply(new THREE.Color(0xc4d2e6));
    const tmp = new THREE.Color();
    for (let j = 0; j < LUT_SIZE; j++) {
      const dep = (j / (LUT_SIZE - 1)) * LUT_MAX_DEPTH;
      const a = smooth(0.0, 0.06, dep);
      const b = smooth(0.05, 0.3, dep);
      tmp.copy(bare).lerp(packed, a).lerp(snow, b);
      this.lut[j * 3] = tmp.r;
      this.lut[j * 3 + 1] = tmp.g;
      this.lut[j * 3 + 2] = tmp.b;
    }
    this.outerMat.color.copy(snow).multiplyScalar(0.97);
    this.outer.position.y = base;

    this.markDirty(0, V - 1, 0, V - 1);
    this.flush();
  }

  /* ------------------------------------------------------------------ queries */

  getDepth(x: number, z: number): number {
    const fx = (x + HALF) * INV_CELL;
    const fz = (z + HALF) * INV_CELL;
    if (fx < 0 || fz < 0 || fx > N || fz > N) return 0;
    let ix = Math.floor(fx);
    let iz = Math.floor(fz);
    if (ix >= N) ix = N - 1;
    if (iz >= N) iz = N - 1;
    const tx = fx - ix;
    const tz = fz - iz;
    const d = this.depth;
    const i = iz * V + ix;
    const a = d[i];
    const b = d[i + 1];
    const c = d[i + V];
    const e = d[i + V + 1];
    return (a + (b - a) * tx) * (1 - tz) + (c + (e - c) * tx) * tz;
  }

  totalSnowFraction(): number {
    return this.total / this.initialTotal;
  }

  /* ------------------------------------------------------------------ edits */

  private markDirty(x0: number, x1: number, z0: number, z1: number): void {
    if (x0 < this.dMinX) this.dMinX = x0;
    if (x1 > this.dMaxX) this.dMaxX = x1;
    if (z0 < this.dMinZ) this.dMinZ = z0;
    if (z1 > this.dMaxZ) this.dMaxZ = z1;
  }

  plowLine(x1: number, z1: number, x2: number, z2: number, thickness: number, fraction: number): number {
    if (fraction <= 0) return 0;
    const r = Math.max(thickness * 0.5, CELL * 0.5);
    const r2 = r * r;
    const ix0 = Math.max(EDGE, Math.floor((Math.min(x1, x2) - r + HALF) * INV_CELL));
    const ix1 = Math.min(V - 1 - EDGE, Math.ceil((Math.max(x1, x2) + r + HALF) * INV_CELL));
    const iz0 = Math.max(EDGE, Math.floor((Math.min(z1, z2) - r + HALF) * INV_CELL));
    const iz1 = Math.min(V - 1 - EDGE, Math.ceil((Math.max(z1, z2) + r + HALF) * INV_CELL));
    if (ix0 > ix1 || iz0 > iz1) return 0;
    const f = Math.min(1, fraction);
    const sx = x2 - x1;
    const sz = z2 - z1;
    const len2 = sx * sx + sz * sz;
    const invLen2 = len2 > 1e-9 ? 1 / len2 : 0;
    const d = this.depth;
    let removed = 0;
    for (let iz = iz0; iz <= iz1; iz++) {
      const pz = -HALF + iz * CELL - z1;
      const row = iz * V;
      for (let ix = ix0; ix <= ix1; ix++) {
        const px = -HALF + ix * CELL - x1;
        let t = (px * sx + pz * sz) * invLen2;
        if (t < 0) t = 0;
        else if (t > 1) t = 1;
        const ex = px - sx * t;
        const ez = pz - sz * t;
        if (ex * ex + ez * ez <= r2) {
          const i = row + ix;
          const v = d[i];
          if (v > 0) {
            const rem = v * f;
            d[i] = v - rem;
            removed += rem;
          }
        }
      }
    }
    if (removed > 0) {
      removed *= CELL_AREA;
      this.total -= removed;
      this.markDirty(ix0, ix1, iz0, iz1);
    }
    return removed;
  }

  collectDisc(x: number, z: number, radius: number, fraction: number): number {
    if (fraction <= 0) return 0;
    const r = Math.max(radius, CELL * 0.5);
    const r2 = r * r;
    const ix0 = Math.max(EDGE, Math.floor((x - r + HALF) * INV_CELL));
    const ix1 = Math.min(V - 1 - EDGE, Math.ceil((x + r + HALF) * INV_CELL));
    const iz0 = Math.max(EDGE, Math.floor((z - r + HALF) * INV_CELL));
    const iz1 = Math.min(V - 1 - EDGE, Math.ceil((z + r + HALF) * INV_CELL));
    if (ix0 > ix1 || iz0 > iz1) return 0;
    const f = Math.min(1, fraction);
    const invR = 1 / r;
    const d = this.depth;
    let removed = 0;
    for (let iz = iz0; iz <= iz1; iz++) {
      const dz = -HALF + iz * CELL - z;
      const row = iz * V;
      for (let ix = ix0; ix <= ix1; ix++) {
        const dx = -HALF + ix * CELL - x;
        const q = dx * dx + dz * dz;
        if (q <= r2) {
          const i = row + ix;
          const v = d[i];
          if (v > 0) {
            // soft rim
            const w = Math.min(1, (1 - Math.sqrt(q) * invR) * 3);
            const rem = v * f * w;
            d[i] = v - rem;
            removed += rem;
          }
        }
      }
    }
    if (removed > 0) {
      removed *= CELL_AREA;
      this.total -= removed;
      this.markDirty(ix0, ix1, iz0, iz1);
    }
    return removed;
  }

  addSnow(x: number, z: number, radius: number, volume: number): void {
    if (volume <= 0) return;
    const r = Math.max(radius, CELL * 1.2);
    const r2 = r * r;
    const ix0 = Math.max(EDGE, Math.floor((x - r + HALF) * INV_CELL));
    const ix1 = Math.min(V - 1 - EDGE, Math.ceil((x + r + HALF) * INV_CELL));
    const iz0 = Math.max(EDGE, Math.floor((z - r + HALF) * INV_CELL));
    const iz1 = Math.min(V - 1 - EDGE, Math.ceil((z + r + HALF) * INV_CELL));
    if (ix0 > ix1 || iz0 > iz1) return;
    const invR2 = 1 / r2;
    // pass 1: total weight
    let wsum = 0;
    for (let iz = iz0; iz <= iz1; iz++) {
      const dz = -HALF + iz * CELL - z;
      for (let ix = ix0; ix <= ix1; ix++) {
        const dx = -HALF + ix * CELL - x;
        const q = (dx * dx + dz * dz) * invR2;
        if (q < 1) {
          const w = 1 - q;
          wsum += w * w;
        }
      }
    }
    if (wsum <= 0) return;
    const k = volume / (wsum * CELL_AREA);
    const cap = this.addCap;
    const d = this.depth;
    let added = 0;
    for (let iz = iz0; iz <= iz1; iz++) {
      const dz = -HALF + iz * CELL - z;
      const row = iz * V;
      for (let ix = ix0; ix <= ix1; ix++) {
        const dx = -HALF + ix * CELL - x;
        const q = (dx * dx + dz * dz) * invR2;
        if (q < 1) {
          const w = 1 - q;
          const i = row + ix;
          const v = d[i];
          if (v < cap) {
            let nv = v + k * w * w;
            if (nv > cap) nv = cap;
            d[i] = nv;
            added += nv - v;
          }
        }
      }
    }
    if (added > 0) {
      this.total += added * CELL_AREA;
      this.markDirty(ix0, ix1, iz0, iz1);
    }
  }

  melt(x: number, z: number, radius: number, amount: number): void {
    if (amount <= 0) return;
    const r = Math.max(radius, CELL * 0.5);
    const r2 = r * r;
    const ix0 = Math.max(EDGE, Math.floor((x - r + HALF) * INV_CELL));
    const ix1 = Math.min(V - 1 - EDGE, Math.ceil((x + r + HALF) * INV_CELL));
    const iz0 = Math.max(EDGE, Math.floor((z - r + HALF) * INV_CELL));
    const iz1 = Math.min(V - 1 - EDGE, Math.ceil((z + r + HALF) * INV_CELL));
    if (ix0 > ix1 || iz0 > iz1) return;
    const invR = 1 / r;
    const d = this.depth;
    let removed = 0;
    for (let iz = iz0; iz <= iz1; iz++) {
      const dz = -HALF + iz * CELL - z;
      const row = iz * V;
      for (let ix = ix0; ix <= ix1; ix++) {
        const dx = -HALF + ix * CELL - x;
        const q = dx * dx + dz * dz;
        if (q <= r2) {
          const i = row + ix;
          const v = d[i];
          if (v > 0) {
            const m = amount * (1 - Math.sqrt(q) * invR);
            const nv = v > m ? v - m : 0;
            removed += v - nv;
            d[i] = nv;
          }
        }
      }
    }
    if (removed > 0) {
      this.total -= removed * CELL_AREA;
      this.markDirty(ix0, ix1, iz0, iz1);
    }
  }

  /* ------------------------------------------------------------------ update */

  update(dt: number): void {
    this.regenTimer += dt;
    if (this.regenTimer >= REGEN_INTERVAL) {
      const rate = this.ctx.stats.snowRegen * this.ctx.zone.snowRegenMult;
      const step = rate * this.regenTimer;
      this.regenTimer = 0;
      if (step > 0) this.regen(step);
    }
    this.flush();
  }

  private regen(step: number): void {
    const d = this.depth;
    const init = this.initial;
    let changed = false;
    let total = 0;
    for (let iz = EDGE; iz < V - EDGE; iz++) {
      const row = iz * V;
      for (let ix = EDGE; ix < V - EDGE; ix++) {
        const i = row + ix;
        const v = d[i];
        const cap = init[i];
        if (v < cap) {
          const nv = v + step;
          d[i] = nv > cap ? cap : nv;
          changed = true;
        }
      }
    }
    // recompute exact running total (avoids float drift)
    for (let i = 0; i < d.length; i++) total += d[i];
    this.total = total * CELL_AREA;
    if (changed) this.markDirty(EDGE, V - 1 - EDGE, EDGE, V - 1 - EDGE);
  }

  /** Push the dirty rect (heights, normals, colors) to the GPU. */
  private flush(): void {
    if (this.dMaxX < 0) return;
    const x0 = Math.max(0, this.dMinX - 1);
    const x1 = Math.min(V - 1, this.dMaxX + 1);
    const z0 = Math.max(0, this.dMinZ - 1);
    const z1 = Math.min(V - 1, this.dMaxZ + 1);
    this.dMinX = V;
    this.dMaxX = -1;
    this.dMinZ = V;
    this.dMaxZ = -1;

    const d = this.depth;
    const pos = this.posAttr.array as Float32Array;
    const nor = this.normAttr.array as Float32Array;
    const col = this.colAttr.array as Float32Array;
    const lut = this.lut;
    const sp = this.sparkle;
    const lutScale = (LUT_SIZE - 1) / LUT_MAX_DEPTH;
    const inv2c = 1 / (2 * CELL);
    for (let iz = z0; iz <= z1; iz++) {
      const row = iz * V;
      const up = iz > 0 ? row - V : row;
      const dn = iz < V - 1 ? row + V : row;
      for (let ix = x0; ix <= x1; ix++) {
        const i = row + ix;
        const h = d[i];
        const i3 = i * 3;
        pos[i3 + 1] = h;
        const hl = d[ix > 0 ? i - 1 : i];
        const hr = d[ix < V - 1 ? i + 1 : i];
        const hu = d[up + ix];
        const hd = d[dn + ix];
        const nx = (hl - hr) * inv2c;
        const nz = (hu - hd) * inv2c;
        const il = 1 / Math.sqrt(nx * nx + 1 + nz * nz);
        nor[i3] = nx * il;
        nor[i3 + 1] = il;
        nor[i3 + 2] = nz * il;
        let li = (h * lutScale) | 0;
        if (li > LUT_SIZE - 1) li = LUT_SIZE - 1;
        else if (li < 0) li = 0;
        // slight shading: concave (lower than neighbours) gets a touch of blue shadow
        const curv = (hl + hr + hu + hd) * 0.25 - h;
        const s = sp[i] - (curv > 0 ? Math.min(0.12, curv * 1.5) : 0);
        const l3 = li * 3;
        col[i3] = lut[l3] * s;
        col[i3 + 1] = lut[l3 + 1] * s;
        col[i3 + 2] = lut[l3 + 2] * (s + (curv > 0 ? Math.min(0.06, curv * 0.8) : 0));
      }
    }
    const start = z0 * V * 3;
    const count = (z1 - z0 + 1) * V * 3;
    for (const a of this.attrs) {
      // ranges are cleared by the renderer after upload; overlapping ranges are harmless
      a.addUpdateRange(start, count);
      a.needsUpdate = true;
    }
  }
}
