import * as THREE from 'three';
import type { BaseAPI, GameContext } from '../core/types';
import { BASE_POSITION, BASE_RADIUS } from '../core/types';

interface Puff {
  sprite: THREE.Sprite;
  mat: THREE.SpriteMaterial;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  life: number;
  size0: number;
  size1: number;
  alpha: number;
  active: boolean;
}

const W = 5; // cabin width (x)
const D = 4; // cabin depth (z); door on -Z (north)
const LOG_R = 0.2;
const LEVELS = 6;
const FOUND_H = 0.55;
const WALL_TOP = FOUND_H + LEVELS * LOG_R * 2;
const RISE = 1.7;

function makeSoftTex(): THREE.Texture {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.5, 'rgba(255,255,255,0.6)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function makeSignTex(): THREE.Texture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 96;
  const g = c.getContext('2d')!;
  g.fillStyle = '#a8703f';
  g.fillRect(0, 0, 256, 96);
  g.fillStyle = 'rgba(0,0,0,0.12)';
  for (let y = 0; y < 96; y += 24) g.fillRect(0, y, 256, 3);
  g.strokeStyle = '#6b4224';
  g.lineWidth = 8;
  g.strokeRect(4, 4, 248, 88);
  g.fillStyle = '#fff6e0';
  g.font = 'bold 40px "Trebuchet MS", sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText('COCOA', 128, 40);
  g.font = 'bold 20px "Trebuchet MS", sans-serif';
  g.fillStyle = '#ffd27a';
  g.fillText('CABIN', 128, 72);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class Base implements BaseAPI {
  readonly object: THREE.Group;
  readonly position: THREE.Vector3;
  readonly radius = BASE_RADIUS;
  hp: number;
  maxHp: number;

  private ctx: GameContext;
  private cabin: THREE.Group;
  private flashMats: THREE.MeshStandardMaterial[] = [];
  private windowMats: THREE.MeshStandardMaterial[] = [];
  private flash = 0;
  private wobble = 0;
  private time = 0;
  private smoke: Puff[] = [];
  private fire: Puff[] = [];
  private smokeTimer = 0;
  private fireTimer = 0;
  private chimneyTop = new THREE.Vector3();
  private fireLight: THREE.PointLight;
  private porchLight: THREE.PointLight;
  private softTex: THREE.Texture;
  private flashColor = new THREE.Color(0xff2a1a);
  private fireSpots: THREE.Vector3[] = [];

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    this.position = new THREE.Vector3(BASE_POSITION.x, 0, BASE_POSITION.z);
    this.maxHp = ctx.stats.baseMaxHp;
    this.hp = this.maxHp;
    this.object = new THREE.Group();
    this.object.name = 'Base';
    this.object.position.copy(this.position);
    this.cabin = new THREE.Group();
    this.object.add(this.cabin);
    this.softTex = makeSoftTex();
    this.build();

    this.porchLight = new THREE.PointLight(0xffa04a, 14, 10, 2);
    this.porchLight.position.set(0, 2.2, -D / 2 - 1.4);
    this.object.add(this.porchLight);
    this.fireLight = new THREE.PointLight(0xff6a1a, 0, 14, 2);
    this.fireLight.position.set(0, WALL_TOP + 2, 0);
    this.object.add(this.fireLight);

    this.initParticles();
    ctx.scene.add(this.object);
  }

  /* ------------------------------------------------------------------ model */

  private std(color: number, opts: THREE.MeshStandardMaterialParameters = {}, flash = true): THREE.MeshStandardMaterial {
    const m = new THREE.MeshStandardMaterial({ color, roughness: 0.85, flatShading: true, ...opts });
    if (flash) this.flashMats.push(m);
    return m;
  }

  private add(geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D = this.cabin, cast = true): THREE.Mesh {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.castShadow = cast;
    m.receiveShadow = true;
    parent.add(m);
    return m;
  }

  private build(): void {
    const logA = this.std(0x9a5f34);
    const logB = this.std(0x8a522b);
    const logEnd = this.std(0xd9a066);
    const stone = this.std(0x8f8a94);
    const darkWood = this.std(0x5a3620);
    const plank = this.std(0xb07a45);
    const snow = this.std(0xffffff, { roughness: 0.8 });
    const red = this.std(0xc8372d);
    const gold = this.std(0xffcc4a, { metalness: 0.6, roughness: 0.35 });
    const green = this.std(0x2f8a4a);
    const ice = new THREE.MeshStandardMaterial({ color: 0xcff2ff, roughness: 0.1, metalness: 0.1, transparent: true, opacity: 0.85 });
    const winMat = new THREE.MeshStandardMaterial({ color: 0xffd27a, emissive: 0xffa13a, emissiveIntensity: 1.6, roughness: 0.4 });
    this.windowMats.push(winMat);

    // foundation + inner fill
    this.add(new THREE.BoxGeometry(W + 0.5, FOUND_H, D + 0.5), stone, 0, FOUND_H / 2, 0);
    this.add(new THREE.BoxGeometry(W - 0.3, WALL_TOP - FOUND_H, D - 0.3), darkWood, 0, (WALL_TOP + FOUND_H) / 2, 0, this.cabin, false);

    // log walls
    const logGeo = new THREE.CylinderGeometry(LOG_R, LOG_R, 1, 8);
    const endGeo = new THREE.CircleGeometry(LOG_R * 0.85, 8);
    for (let l = 0; l < LEVELS; l++) {
      const y = FOUND_H + LOG_R + l * LOG_R * 2;
      const mat = l % 2 ? logA : logB;
      for (const sz of [-1, 1]) {
        const m = this.add(logGeo, mat, 0, y, (sz * D) / 2);
        m.rotation.z = Math.PI / 2;
        m.scale.y = W + 0.7;
      }
      for (const sx of [-1, 1]) {
        const m = this.add(logGeo, mat, (sx * W) / 2, y + LOG_R * 0.5, 0);
        m.rotation.x = Math.PI / 2;
        m.scale.y = D + 0.7;
        // visible log ends at the corners
        for (const sz of [-1, 1]) {
          const e = this.add(endGeo, logEnd, (sx * W) / 2, y + LOG_R * 0.5, sz * (D / 2 + 0.351), this.cabin, false);
          e.rotation.y = sz > 0 ? 0 : Math.PI;
        }
      }
    }

    // gable triangles
    const tri = new THREE.Shape();
    tri.moveTo(-W / 2 - 0.1, 0);
    tri.lineTo(W / 2 + 0.1, 0);
    tri.lineTo(0, RISE);
    tri.lineTo(-W / 2 - 0.1, 0);
    const gableGeo = new THREE.ExtrudeGeometry(tri, { depth: 0.3, bevelEnabled: false });
    this.add(gableGeo, plank, 0, WALL_TOP, -D / 2 - 0.15);
    this.add(gableGeo, plank, 0, WALL_TOP, D / 2 - 0.15);
    // round attic window
    const attic = this.add(new THREE.CircleGeometry(0.32, 16), winMat, 0, WALL_TOP + 0.65, -D / 2 - 0.16, this.cabin, false);
    attic.rotation.y = Math.PI;
    const atticRim = this.add(new THREE.TorusGeometry(0.34, 0.06, 6, 16), plank, 0, WALL_TOP + 0.65, -D / 2 - 0.17);
    atticRim.rotation.y = Math.PI;

    // roof panels (ridge along Z)
    const half = W / 2 + 0.1;
    const a = Math.atan2(RISE, half);
    const slopeLen = Math.hypot(half, RISE);
    const over = 0.75;
    const len = slopeLen + over;
    const roofGeo = new THREE.BoxGeometry(len, 0.16, D + 1.3);
    const snowGeo = new THREE.BoxGeometry(len + 0.08, 0.26, D + 1.4);
    const roofMat = this.std(0x7a2f2a);
    const lipGeo = new THREE.SphereGeometry(0.2, 8, 6);
    const icicleGeo = new THREE.ConeGeometry(0.06, 0.4, 5).rotateX(Math.PI);
    for (const s of [-1, 1]) {
      const cx = s * (half / 2 + (over / 2) * Math.cos(a));
      const cy = WALL_TOP + RISE / 2 - (over / 2) * Math.sin(a) + 0.1;
      const r = this.add(roofGeo, roofMat, cx, cy, 0);
      r.rotation.z = -s * a;
      const nx = s * Math.sin(a);
      const ny = Math.cos(a);
      const sn = this.add(snowGeo, snow, cx + nx * 0.2, cy + ny * 0.2, 0);
      sn.rotation.z = -s * a;
      // snow lip + icicles along the eave
      const ex = s * (half + over * Math.cos(a)) + nx * 0.15;
      const ey = WALL_TOP - over * Math.sin(a) + 0.1 + ny * 0.15;
      for (let k = 0; k < 9; k++) {
        const z = -D / 2 - 0.55 + (k / 8) * (D + 1.1);
        const lip = this.add(lipGeo, snow, ex, ey, z, this.cabin, false);
        lip.scale.set(1.1, 0.8, 1.6);
        if (k % 2 === 1) {
          const ic = this.add(icicleGeo, ice, ex, ey - 0.3, z + 0.1, this.cabin, false);
          ic.scale.y = 0.7 + ((k * 37) % 5) * 0.15;
        }
      }
      this.fireSpots.push(new THREE.Vector3(cx * 0.8, cy + 0.4, -0.8), new THREE.Vector3(cx * 0.6, cy + 0.6, 1.0));
    }
    // ridge snow
    const ridge = this.add(new THREE.CylinderGeometry(0.28, 0.28, D + 1.4, 8), snow, 0, WALL_TOP + RISE + 0.22, 0, this.cabin, false);
    ridge.rotation.x = Math.PI / 2;

    // chimney
    const chX = 1.25;
    const chZ = 0.7;
    const chH = 2.6;
    const chBase = WALL_TOP + 0.4;
    this.add(new THREE.BoxGeometry(0.8, chH, 0.8), stone, chX, chBase + chH / 2 - 0.4, chZ);
    this.add(new THREE.BoxGeometry(0.95, 0.18, 0.95), stone, chX, chBase + chH - 0.4, chZ);
    const chSnow = this.add(new THREE.BoxGeometry(0.98, 0.12, 0.98), snow, chX, chBase + chH - 0.25, chZ, this.cabin, false);
    chSnow.scale.set(1, 1, 1);
    this.add(new THREE.BoxGeometry(0.5, 0.05, 0.5), new THREE.MeshBasicMaterial({ color: 0x1a1210 }), chX, chBase + chH - 0.18, chZ, this.cabin, false);
    this.chimneyTop.set(chX, chBase + chH - 0.1, chZ);

    // windows (front x2, sides x1 each, back x1)
    const frameGeoH = new THREE.BoxGeometry(1.0, 0.1, 0.1);
    const frameGeoV = new THREE.BoxGeometry(0.1, 0.9, 0.1);
    const paneGeo = new THREE.BoxGeometry(0.85, 0.75, 0.05);
    const shutterGeo = new THREE.BoxGeometry(0.3, 0.85, 0.06);
    const winY = FOUND_H + 1.3;
    const addWindow = (x: number, z: number, ry: number) => {
      const g = new THREE.Group();
      g.position.set(x, winY, z);
      g.rotation.y = ry;
      this.cabin.add(g);
      this.add(paneGeo, winMat, 0, 0, 0, g, false);
      this.add(frameGeoH, logEnd, 0, 0.45, 0.04, g);
      this.add(frameGeoH, logEnd, 0, -0.45, 0.04, g);
      this.add(frameGeoH, logEnd, 0, 0, 0.05, g).scale.x = 0.85;
      this.add(frameGeoV, logEnd, -0.48, 0, 0.04, g);
      this.add(frameGeoV, logEnd, 0.48, 0, 0.04, g);
      this.add(frameGeoV, logEnd, 0, 0, 0.05, g);
      this.add(shutterGeo, red, -0.68, 0, 0.02, g);
      this.add(shutterGeo, red, 0.68, 0, 0.02, g);
      const sill = this.add(new THREE.BoxGeometry(1.2, 0.12, 0.25), snow, 0, -0.52, 0.1, g, false);
      sill.scale.y = 1.2;
    };
    const fz = -D / 2 - LOG_R - 0.02;
    addWindow(-1.55, fz, Math.PI);
    addWindow(1.55, fz, Math.PI);
    addWindow(W / 2 + LOG_R + 0.02, -0.2, Math.PI / 2);
    addWindow(-W / 2 - LOG_R - 0.02, -0.2, -Math.PI / 2);
    addWindow(0, D / 2 + LOG_R + 0.02, 0);

    // door with wreath
    const door = this.add(new THREE.BoxGeometry(1.0, 1.85, 0.12), red, 0, FOUND_H + 0.93, fz - 0.02);
    door.castShadow = false;
    this.add(new THREE.BoxGeometry(1.2, 0.14, 0.16), logEnd, 0, FOUND_H + 1.92, fz - 0.03);
    this.add(new THREE.SphereGeometry(0.06, 8, 6), gold, 0.35, FOUND_H + 0.9, fz - 0.1, this.cabin, false);
    const wreath = this.add(new THREE.TorusGeometry(0.22, 0.07, 6, 14), green, 0, FOUND_H + 1.4, fz - 0.1, this.cabin, false);
    wreath.rotation.y = Math.PI;
    this.add(new THREE.SphereGeometry(0.06, 6, 5), red, 0, FOUND_H + 1.2, fz - 0.15, this.cabin, false);

    // porch deck, posts, awning
    const pz = -D / 2 - 1.0;
    this.add(new THREE.BoxGeometry(3.4, 0.16, 1.6), plank, 0, FOUND_H - 0.02, pz);
    this.add(new THREE.BoxGeometry(1.4, 0.14, 0.5), plank, 0, FOUND_H * 0.45, pz - 1.0);
    const postGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.9, 6);
    for (const sx of [-1, 1]) this.add(postGeo, darkWood, sx * 1.55, FOUND_H + 0.95, pz - 0.65);
    const awn = this.add(new THREE.BoxGeometry(3.6, 0.12, 1.9), roofMat, 0, FOUND_H + 2.0, pz + 0.05);
    awn.rotation.x = -0.18;
    const awnSnow = this.add(new THREE.BoxGeometry(3.7, 0.18, 1.95), snow, 0, FOUND_H + 2.13, pz + 0.07, this.cabin, false);
    awnSnow.rotation.x = -0.18;
    // lantern
    const lantern = new THREE.MeshStandardMaterial({ color: 0xffe0a0, emissive: 0xffa040, emissiveIntensity: 2.2 });
    this.windowMats.push(lantern);
    this.add(new THREE.BoxGeometry(0.18, 0.26, 0.18), lantern, 0.85, FOUND_H + 1.75, fz - 0.15, this.cabin, false);

    // sign post with a giant cocoa mug
    const sign = new THREE.Group();
    sign.position.set(-2.9, 0, -D / 2 - 1.8);
    sign.rotation.y = 0.35;
    this.object.add(sign);
    this.add(new THREE.BoxGeometry(0.14, 1.9, 0.14), darkWood, 0, 0.95, 0, sign);
    const boardMat = new THREE.MeshStandardMaterial({ map: makeSignTex(), roughness: 0.8 });
    this.flashMats.push(boardMat);
    const board = this.add(new THREE.BoxGeometry(1.5, 0.56, 0.08), boardMat, 0, 1.55, -0.08, sign);
    board.rotation.y = Math.PI;
    const mugMat = this.std(0xe8453c, { roughness: 0.4, flatShading: false });
    this.add(new THREE.CylinderGeometry(0.3, 0.26, 0.55, 14), mugMat, 0, 2.15, -0.05, sign);
    const stripe = this.std(0xffffff, { roughness: 0.4, flatShading: false });
    this.add(new THREE.CylinderGeometry(0.305, 0.295, 0.08, 14), stripe, 0, 2.2, -0.05, sign, false);
    this.add(new THREE.CylinderGeometry(0.26, 0.26, 0.04, 14), this.std(0x5a2e1a, { flatShading: false }), 0, 2.42, -0.05, sign, false);
    const handle = this.add(new THREE.TorusGeometry(0.14, 0.045, 6, 12), mugMat, 0.32, 2.15, -0.05, sign, false);
    handle.rotation.y = 0;
    const mallow = this.std(0xfff4f0, { flatShading: false });
    const mg = new THREE.BoxGeometry(0.1, 0.08, 0.1);
    this.add(mg, mallow, 0.08, 2.47, 0.02, sign, false).rotation.y = 0.6;
    this.add(mg, mallow, -0.08, 2.47, -0.1, sign, false).rotation.y = 1.4;
    this.add(mg, mallow, 0.0, 2.5, -0.12, sign, false).rotation.y = 0.2;

    // fence of snowballs around the yard (gap at the front path)
    const ballGeo = new THREE.SphereGeometry(1, 12, 8);
    const ballMat = this.std(0xf7fbff, { roughness: 0.75, flatShading: false });
    const n = 26;
    const im = new THREE.InstancedMesh(ballGeo, ballMat, n);
    const dummy = new THREE.Object3D();
    let count = 0;
    for (let i = 0; i < n + 6; i++) {
      const ang = (i / (n + 6)) * Math.PI * 2; // 0 = +Z (south)
      const fromNorth = Math.abs(Math.PI - ang);
      if (fromNorth < 0.42) continue;
      if (count >= n) break;
      const r = 0.32 + ((i * 53) % 7) * 0.025;
      dummy.position.set(Math.sin(ang) * (BASE_RADIUS - 0.2), r * 0.85, Math.cos(ang) * (BASE_RADIUS - 0.2));
      dummy.scale.setScalar(r);
      dummy.rotation.set(i, i * 2, 0);
      dummy.updateMatrix();
      im.setMatrixAt(count++, dummy.matrix);
    }
    im.count = count;
    im.castShadow = true;
    im.receiveShadow = true;
    im.instanceMatrix.needsUpdate = true;
    this.object.add(im);
    // a little snowman friend guarding the porch
    const sm = new THREE.Group();
    sm.position.set(2.7, 0, -D / 2 - 1.6);
    this.object.add(sm);
    this.add(ballGeo, ballMat, 0, 0.75, 0, sm).scale.setScalar(0.42);
    this.add(ballGeo, ballMat, 0, 1.28, 0, sm).scale.setScalar(0.3);
    this.add(new THREE.ConeGeometry(0.06, 0.3, 6).rotateX(-Math.PI / 2), this.std(0xff8a1a), 0, 1.3, -0.4, sm, false);
    const scarf = this.add(new THREE.TorusGeometry(0.25, 0.07, 6, 14), red, 0, 1.06, 0, sm, false);
    scarf.rotation.x = Math.PI / 2;
    const hat = this.add(new THREE.CylinderGeometry(0.18, 0.18, 0.3, 10), darkWood, 0, 1.68, 0, sm);
    hat.scale.set(1, 1, 1);
    this.add(new THREE.CylinderGeometry(0.28, 0.28, 0.04, 10), darkWood, 0, 1.54, 0, sm, false);
  }

  /* ------------------------------------------------------------------ particles */

  private makePuff(additive: boolean): Puff {
    const mat = new THREE.SpriteMaterial({
      map: this.softTex,
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    const sprite = new THREE.Sprite(mat);
    sprite.visible = false;
    this.object.add(sprite);
    return { sprite, mat, vx: 0, vy: 0, vz: 0, age: 0, life: 1, size0: 1, size1: 1, alpha: 1, active: false };
  }

  private initParticles(): void {
    for (let i = 0; i < 28; i++) this.smoke.push(this.makePuff(false));
    for (let i = 0; i < 22; i++) this.fire.push(this.makePuff(true));
  }

  private spawn(pool: Puff[], x: number, y: number, z: number, color: number, life: number, s0: number, s1: number, vy: number, alpha: number): void {
    let p: Puff | null = null;
    for (let i = 0; i < pool.length; i++) {
      if (!pool[i].active) {
        p = pool[i];
        break;
      }
    }
    if (!p) return;
    p.active = true;
    p.age = 0;
    p.life = life;
    p.size0 = s0;
    p.size1 = s1;
    p.alpha = alpha;
    p.vx = (Math.random() - 0.5) * 0.4 + 0.25;
    p.vz = (Math.random() - 0.5) * 0.4 + 0.15;
    p.vy = vy;
    p.mat.color.setHex(color);
    p.mat.rotation = Math.random() * Math.PI * 2;
    p.sprite.position.set(x, y, z);
    p.sprite.visible = true;
  }

  private stepPool(pool: Puff[], dt: number): void {
    for (let i = 0; i < pool.length; i++) {
      const p = pool[i];
      if (!p.active) continue;
      p.age += dt;
      const t = p.age / p.life;
      if (t >= 1) {
        p.active = false;
        p.sprite.visible = false;
        continue;
      }
      p.sprite.position.x += p.vx * dt;
      p.sprite.position.y += p.vy * dt;
      p.sprite.position.z += p.vz * dt;
      const s = p.size0 + (p.size1 - p.size0) * t;
      p.sprite.scale.set(s, s, s);
      p.mat.opacity = p.alpha * Math.min(1, t * 6) * (1 - t);
      p.mat.rotation += dt * 0.3;
    }
  }

  /* ------------------------------------------------------------------ API */

  damage(amount: number): void {
    if (amount <= 0 || this.hp <= 0) return;
    this.hp = Math.max(0, this.hp - amount);
    this.flash = 1;
    this.wobble = Math.min(1, this.wobble + 0.5 + amount / Math.max(1, this.maxHp) * 4);
    this.ctx.events.emit('baseDamaged', { amount });
    this.ctx.audio?.play('baseHit');
  }

  repair(amount: number): void {
    if (amount <= 0) return;
    this.hp = Math.min(this.maxHp, this.hp + amount);
  }

  reset(maxHp: number): void {
    this.maxHp = maxHp;
    this.hp = maxHp;
    this.flash = 0;
    this.wobble = 0;
    for (const p of this.fire) {
      p.active = false;
      p.sprite.visible = false;
    }
  }

  update(dt: number): void {
    this.time += dt;
    const t = this.time;
    const frac = this.maxHp > 0 ? this.hp / this.maxHp : 1;
    const burning = frac < 0.35;

    // hit flash + wobble
    if (this.flash > 0 || this.wobble > 0) {
      this.flash = Math.max(0, this.flash - dt * 3.5);
      this.wobble = Math.max(0, this.wobble - dt * 2.5);
      const f = this.flash;
      for (let i = 0; i < this.flashMats.length; i++) {
        this.flashMats[i].emissive.copy(this.flashColor).multiplyScalar(f * 0.65);
      }
      const w = this.wobble;
      this.cabin.rotation.z = Math.sin(t * 38) * 0.035 * w;
      this.cabin.rotation.x = Math.cos(t * 31) * 0.02 * w;
      const sq = 1 - Math.sin(t * 30) * 0.03 * w;
      this.cabin.scale.set(1 / Math.sqrt(sq), sq, 1 / Math.sqrt(sq));
    }

    // windows flicker warmly (more when burning)
    const flick = 1.5 + Math.sin(t * 7.3) * 0.08 + Math.sin(t * 13.1) * 0.06 + (burning ? Math.sin(t * 23) * 0.4 : 0);
    for (let i = 0; i < this.windowMats.length; i++) this.windowMats[i].emissiveIntensity = flick;
    this.porchLight.intensity = 13 + Math.sin(t * 9.1) * 1.2;

    // chimney smoke
    this.smokeTimer -= dt;
    if (this.smokeTimer <= 0) {
      this.smokeTimer = burning ? 0.12 : 0.32;
      const c = this.chimneyTop;
      if (burning) this.spawn(this.smoke, c.x, c.y, c.z, 0x3a363a, 3.2, 0.7, 3.2, 1.6, 0.85);
      else this.spawn(this.smoke, c.x, c.y, c.z, 0xeef0f4, 3.0, 0.45, 2.2, 1.1, 0.7);
    }
    // roof fire + dark smoke when badly damaged
    if (burning) {
      this.fireTimer -= dt;
      if (this.fireTimer <= 0) {
        this.fireTimer = 0.05;
        const s = this.fireSpots[(Math.random() * this.fireSpots.length) | 0];
        const col = Math.random() < 0.5 ? 0xff6a1a : 0xffb030;
        this.spawn(this.fire, s.x + (Math.random() - 0.5) * 0.8, s.y, s.z + (Math.random() - 0.5) * 1.2, col, 0.7 + Math.random() * 0.4, 0.9, 0.3, 2.2, 1);
        if (Math.random() < 0.25) this.spawn(this.smoke, s.x, s.y + 0.8, s.z, 0x2c282c, 2.6, 0.8, 3.0, 1.8, 0.8);
      }
      this.fireLight.intensity = 22 + Math.sin(t * 17) * 6 + Math.sin(t * 29) * 4;
    } else if (this.fireLight.intensity !== 0) {
      this.fireLight.intensity = 0;
    }
    this.stepPool(this.smoke, dt);
    this.stepPool(this.fire, dt);
  }
}
