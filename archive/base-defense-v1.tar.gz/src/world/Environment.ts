import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { GameContext, WorldAPI, ZoneDef } from '../core/types';
import { ARENA } from '../core/types';

type Theme = ZoneDef['theme'];

interface Item {
  x: number;
  y: number;
  z: number;
  ry: number;
  sx: number;
  sy: number;
  sz: number;
  rx?: number;
  rz?: number;
  color?: number;
}

const PORTAL_COLORS: Record<Theme, number> = {
  meadow: 0x5fd0ff,
  pines: 0xff7a2e,
  lake: 0x6ff3ff,
  blizzard: 0x9fb4ff,
  peak: 0xd24dff,
};

const ROCK_COLORS: Record<Theme, number> = {
  meadow: 0x8a8f99,
  pines: 0x6e6a66,
  lake: 0x7f93a3,
  blizzard: 0x4a4f58,
  peak: 0x4b4058,
};

const MOUNTAIN_COLORS: Record<Theme, number> = {
  meadow: 0x7d93b8,
  pines: 0x4f6378,
  lake: 0x87a5bf,
  blizzard: 0xb7c1cc,
  peak: 0x3d3150,
};

const FOLIAGE: Record<Theme, number[]> = {
  meadow: [0x2f7d4a, 0x3a8a52, 0x2a6e44],
  pines: [0x1f5a3c, 0x245f3a, 0x2d6b45, 0x1a4d35],
  lake: [0x2a6a55, 0x2f7560],
  blizzard: [0x2b4a44, 0x34524b],
  peak: [0x2c4a4f, 0x3a3f5e],
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let snowflakeTex: THREE.Texture | null = null;
let stripeTex: THREE.Texture | null = null;
let glowTex: THREE.Texture | null = null;
let swirlTex: THREE.Texture | null = null;

function getSnowflakeTex(): THREE.Texture {
  if (snowflakeTex) return snowflakeTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.35, 'rgba(255,255,255,0.85)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  snowflakeTex = new THREE.CanvasTexture(c);
  snowflakeTex.colorSpace = THREE.SRGBColorSpace;
  return snowflakeTex;
}

function getStripeTex(): THREE.Texture {
  if (stripeTex) return stripeTex;
  const c = document.createElement('canvas');
  c.width = 16;
  c.height = 64;
  const g = c.getContext('2d')!;
  g.fillStyle = '#ffffff';
  g.fillRect(0, 0, 16, 64);
  g.fillStyle = '#e8263a';
  g.fillRect(0, 0, 16, 32);
  stripeTex = new THREE.CanvasTexture(c);
  stripeTex.colorSpace = THREE.SRGBColorSpace;
  stripeTex.wrapS = stripeTex.wrapT = THREE.RepeatWrapping;
  stripeTex.repeat.set(1, 5);
  return stripeTex;
}

function getGlowTex(): THREE.Texture {
  if (glowTex) return glowTex;
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.4, 'rgba(255,255,255,0.45)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  glowTex = new THREE.CanvasTexture(c);
  glowTex.colorSpace = THREE.SRGBColorSpace;
  return glowTex;
}

function getSwirlTex(): THREE.Texture {
  if (swirlTex) return swirlTex;
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  grd.addColorStop(0, 'rgba(255,255,255,0.95)');
  grd.addColorStop(0.5, 'rgba(255,255,255,0.35)');
  grd.addColorStop(1, 'rgba(255,255,255,0.05)');
  g.fillStyle = grd;
  g.fillRect(0, 0, S, S);
  g.translate(S / 2, S / 2);
  g.strokeStyle = 'rgba(255,255,255,0.8)';
  g.lineCap = 'round';
  for (let arm = 0; arm < 4; arm++) {
    g.beginPath();
    for (let t = 0; t < 1; t += 0.02) {
      const a = arm * (Math.PI / 2) + t * Math.PI * 2.2;
      const r = t * S * 0.48;
      if (t === 0) g.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      else g.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    g.lineWidth = 10;
    g.stroke();
  }
  swirlTex = new THREE.CanvasTexture(c);
  swirlTex.colorSpace = THREE.SRGBColorSpace;
  return swirlTex;
}

const SNOW_BOX = 70;
const SNOW_H = 36;

export class Environment implements WorldAPI {
  private ctx: GameContext;
  private hemi: THREE.HemisphereLight;
  private sun: THREE.DirectionalLight;
  private sky: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;
  private fog: THREE.Fog;
  private decor: THREE.Group | null = null;
  private zone: ZoneDef;
  private time = 0;

  // ambient animation targets
  private swirls: THREE.Mesh[] = [];
  private pulseMats: { mat: THREE.MeshStandardMaterial | THREE.MeshBasicMaterial; base: number; speed: number; phase: number }[] = [];

  // falling snow
  private flakes: THREE.Points | null = null;
  private flakePos: Float32Array = new Float32Array(0);
  private flakePhase: Float32Array = new Float32Array(0);
  private windX = 1;
  private windZ = 0.4;
  private fallSpeed = 1.5;
  private sway = 0.6;

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    this.zone = ctx.zone;
    const scene = ctx.scene;

    this.fog = new THREE.Fog(0xffffff, 60, 170);
    scene.fog = this.fog;
    scene.background = new THREE.Color(0xffffff);

    this.hemi = new THREE.HemisphereLight(0xbcd7ff, 0xe8eef5, 0.9);
    scene.add(this.hemi);

    const sun = new THREE.DirectionalLight(0xffffff, 2.5);
    sun.position.set(45, 80, 55);
    sun.target.position.set(0, 0, -2);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = -64;
    sc.right = 64;
    sc.top = 64;
    sc.bottom = -64;
    sc.near = 5;
    sc.far = 260;
    sc.updateProjectionMatrix();
    sun.shadow.bias = -0.0006;
    sun.shadow.normalBias = 0.04;
    scene.add(sun);
    scene.add(sun.target);
    this.sun = sun;

    this.skyMat = new THREE.ShaderMaterial({
      uniforms: {
        top: { value: new THREE.Color() },
        bottom: { value: new THREE.Color() },
        horizon: { value: new THREE.Color() },
      },
      vertexShader: `
        varying vec3 vDir;
        void main() {
          vDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        uniform vec3 top; uniform vec3 bottom; uniform vec3 horizon;
        varying vec3 vDir;
        void main() {
          float h = vDir.y;
          vec3 c = mix(horizon, bottom, smoothstep(-0.02, 0.12, h));
          c = mix(c, top, smoothstep(0.08, 0.75, h));
          gl_FragColor = vec4(c, 1.0);
          #include <colorspace_fragment>
        }`,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      toneMapped: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(420, 32, 16), this.skyMat);
    this.sky.renderOrder = -10;
    this.sky.frustumCulled = false;
    scene.add(this.sky);
  }

  /* ------------------------------------------------------------------ zone */

  setZone(zone: ZoneDef): void {
    this.zone = zone;
    const scene = this.ctx.scene;
    this.fog.color.setHex(zone.fogColor);
    this.fog.near = zone.fogNear;
    this.fog.far = zone.fogFar;
    (scene.background as THREE.Color).setHex(zone.fogColor);

    this.skyMat.uniforms.top.value.setHex(zone.skyTop);
    this.skyMat.uniforms.bottom.value.setHex(zone.skyBottom);
    this.skyMat.uniforms.horizon.value.setHex(zone.fogColor);

    this.hemi.color.setHex(zone.ambientColor);
    this.hemi.groundColor.setHex(zone.snowTint).lerp(new THREE.Color(zone.ambientColor), 0.3);
    this.hemi.intensity = zone.ambientIntensity;
    this.sun.color.setHex(zone.sunColor);
    this.sun.intensity = zone.sunIntensity;

    this.buildDecor(zone);
    this.buildSnowfall(zone);
  }

  private disposeDecor(): void {
    if (!this.decor) return;
    const geos = new Set<THREE.BufferGeometry>();
    const mats = new Set<THREE.Material>();
    this.decor.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) geos.add(m.geometry);
      if (m.material) {
        if (Array.isArray(m.material)) m.material.forEach((x) => mats.add(x));
        else mats.add(m.material);
      }
      if ((o as THREE.InstancedMesh).isInstancedMesh) (o as THREE.InstancedMesh).dispose();
    });
    geos.forEach((g) => g.dispose());
    mats.forEach((m) => m.dispose());
    this.ctx.scene.remove(this.decor);
    this.decor = null;
    this.swirls.length = 0;
    this.pulseMats.length = 0;
  }

  private buildDecor(zone: ZoneDef): void {
    this.disposeDecor();
    const group = new THREE.Group();
    group.name = 'Decor';
    this.decor = group;
    this.ctx.scene.add(group);
    const theme = zone.theme;
    const G = zone.snowDepth; // outer ground height
    const rnd = mulberry32(1234 + zone.index * 101);
    const snowCol = new THREE.Color(zone.snowTint);

    const snowMat = new THREE.MeshStandardMaterial({ color: snowCol, roughness: 0.85, flatShading: true });

    /* ---------- placement helpers ---------- */
    const inArena = (x: number, z: number, m: number) =>
      x > ARENA.minX - m && x < ARENA.maxX + m && z > ARENA.minZ - m && z < ARENA.maxZ + m;
    const southCam = (x: number, z: number) => z > ARENA.maxZ - 2 && z < 84 && Math.abs(x) < 50;
    const portalZone = (x: number, z: number) => z < ARENA.minZ + 2 && z > -72 && Math.abs(x) < 44;
    const scatter = (count: number, minR: number, maxR: number, opts: { tall?: boolean; margin?: number } = {}) => {
      const out: { x: number; z: number }[] = [];
      const margin = opts.margin ?? 3;
      let tries = 0;
      while (out.length < count && tries < count * 40) {
        tries++;
        const x = (rnd() * 2 - 1) * maxR;
        const z = (rnd() * 2 - 1) * maxR;
        const r = Math.hypot(x, z);
        if (r > maxR || r < minR) continue;
        if (inArena(x, z, margin)) continue;
        if (portalZone(x, z)) continue;
        if (opts.tall && southCam(x, z)) continue;
        out.push({ x, z });
      }
      return out;
    };
    const dummy = new THREE.Object3D();
    const tmpCol = new THREE.Color();
    const addInstanced = (geo: THREE.BufferGeometry, mat: THREE.Material, items: Item[], cast = true, receive = false) => {
      if (items.length === 0) {
        geo.dispose();
        return null;
      }
      const im = new THREE.InstancedMesh(geo, mat, items.length);
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        dummy.position.set(it.x, it.y, it.z);
        dummy.rotation.set(it.rx ?? 0, it.ry, it.rz ?? 0);
        dummy.scale.set(it.sx, it.sy, it.sz);
        dummy.updateMatrix();
        im.setMatrixAt(i, dummy.matrix);
        if (it.color !== undefined) im.setColorAt(i, tmpCol.setHex(it.color));
      }
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.castShadow = cast;
      im.receiveShadow = receive;
      im.computeBoundingSphere();
      group.add(im);
      return im;
    };

    /* ---------- trees ---------- */
    const treeCounts: Record<Theme, number> = { meadow: 70, pines: 420, lake: 90, blizzard: 50, peak: 45 };
    const treePts = scatter(treeCounts[theme], 0, theme === 'pines' ? 120 : 130, { tall: true, margin: 4 });
    // pines: also a dense wall hugging the arena sides
    if (theme === 'pines') {
      for (let z = ARENA.minZ - 6; z < ARENA.maxZ; z += 3.2) {
        for (const side of [-1, 1]) {
          const x = side * (ARENA.maxX + 6 + rnd() * 6);
          if (!southCam(x, z)) treePts.push({ x, z: z + rnd() * 2 });
        }
      }
    }
    if (treePts.length) {
      const seg = 7;
      const tiers = [
        { r: 1.7, h: 2.2, y: 2.0 },
        { r: 1.3, h: 1.9, y: 3.4 },
        { r: 0.9, h: 1.6, y: 4.6 },
      ];
      const fol: THREE.BufferGeometry[] = [];
      const caps: THREE.BufferGeometry[] = [];
      for (const t of tiers) {
        fol.push(new THREE.ConeGeometry(t.r, t.h, seg).translate(0, t.y, 0));
        const ch = t.h * 0.42;
        caps.push(new THREE.ConeGeometry(t.r * 0.48, ch, seg).translate(0, t.y + t.h / 2 - ch / 2 + 0.02, 0));
        // snow rim on each tier
        caps.push(new THREE.CylinderGeometry(t.r * 0.75, t.r * 0.98, 0.18, seg).translate(0, t.y - t.h / 2 + 0.25, 0));
      }
      const folGeo = mergeGeometries(fol)!;
      const capGeo = mergeGeometries(caps)!;
      fol.forEach((g) => g.dispose());
      caps.forEach((g) => g.dispose());
      const trunkGeo = new THREE.CylinderGeometry(0.22, 0.3, 1.6, 6).translate(0, 0.8, 0);
      const folMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, flatShading: true });
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4428, roughness: 0.9, flatShading: true });
      const palette = FOLIAGE[theme];
      const items: Item[] = treePts.map((p) => {
        const s = 0.75 + rnd() * 0.9 + (Math.hypot(p.x, p.z) > 80 ? 0.5 : 0);
        return {
          x: p.x, y: G - 0.2, z: p.z, ry: rnd() * Math.PI * 2, sx: s, sy: s * (0.9 + rnd() * 0.35), sz: s,
          color: palette[(rnd() * palette.length) | 0],
        };
      });
      addInstanced(folGeo, folMat, items, true);
      addInstanced(capGeo, snowMat, items.map((i) => ({ ...i, color: undefined })), false);
      addInstanced(trunkGeo, trunkMat, items.map((i) => ({ ...i, color: undefined })), true);
    }

    /* ---------- rocks ---------- */
    const rockCounts: Record<Theme, number> = { meadow: 30, pines: 45, lake: 25, blizzard: 90, peak: 70 };
    const rockMat = new THREE.MeshStandardMaterial({ color: ROCK_COLORS[theme], roughness: 0.95, flatShading: true });
    const rockItems: Item[] = scatter(rockCounts[theme], 0, 110, { margin: 2.5 }).map((p) => {
      const s = 0.6 + rnd() * (theme === 'blizzard' || theme === 'peak' ? 2.4 : 1.4);
      return { x: p.x, y: G + s * 0.15, z: p.z, ry: rnd() * 6.28, rx: rnd() * 0.5, sx: s * (0.8 + rnd() * 0.6), sy: s * (0.55 + rnd() * 0.4), sz: s * (0.8 + rnd() * 0.6) };
    });
    addInstanced(new THREE.DodecahedronGeometry(1, 0), rockMat, rockItems, true, true);
    // snow caps on rocks
    addInstanced(
      new THREE.SphereGeometry(1, 7, 4, 0, Math.PI * 2, 0, Math.PI * 0.35),
      snowMat,
      rockItems.map((r) => ({ ...r, y: r.y + r.sy * 0.18, rx: 0, sx: r.sx * 0.92, sz: r.sz * 0.92, sy: r.sy * 0.9 })),
      false,
    );

    /* ---------- drifts ---------- */
    const driftItems: Item[] = scatter(theme === 'blizzard' ? 70 : 40, 0, 110, { margin: 2 }).map((p) => {
      const s = 1.5 + rnd() * 3;
      return { x: p.x, y: G - 0.1, z: p.z, ry: rnd() * 6.28, sx: s * 1.6, sy: s * 0.28, sz: s };
    });
    addInstanced(new THREE.SphereGeometry(1, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), snowMat, driftItems, false, true);

    /* ---------- distant mountain ring ---------- */
    {
      const fogC = new THREE.Color(zone.fogColor);
      const skyB = new THREE.Color(zone.skyBottom);
      const haze = theme === 'blizzard' ? 0.82 : 0.5;
      const mCol = new THREE.Color(MOUNTAIN_COLORS[theme]).lerp(fogC, haze);
      const cCol = snowCol.clone().lerp(skyB, haze * 0.6);
      const mMat = new THREE.MeshLambertMaterial({ color: mCol, flatShading: true, fog: false });
      const cMat = new THREE.MeshLambertMaterial({ color: cCol, flatShading: true, fog: false });
      const mGeo = new THREE.ConeGeometry(1, 1, 6, 1).translate(0, 0.5, 0);
      const mItems: Item[] = [];
      const cItems: Item[] = [];
      const n = 34;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + rnd() * 0.12;
        const R = 230 + rnd() * 70;
        const h = (theme === 'peak' ? 80 : 45) + rnd() * (theme === 'peak' ? 90 : 60);
        const r = 35 + rnd() * 40;
        const ry = rnd() * 6.28;
        const x = Math.sin(a) * R;
        const z = Math.cos(a) * R;
        mItems.push({ x, y: -2, z, ry, sx: r, sy: h, sz: r * (0.7 + rnd() * 0.5) });
        const k = 0.36;
        cItems.push({ x, y: -2 + h * (1 - k) - 0.3, z, ry, sx: r * k * 1.04, sy: h * k * 1.01, sz: mItems[i].sz * k * 1.04 });
      }
      const mm = addInstanced(mGeo, mMat, mItems, false);
      const cm = addInstanced(mGeo.clone(), cMat, cItems, false);
      if (mm) mm.renderOrder = -5;
      if (cm) cm.renderOrder = -5;
    }

    /* ---------- candy-striped boundary poles along ARENA edge ---------- */
    {
      const poleGeo = new THREE.CylinderGeometry(0.09, 0.09, 2.1, 8).translate(0, 1.05, 0);
      const poleMat = new THREE.MeshStandardMaterial({ map: getStripeTex(), roughness: 0.5 });
      const knobGeo = new THREE.SphereGeometry(0.16, 10, 8).translate(0, 2.15, 0);
      const knobMat = new THREE.MeshStandardMaterial({
        color: PORTAL_COLORS[theme], emissive: PORTAL_COLORS[theme], emissiveIntensity: 0.35, roughness: 0.4,
      });
      const poles: Item[] = [];
      const ropes: Item[] = [];
      const step = 4;
      const corners = [
        [ARENA.minX, ARENA.minZ], [ARENA.maxX, ARENA.minZ], [ARENA.maxX, ARENA.maxZ], [ARENA.minX, ARENA.maxZ],
      ];
      for (let s = 0; s < 4; s++) {
        const [ax, az] = corners[s];
        const [bx, bz] = corners[(s + 1) % 4];
        const len = Math.hypot(bx - ax, bz - az);
        const n = Math.max(1, Math.round(len / step));
        const isNorth = s === 0;
        for (let i = 0; i < n; i++) {
          const t = i / n;
          const x = ax + (bx - ax) * t;
          const z = az + (bz - az) * t;
          poles.push({ x, y: 0, z, ry: 0, sx: 1, sy: 1, sz: 1 });
          if (!isNorth) {
            const t2 = (i + 1) / n;
            const x2 = ax + (bx - ax) * t2;
            const z2 = az + (bz - az) * t2;
            const seg = Math.hypot(x2 - x, z2 - z);
            const ry = Math.atan2(x2 - x, z2 - z);
            ropes.push({ x: (x + x2) / 2, y: 1.45, z: (z + z2) / 2, ry, sx: 1, sy: 1, sz: seg });
            ropes.push({ x: (x + x2) / 2, y: 1.0, z: (z + z2) / 2, ry, sx: 1, sy: 1, sz: seg });
          }
        }
      }
      addInstanced(poleGeo, poleMat, poles, true);
      addInstanced(knobGeo, knobMat, poles, false);
      const ropeMat = new THREE.MeshStandardMaterial({ color: 0xe8263a, roughness: 0.6 });
      addInstanced(new THREE.BoxGeometry(0.05, 0.05, 1), ropeMat, ropes, false);
      // little pennant flags on the north line
      const flagShape = new THREE.Shape();
      flagShape.moveTo(0, 0);
      flagShape.lineTo(0.55, -0.16);
      flagShape.lineTo(0, -0.32);
      const flagGeo = new THREE.ShapeGeometry(flagShape).translate(0.09, 2.05, 0);
      const flagMat = new THREE.MeshStandardMaterial({ color: 0xffc83a, side: THREE.DoubleSide, roughness: 0.6 });
      addInstanced(flagGeo, flagMat, poles.filter((p) => p.z === ARENA.minZ).map((p) => ({ ...p, ry: Math.PI / 2 })), false);
    }

    /* ---------- spawn portals / ice caves at the north edge ---------- */
    this.buildPortals(group, zone, G, rnd, snowMat);

    /* ---------- theme extras ---------- */
    if (theme === 'meadow') this.buildMeadow(group, G, rnd, scatter, addInstanced);
    else if (theme === 'pines') this.buildPines(G, rnd, scatter, addInstanced);
    else if (theme === 'lake') this.buildLake(group, G, rnd, scatter, addInstanced);
    else if (theme === 'blizzard') this.buildBlizzard(group, G, rnd, scatter);
    else if (theme === 'peak') this.buildPeak(G, rnd, scatter, addInstanced, snowMat);
  }

  private buildPortals(group: THREE.Group, zone: ZoneDef, G: number, rnd: () => number, snowMat: THREE.Material): void {
    const theme = zone.theme;
    const color = PORTAL_COLORS[theme];
    const xs = [-26, -9, 9, 26];
    const caveMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(zone.snowTint).multiply(new THREE.Color(0xc8dcf0)), roughness: 0.6, flatShading: true,
    });
    const darkMat = new THREE.MeshBasicMaterial({ color: 0x0b0f22 });
    const ringMat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.6, roughness: 0.3 });
    const swirlMat = new THREE.MeshBasicMaterial({
      map: getSwirlTex(), color, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const glowMat = new THREE.MeshBasicMaterial({
      map: getGlowTex(), color, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const iceMat = new THREE.MeshStandardMaterial({
      color: 0xbfefff, emissive: color, emissiveIntensity: 0.25, roughness: 0.15, metalness: 0.1, flatShading: true,
      transparent: true, opacity: 0.9,
    });
    this.pulseMats.push({ mat: ringMat, base: 1.6, speed: 2.2, phase: 0 });
    this.pulseMats.push({ mat: glowMat as THREE.MeshBasicMaterial, base: 0.55, speed: 1.7, phase: 1 });

    const moundGeo = new THREE.SphereGeometry(1, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2);
    const mouthGeo = new THREE.CircleGeometry(1, 20, 0, Math.PI);
    const ringGeo = new THREE.TorusGeometry(1, 0.12, 8, 24, Math.PI);
    const swirlGeo = new THREE.CircleGeometry(1, 24);
    const glowGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
    const shardGeo = new THREE.OctahedronGeometry(1, 0);

    for (let i = 0; i < xs.length; i++) {
      const x = xs[i] + (rnd() - 0.5) * 3;
      const z = ARENA.minZ - 7 - rnd() * 2;
      const cave = new THREE.Group();
      cave.position.set(x, G - 0.3, z);
      cave.rotation.y = (rnd() - 0.5) * 0.3;
      group.add(cave);

      const mound = new THREE.Mesh(moundGeo, caveMat);
      mound.scale.set(5.5, 4.2 + rnd() * 1.2, 4.2);
      mound.castShadow = true;
      mound.receiveShadow = true;
      cave.add(mound);
      const snowTop = new THREE.Mesh(moundGeo, snowMat);
      snowTop.scale.set(4.6, 1.6, 3.6);
      snowTop.position.y = mound.scale.y - 1.25;
      cave.add(snowTop);

      const mouthR = 2.3;
      const mouth = new THREE.Mesh(mouthGeo, darkMat);
      mouth.scale.setScalar(mouthR);
      mouth.position.set(0, 0.05, 4.3);
      cave.add(mouth);
      const swirl = new THREE.Mesh(swirlGeo, swirlMat);
      swirl.scale.setScalar(mouthR * 0.95);
      swirl.position.set(0, 0.9, 4.36);
      swirl.userData.spin = (i % 2 ? 1 : -1) * (0.8 + rnd() * 0.6);
      cave.add(swirl);
      this.swirls.push(swirl);
      // clip lower half of swirl visually by darker mouth? keep it simple: swirl sits within arch height
      swirl.scale.y = mouthR * 0.95;
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.scale.setScalar(mouthR + 0.1);
      ring.position.set(0, 0.05, 4.42);
      cave.add(ring);
      const glow = new THREE.Mesh(glowGeo, glowMat);
      glow.scale.set(9, 1, 7);
      glow.position.set(0, 0.42, 7.2);
      cave.add(glow);
      // icy crystal shards around the entrance
      for (let k = 0; k < 6; k++) {
        const shard = new THREE.Mesh(shardGeo, iceMat);
        const a = (k / 5) * Math.PI - Math.PI;
        shard.position.set(Math.cos(a) * (mouthR + 1.2 + rnd()), 0.3 + rnd() * 0.5, 4.0 + rnd() * 0.8);
        if (k === 0 || k === 5) shard.position.y = 0.6;
        shard.scale.set(0.35 + rnd() * 0.3, 1.0 + rnd() * 1.6, 0.35 + rnd() * 0.3);
        shard.rotation.set((rnd() - 0.5) * 0.6, rnd() * 3, (rnd() - 0.5) * 0.8);
        shard.castShadow = true;
        cave.add(shard);
      }
    }
    // swirl is a full disc; mask lower half under ground by placing center at mouth level
    for (const s of this.swirls) s.position.y = 0.05;
  }

  private buildMeadow(
    group: THREE.Group,
    G: number,
    rnd: () => number,
    scatter: (n: number, a: number, b: number, o?: { tall?: boolean; margin?: number }) => { x: number; z: number }[],
    addInstanced: (g: THREE.BufferGeometry, m: THREE.Material, items: Item[], cast?: boolean, recv?: boolean) => THREE.InstancedMesh | null,
  ): void {
    // wooden fence around the arena (outside the candy poles)
    const wood = new THREE.MeshStandardMaterial({ color: 0x8a5a33, roughness: 0.9, flatShading: true });
    const posts: Item[] = [];
    const rails: Item[] = [];
    const off = 7;
    const minX = ARENA.minX - off, maxX = ARENA.maxX + off, minZ = ARENA.minZ - 20, maxZ = ARENA.maxZ + 12;
    const edges: [number, number, number, number][] = [
      [minX, maxZ, minX, minZ], [maxX, minZ, maxX, maxZ], [maxX, maxZ, minX, maxZ],
    ];
    for (const [ax, az, bx, bz] of edges) {
      const len = Math.hypot(bx - ax, bz - az);
      const n = Math.round(len / 3);
      for (let i = 0; i < n; i++) {
        if (rnd() < 0.08) continue; // a few broken gaps
        const t = i / n;
        const t2 = (i + 1) / n;
        const x = ax + (bx - ax) * t, z = az + (bz - az) * t;
        const x2 = ax + (bx - ax) * t2, z2 = az + (bz - az) * t2;
        posts.push({ x, y: G, z, ry: rnd() * 0.3, sx: 1, sy: 0.9 + rnd() * 0.25, sz: 1 });
        const ry = Math.atan2(x2 - x, z2 - z);
        const seg = Math.hypot(x2 - x, z2 - z);
        rails.push({ x: (x + x2) / 2, y: G + 0.55, z: (z + z2) / 2, ry, sx: 1, sy: 1, sz: seg, rx: (rnd() - 0.5) * 0.06 });
        rails.push({ x: (x + x2) / 2, y: G + 0.95, z: (z + z2) / 2, ry, sx: 1, sy: 1, sz: seg, rx: (rnd() - 0.5) * 0.06 });
      }
    }
    addInstanced(new THREE.BoxGeometry(0.22, 1.3, 0.22).translate(0, 0.45, 0), wood, posts, true);
    addInstanced(new THREE.BoxGeometry(0.1, 0.16, 1), wood, rails, true);
    const snowLine = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 });
    addInstanced(new THREE.BoxGeometry(0.16, 0.07, 1).translate(0, 0.11, 0), snowLine, rails.map((r) => ({ ...r })), false);

    // hay bales
    const hay = new THREE.MeshStandardMaterial({ color: 0xd9a441, roughness: 0.95, flatShading: true });
    const bales: Item[] = scatter(26, 0, 85, { margin: 9 }).map((p) => ({
      x: p.x, y: G + 0.55, z: p.z, ry: rnd() * 6.28, rz: Math.PI / 2, sx: 1, sy: 1, sz: 1,
    }));
    addInstanced(new THREE.CylinderGeometry(0.7, 0.7, 1.3, 12), hay, bales, true);
    const capMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 });
    addInstanced(
      new THREE.SphereGeometry(1, 10, 5, 0, Math.PI * 2, 0, Math.PI / 2),
      capMat,
      bales.map((b) => ({ x: b.x, y: b.y + 0.55, z: b.z, ry: b.ry, sx: 0.55, sy: 0.2, sz: 0.75 })),
      false,
    );
    // little red barn far south-west
    const barn = new THREE.Group();
    const red = new THREE.MeshStandardMaterial({ color: 0xc23b30, roughness: 0.8, flatShading: true });
    const white = new THREE.MeshStandardMaterial({ color: 0xfafafa, roughness: 0.8 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(8, 5, 10), red);
    body.position.y = 2.5;
    body.castShadow = true;
    barn.add(body);
    const roof = new THREE.Mesh(new THREE.CylinderGeometry(4.6, 4.6, 10.4, 3, 1), white);
    roof.rotation.x = Math.PI / 2;
    roof.rotation.y = Math.PI / 2;
    roof.scale.set(1, 1, 0.6);
    roof.position.y = 5 + 1.2;
    roof.castShadow = true;
    barn.add(roof);
    const door = new THREE.Mesh(new THREE.BoxGeometry(3, 3.4, 0.2), white);
    door.position.set(0, 1.7, 5.05);
    barn.add(door);
    barn.position.set(-62, G, 20);
    barn.rotation.y = Math.PI / 2.4;
    group.add(barn);
  }

  private buildPines(
    G: number,
    rnd: () => number,
    scatter: (n: number, a: number, b: number, o?: { tall?: boolean; margin?: number }) => { x: number; z: number }[],
    addInstanced: (g: THREE.BufferGeometry, m: THREE.Material, items: Item[], cast?: boolean, recv?: boolean) => THREE.InstancedMesh | null,
  ): void {
    // fallen logs and stumps
    const wood = new THREE.MeshStandardMaterial({ color: 0x6b4428, roughness: 0.9, flatShading: true });
    const logs: Item[] = scatter(24, 0, 90, { margin: 3 }).map((p) => ({
      x: p.x, y: G + 0.25, z: p.z, ry: rnd() * 6.28, rz: Math.PI / 2, sx: 1, sy: 1.5 + rnd() * 2, sz: 1,
    }));
    addInstanced(new THREE.CylinderGeometry(0.35, 0.4, 1, 8), wood, logs, true);
    const stumps: Item[] = scatter(30, 0, 90, { margin: 3 }).map((p) => ({ x: p.x, y: G, z: p.z, ry: rnd() * 6.28, sx: 1, sy: 0.6 + rnd() * 0.6, sz: 1 }));
    addInstanced(new THREE.CylinderGeometry(0.4, 0.5, 0.8, 8).translate(0, 0.3, 0), wood, stumps, true);
    // warm lantern glows between trees (fire imps' forest)
    const lantern = new THREE.MeshStandardMaterial({ color: 0xffb35a, emissive: 0xff8a2a, emissiveIntensity: 1.4 });
    this.pulseMats.push({ mat: lantern, base: 1.4, speed: 3.1, phase: 0.5 });
    addInstanced(
      new THREE.OctahedronGeometry(0.22, 0),
      lantern,
      scatter(18, 0, 70, { margin: 4 }).map((p) => ({ x: p.x, y: G + 0.6 + rnd() * 1.2, z: p.z, ry: rnd() * 6, sx: 1, sy: 1.4, sz: 1 })),
      false,
    );
  }

  private buildLake(
    group: THREE.Group,
    G: number,
    rnd: () => number,
    scatter: (n: number, a: number, b: number, o?: { tall?: boolean; margin?: number }) => { x: number; z: number }[],
    addInstanced: (g: THREE.BufferGeometry, m: THREE.Material, items: Item[], cast?: boolean, recv?: boolean) => THREE.InstancedMesh | null,
  ): void {
    // ice sheet: big disc around the field with a square hole
    const shape = new THREE.Shape();
    shape.absarc(0, 0, 105, 0, Math.PI * 2, false);
    const hole = new THREE.Path();
    const h = 53;
    hole.moveTo(-h, -h);
    hole.lineTo(h, -h);
    hole.lineTo(h, h);
    hole.lineTo(-h, h);
    hole.lineTo(-h, -h);
    shape.holes.push(hole);
    const iceGeo = new THREE.ShapeGeometry(shape, 48).rotateX(-Math.PI / 2);
    const iceMat = new THREE.MeshStandardMaterial({ color: 0x9fd2ea, roughness: 0.12, metalness: 0.15 });
    const ice = new THREE.Mesh(iceGeo, iceMat);
    ice.position.y = G + 0.03;
    ice.receiveShadow = true;
    group.add(ice);
    // ice cracks / pale patches
    const patchMat = new THREE.MeshStandardMaterial({ color: 0xe6f6ff, roughness: 0.4, transparent: true, opacity: 0.7, depthWrite: false });
    addInstanced(
      new THREE.CircleGeometry(1, 9).rotateX(-Math.PI / 2),
      patchMat,
      scatter(40, 56, 100, { margin: 6 }).map((p) => ({ x: p.x, y: G + 0.05, z: p.z, ry: rnd() * 6, sx: 2 + rnd() * 5, sy: 1, sz: 1 + rnd() * 3 })),
      false,
      true,
    );
    // fishing huts
    const hutColors = [0xd94a3a, 0x2f9fb0, 0xf2b632, 0x6c5ccf];
    const roofMat = new THREE.MeshStandardMaterial({ color: 0xf6f8fb, roughness: 0.8, flatShading: true });
    const doorMat = new THREE.MeshStandardMaterial({ color: 0x3b2a20, roughness: 0.9 });
    const winMat = new THREE.MeshStandardMaterial({ color: 0xffd27a, emissive: 0xffa640, emissiveIntensity: 0.9 });
    const bodyGeo = new THREE.BoxGeometry(2.2, 2, 2.6);
    const roofGeo = new THREE.CylinderGeometry(1.5, 1.5, 2.9, 3).rotateZ(Math.PI / 2).rotateX(Math.PI / 2);
    const huts = scatter(8, 60, 95, { tall: true, margin: 8 });
    huts.forEach((p, i) => {
      const hut = new THREE.Group();
      const bm = new THREE.MeshStandardMaterial({ color: hutColors[i % hutColors.length], roughness: 0.8, flatShading: true });
      const b = new THREE.Mesh(bodyGeo, bm);
      b.position.y = 1;
      b.castShadow = true;
      hut.add(b);
      const r = new THREE.Mesh(roofGeo, roofMat);
      r.rotation.y = Math.PI / 2;
      r.scale.set(1, 0.55, 1);
      r.position.y = 2.35;
      r.castShadow = true;
      hut.add(r);
      const d = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.3, 0.05), doorMat);
      d.position.set(0, 0.65, 1.32);
      hut.add(d);
      const w = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.5, 0.6), winMat);
      w.position.set(1.12, 1.25, 0);
      hut.add(w);
      hut.position.set(p.x, G, p.z);
      hut.rotation.y = Math.atan2(-p.x, -p.z) + (rnd() - 0.5) * 0.6;
      group.add(hut);
    });
    // reeds at the shoreline
    const reedMat = new THREE.MeshStandardMaterial({ color: 0x9a7a45, roughness: 0.9, flatShading: true });
    const reeds: Item[] = [];
    for (let c = 0; c < 46; c++) {
      const a = rnd() * Math.PI * 2;
      const R = 104 + rnd() * 6;
      const cx = Math.sin(a) * R;
      const cz = Math.cos(a) * R;
      for (let k = 0; k < 7; k++) {
        reeds.push({ x: cx + (rnd() - 0.5) * 2, y: G, z: cz + (rnd() - 0.5) * 2, ry: 0, rx: (rnd() - 0.5) * 0.3, rz: (rnd() - 0.5) * 0.3, sx: 1, sy: 0.8 + rnd() * 1.2, sz: 1 });
      }
    }
    addInstanced(new THREE.CylinderGeometry(0.03, 0.05, 1.6, 4).translate(0, 0.8, 0), reedMat, reeds, false);
    const tipMat = new THREE.MeshStandardMaterial({ color: 0x5a3b22, roughness: 0.9 });
    addInstanced(
      new THREE.CylinderGeometry(0.08, 0.08, 0.35, 5),
      tipMat,
      reeds.filter((_, i) => i % 2 === 0).map((r) => ({ ...r, y: r.y + 1.45 * r.sy, sy: 1 })),
      false,
    );
  }

  private buildBlizzard(
    group: THREE.Group,
    G: number,
    rnd: () => number,
    scatter: (n: number, a: number, b: number, o?: { tall?: boolean; margin?: number }) => { x: number; z: number }[],
  ): void {
    const postMat = new THREE.MeshStandardMaterial({ color: 0x5a3e2a, roughness: 0.9, flatShading: true });
    const boardMats = [
      new THREE.MeshStandardMaterial({ color: 0xffc22e, roughness: 0.7 }),
      new THREE.MeshStandardMaterial({ color: 0xe8423a, roughness: 0.7 }),
    ];
    const postGeo = new THREE.BoxGeometry(0.18, 2.6, 0.18).translate(0, 1.3, 0);
    const arrow = new THREE.Shape();
    arrow.moveTo(0, -0.22);
    arrow.lineTo(1.2, -0.22);
    arrow.lineTo(1.5, 0);
    arrow.lineTo(1.2, 0.22);
    arrow.lineTo(0, 0.22);
    arrow.lineTo(0, -0.22);
    const arrowGeo = new THREE.ExtrudeGeometry(arrow, { depth: 0.08, bevelEnabled: false });
    const snowCap = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 });
    const capGeo = new THREE.BoxGeometry(1.5, 0.08, 0.14).translate(0.72, 0.26, 0.04);
    const pts = scatter(14, 0, 70, { margin: 4 });
    pts.forEach((p, i) => {
      const s = new THREE.Group();
      const post = new THREE.Mesh(postGeo, postMat);
      post.castShadow = true;
      s.add(post);
      for (let k = 0; k < 2; k++) {
        const a = new THREE.Mesh(arrowGeo, boardMats[(i + k) % 2]);
        a.position.set(0, 1.8 + k * 0.55, 0);
        a.rotation.y = rnd() * 6.28;
        a.castShadow = true;
        const c = new THREE.Mesh(capGeo, snowCap);
        a.add(c);
        s.add(a);
      }
      s.position.set(p.x, G - 0.1, p.z);
      s.rotation.z = (rnd() - 0.5) * 0.15;
      group.add(s);
    });
    // marker posts with reflector tops lining the outer road
    const markerMat = new THREE.MeshStandardMaterial({ color: 0xff5a2a, emissive: 0xff3a10, emissiveIntensity: 0.8 });
    this.pulseMats.push({ mat: markerMat, base: 0.8, speed: 4, phase: 0 });
    const mGeo = new THREE.BoxGeometry(0.12, 1.8, 0.12).translate(0, 0.9, 0);
    for (let z = ARENA.minZ; z <= ARENA.maxZ; z += 8) {
      for (const sx of [-1, 1]) {
        const m = new THREE.Mesh(mGeo, markerMat);
        m.position.set(sx * (ARENA.maxX + 4), G, z);
        group.add(m);
      }
    }
  }

  private buildPeak(
    G: number,
    rnd: () => number,
    scatter: (n: number, a: number, b: number, o?: { tall?: boolean; margin?: number }) => { x: number; z: number }[],
    addInstanced: (g: THREE.BufferGeometry, m: THREE.Material, items: Item[], cast?: boolean, recv?: boolean) => THREE.InstancedMesh | null,
    snowMat: THREE.Material,
  ): void {
    const spireMat = new THREE.MeshStandardMaterial({ color: 0x4a3d5c, roughness: 0.9, flatShading: true });
    const spireGeo = new THREE.ConeGeometry(1, 1, 5, 1).translate(0, 0.5, 0);
    const spires: Item[] = scatter(60, 0, 120, { tall: true, margin: 6 }).map((p) => {
      const far = Math.hypot(p.x, p.z) > 75;
      const r = 1.5 + rnd() * (far ? 5 : 2.5);
      const h = (far ? 14 : 6) + rnd() * (far ? 26 : 10);
      return { x: p.x, y: G - 0.5, z: p.z, ry: rnd() * 6, rx: (rnd() - 0.5) * 0.2, rz: (rnd() - 0.5) * 0.2, sx: r, sy: h, sz: r * (0.7 + rnd() * 0.5) };
    });
    addInstanced(spireGeo, spireMat, spires, true, true);
    addInstanced(
      spireGeo.clone(),
      snowMat,
      spires.map((s) => ({ ...s, y: s.y + s.sy * 0.7 - 0.05, sx: s.sx * 0.31, sy: s.sy * 0.305, sz: s.sz * 0.31 })),
      false,
    );
    // glowing crystals
    const colors = [0x6ff3ff, 0xd24dff, 0xff7ad9];
    for (let c = 0; c < colors.length; c++) {
      const mat = new THREE.MeshStandardMaterial({
        color: colors[c], emissive: colors[c], emissiveIntensity: 1.2, roughness: 0.2, metalness: 0.1, flatShading: true,
      });
      this.pulseMats.push({ mat, base: 1.2, speed: 1.3 + c * 0.4, phase: c * 2 });
      const items: Item[] = [];
      for (const p of scatter(14, 0, 90, { margin: 3 })) {
        const n = 2 + ((rnd() * 4) | 0);
        for (let k = 0; k < n; k++) {
          const s = 0.3 + rnd() * 0.5;
          items.push({
            x: p.x + (rnd() - 0.5) * 1.6, y: G + s, z: p.z + (rnd() - 0.5) * 1.6, ry: rnd() * 6,
            rx: (rnd() - 0.5) * 0.7, rz: (rnd() - 0.5) * 0.7, sx: s, sy: s * (2.2 + rnd() * 1.5), sz: s,
          });
        }
      }
      addInstanced(new THREE.OctahedronGeometry(1, 0), mat, items, true);
    }
  }

  /* ------------------------------------------------------------------ falling snow */

  private buildSnowfall(zone: ZoneDef): void {
    if (this.flakes) {
      this.ctx.scene.remove(this.flakes);
      this.flakes.geometry.dispose();
      (this.flakes.material as THREE.Material).dispose();
      this.flakes = null;
    }
    const blizzard = zone.theme === 'blizzard';
    const count = Math.round(1500 + Math.min(1, Math.max(0, zone.snowfall)) * 6500);
    this.windX = blizzard ? 16 : 0.8 + zone.snowfall * 2;
    this.windZ = blizzard ? 5 : 0.4;
    this.fallSpeed = blizzard ? 5 : 1.4;
    this.sway = blizzard ? 1.5 : 0.6;
    const pos = new Float32Array(count * 3);
    const phase = new Float32Array(count);
    const cam = this.ctx.camera.position;
    for (let i = 0; i < count; i++) {
      pos[i * 3] = cam.x + (Math.random() - 0.5) * SNOW_BOX;
      pos[i * 3 + 1] = cam.y - 12 + Math.random() * SNOW_H;
      pos[i * 3 + 2] = cam.z + (Math.random() - 0.5) * SNOW_BOX;
      phase[i] = Math.random() * 100;
    }
    this.flakePos = pos;
    this.flakePhase = phase;
    const geo = new THREE.BufferGeometry();
    const attr = new THREE.BufferAttribute(pos, 3);
    attr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', attr);
    const mat = new THREE.PointsMaterial({
      size: blizzard ? 0.32 : 0.24,
      map: getSnowflakeTex(),
      transparent: true,
      opacity: blizzard ? 0.95 : 0.9,
      depthWrite: false,
      sizeAttenuation: true,
      color: 0xffffff,
    });
    this.flakes = new THREE.Points(geo, mat);
    this.flakes.frustumCulled = false;
    this.flakes.renderOrder = 5;
    this.ctx.scene.add(this.flakes);
  }

  /* ------------------------------------------------------------------ update */

  update(dt: number): void {
    this.time += dt;
    const t = this.time;
    const cam = this.ctx.camera.position;
    this.sky.position.copy(cam);

    for (let i = 0; i < this.swirls.length; i++) {
      const s = this.swirls[i];
      s.rotation.z += dt * (s.userData.spin as number);
    }
    for (let i = 0; i < this.pulseMats.length; i++) {
      const p = this.pulseMats[i];
      const k = 0.75 + 0.25 * Math.sin(t * p.speed + p.phase);
      const m = p.mat as THREE.MeshStandardMaterial;
      if (m.isMeshStandardMaterial) m.emissiveIntensity = p.base * k;
      else p.mat.opacity = p.base * k;
    }

    if (this.flakes) {
      const pos = this.flakePos;
      const ph = this.flakePhase;
      const n = ph.length;
      const halfB = SNOW_BOX / 2;
      const yMin = cam.y - 12;
      const gust = 1 + 0.35 * Math.sin(t * 0.7) + 0.15 * Math.sin(t * 2.3);
      const wx = this.windX * gust * dt;
      const wz = this.windZ * gust * dt;
      const fall = this.fallSpeed * dt;
      const sw = this.sway * dt;
      const cx = cam.x;
      const cz = cam.z;
      for (let i = 0; i < n; i++) {
        const i3 = i * 3;
        const p = ph[i];
        let x = pos[i3] + wx + Math.sin(t * 1.3 + p) * sw;
        let y = pos[i3 + 1] - fall * (0.7 + (p % 1) * 0.6);
        let z = pos[i3 + 2] + wz + Math.cos(t * 1.1 + p * 1.7) * sw;
        let dx = x - cx;
        if (dx > halfB) x -= SNOW_BOX;
        else if (dx < -halfB) x += SNOW_BOX;
        dx = z - cz;
        if (dx > halfB) z -= SNOW_BOX;
        else if (dx < -halfB) z += SNOW_BOX;
        if (y < yMin || y < -0.2) y += SNOW_H;
        else if (y > yMin + SNOW_H) y -= SNOW_H;
        pos[i3] = x;
        pos[i3 + 1] = y;
        pos[i3 + 2] = z;
      }
      (this.flakes.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }
  }
}
