import type { AudioAPI, SoundName } from '../core/types';

type PlayOpts = { volume?: number; pitch?: number };

const MIN_GAP = 0.035;
const MAX_VOICES = 6;
const MASTER_VOL = 0.8;

export class AudioSystem implements AudioAPI {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfx: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private _muted = false;

  private lastPlay = new Map<SoundName, number>();
  private voices = new Map<SoundName, number[]>();

  // engine
  private engGain: GainNode | null = null;
  private engO1: OscillatorNode | null = null;
  private engO2: OscillatorNode | null = null;
  private engFilter: BiquadFilterNode | null = null;
  // plowing
  private plowGain: GainNode | null = null;
  private plowFilter: BiquadFilterNode | null = null;
  // music
  private musicGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private musicOn = false;
  private musicWanted = false;
  private musicTimer: number | null = null;
  private nextBeat = 0;
  private beat = 0;

  get muted(): boolean {
    return this._muted;
  }
  set muted(v: boolean) {
    this._muted = v;
    if (this.ac && this.master) {
      this.master.gain.setTargetAtTime(v ? 0 : MASTER_VOL, this.ac.currentTime, 0.05);
    }
  }

  unlock(): void {
    try {
      if (!this.ac) {
        const Ctor: typeof AudioContext | undefined =
          window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!Ctor) return;
        this.ac = new Ctor();
        this.build();
      }
      if (this.ac.state === 'suspended') void this.ac.resume();
    } catch {
      /* ignore */
    }
  }

  private build(): void {
    const ac = this.ac!;
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 12;
    comp.ratio.value = 6;
    comp.attack.value = 0.003;
    comp.release.value = 0.2;
    comp.connect(ac.destination);
    this.master = ac.createGain();
    this.master.gain.value = this._muted ? 0 : MASTER_VOL;
    this.master.connect(comp);
    this.sfx = ac.createGain();
    this.sfx.gain.value = 0.9;
    this.sfx.connect(this.master);

    // white noise buffer 2s
    const len = ac.sampleRate * 2;
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;

    // engine
    this.engFilter = ac.createBiquadFilter();
    this.engFilter.type = 'lowpass';
    this.engFilter.frequency.value = 400;
    this.engFilter.Q.value = 3;
    this.engGain = ac.createGain();
    this.engGain.gain.value = 0;
    this.engO1 = ac.createOscillator();
    this.engO1.type = 'sawtooth';
    this.engO1.frequency.value = 45;
    this.engO2 = ac.createOscillator();
    this.engO2.type = 'square';
    this.engO2.frequency.value = 45;
    this.engO2.detune.value = 14;
    const o2g = ac.createGain();
    o2g.gain.value = 0.5;
    this.engO1.connect(this.engFilter);
    this.engO2.connect(o2g).connect(this.engFilter);
    this.engFilter.connect(this.engGain).connect(this.master);
    this.engO1.start();
    this.engO2.start();

    // plowing crunch
    const pn = ac.createBufferSource();
    pn.buffer = buf;
    pn.loop = true;
    this.plowFilter = ac.createBiquadFilter();
    this.plowFilter.type = 'bandpass';
    this.plowFilter.frequency.value = 1400;
    this.plowFilter.Q.value = 0.7;
    this.plowGain = ac.createGain();
    this.plowGain.gain.value = 0;
    // tremolo-ish crunch modulation
    const lfo = ac.createOscillator();
    lfo.frequency.value = 13;
    const lfoG = ac.createGain();
    lfoG.gain.value = 500;
    lfo.connect(lfoG).connect(this.plowFilter.frequency);
    lfo.start();
    pn.connect(this.plowFilter).connect(this.plowGain).connect(this.master);
    pn.start();

    // music bus
    this.musicGain = ac.createGain();
    this.musicGain.gain.value = 0;
    this.musicGain.connect(this.master);
    const wind = ac.createBufferSource();
    wind.buffer = buf;
    wind.loop = true;
    wind.playbackRate.value = 0.5;
    const wf = ac.createBiquadFilter();
    wf.type = 'bandpass';
    wf.frequency.value = 500;
    wf.Q.value = 1.4;
    const wlfo = ac.createOscillator();
    wlfo.frequency.value = 0.09;
    const wlfoG = ac.createGain();
    wlfoG.gain.value = 260;
    wlfo.connect(wlfoG).connect(wf.frequency);
    wlfo.start();
    this.windGain = ac.createGain();
    this.windGain.gain.value = 0.05;
    wind.connect(wf).connect(this.windGain).connect(this.musicGain);
    wind.start();

    if (this.musicWanted) this.setMusic(true);
  }

  /* ---------------------------------------------------------------- continuous */

  setEngine(throttle: number, speedFrac: number): void {
    const ac = this.ac;
    if (!ac || !this.engO1 || !this.engO2 || !this.engGain || !this.engFilter) return;
    const t = ac.currentTime;
    const th = Math.abs(throttle);
    const f = 42 + speedFrac * 55 + th * 12;
    this.engO1.frequency.setTargetAtTime(f, t, 0.12);
    this.engO2.frequency.setTargetAtTime(f * 1.005, t, 0.12);
    this.engFilter.frequency.setTargetAtTime(260 + speedFrac * 700 + th * 400, t, 0.1);
    const g = th < 0.01 && speedFrac < 0.01 ? 0.025 : 0.05 + th * 0.06 + speedFrac * 0.04;
    this.engGain.gain.setTargetAtTime(g, t, 0.15);
  }

  setPlowing(intensity: number): void {
    const ac = this.ac;
    if (!ac || !this.plowGain || !this.plowFilter) return;
    const i = Math.max(0, Math.min(1, intensity));
    this.plowGain.gain.setTargetAtTime(i * 0.28, ac.currentTime, 0.06);
  }

  setMusic(on: boolean): void {
    this.musicWanted = on;
    const ac = this.ac;
    if (!ac || !this.musicGain) return;
    if (on === this.musicOn) return;
    this.musicOn = on;
    const t = ac.currentTime;
    if (on) {
      this.musicGain.gain.cancelScheduledValues(t);
      this.musicGain.gain.setTargetAtTime(0.5, t, 1.0);
      this.nextBeat = t + 0.1;
      if (this.musicTimer === null) this.musicTimer = window.setInterval(() => this.schedule(), 100);
    } else {
      this.musicGain.gain.cancelScheduledValues(t);
      this.musicGain.gain.setTargetAtTime(0, t, 0.6);
      if (this.musicTimer !== null) {
        window.clearInterval(this.musicTimer);
        this.musicTimer = null;
      }
    }
  }

  private static CHORDS = [
    [57, 60, 64, 69], // Am / F / C / G
    [53, 57, 60, 65],
    [48, 55, 60, 64],
    [55, 59, 62, 67],
  ];
  private static MELODY = [0, 2, 1, 3, 2, 1, 3, 0];

  private schedule(): void {
    const ac = this.ac;
    if (!ac || !this.musicGain || !this.musicOn) return;
    const beatLen = 0.5; // 120 bpm eighths -> gentle
    while (this.nextBeat < ac.currentTime + 0.3) {
      const b = this.beat;
      const t = this.nextBeat;
      const chord = AudioSystem.CHORDS[Math.floor(b / 8) % 4];
      if (b % 8 === 0) {
        for (const n of chord) this.pad(midi(n - 12), t, beatLen * 8);
      }
      // sparse music-box arpeggio
      if (b % 2 === 0 || Math.random() < 0.25) {
        if (Math.random() < 0.8) {
          const idx = AudioSystem.MELODY[(b + Math.floor(b / 16)) % 8];
          const up = Math.random() < 0.3 ? 12 : 0;
          this.musicBox(midi(chord[idx] + 12 + up), t);
        }
      }
      this.nextBeat += beatLen;
      this.beat++;
    }
  }

  private pad(freq: number, t: number, dur: number): void {
    const ac = this.ac!;
    const g = ac.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.025, t + 1.2);
    g.gain.setValueAtTime(0.025, t + dur - 1.0);
    g.gain.linearRampToValueAtTime(0, t + dur + 0.6);
    const f = ac.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 900;
    f.connect(g).connect(this.musicGain!);
    for (const det of [-7, 7]) {
      const o = ac.createOscillator();
      o.type = 'triangle';
      o.frequency.value = freq;
      o.detune.value = det;
      o.connect(f);
      o.start(t);
      o.stop(t + dur + 0.7);
    }
  }

  private musicBox(freq: number, t: number): void {
    const ac = this.ac!;
    const g = ac.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.045, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 1.4);
    g.connect(this.musicGain!);
    const o = ac.createOscillator();
    o.type = 'sine';
    o.frequency.value = freq;
    o.connect(g);
    const o2 = ac.createOscillator();
    o2.type = 'sine';
    o2.frequency.value = freq * 3.01;
    const g2 = ac.createGain();
    g2.gain.value = 0.18;
    o2.connect(g2).connect(g);
    o.start(t);
    o2.start(t);
    o.stop(t + 1.5);
    o2.stop(t + 1.5);
  }

  /* ---------------------------------------------------------------- one-shots */

  play(name: SoundName, opts?: PlayOpts): void {
    const ac = this.ac;
    if (!ac || !this.sfx || this._muted) return;
    const now = ac.currentTime;
    const last = this.lastPlay.get(name) ?? -1;
    if (now - last < MIN_GAP) return;
    let v = this.voices.get(name);
    if (!v) {
      v = [];
      this.voices.set(name, v);
    }
    // drop finished voices
    for (let i = v.length - 1; i >= 0; i--) if (v[i] < now) v.splice(i, 1);
    if (v.length >= MAX_VOICES) return;
    this.lastPlay.set(name, now);
    const vol = opts?.volume ?? 1;
    const p = opts?.pitch ?? 1;
    let dur = 0.3;
    try {
      dur = this.synth(name, now, vol, p);
    } catch {
      /* ignore */
    }
    v.push(now + dur);
  }

  private out(vol: number): GainNode {
    const g = this.ac!.createGain();
    g.gain.value = vol;
    g.connect(this.sfx!);
    return g;
  }

  private tone(
    type: OscillatorType, f0: number, f1: number, t: number, dur: number, vol: number,
    dest: AudioNode, attack = 0.005, curve: 'exp' | 'lin' = 'exp',
  ): void {
    const ac = this.ac!;
    const o = ac.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) {
      if (curve === 'exp') o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
      else o.frequency.linearRampToValueAtTime(f1, t + dur);
    }
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(
    t: number, dur: number, vol: number, dest: AudioNode, type: BiquadFilterType, f0: number, f1: number,
    q = 1, attack = 0.003, rate = 1,
  ): void {
    const ac = this.ac!;
    const src = ac.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = rate;
    const f = ac.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(dest);
    src.start(t, Math.random() * 1.5);
    src.stop(t + dur + 0.02);
  }

  private bell(freq: number, t: number, dur: number, vol: number, dest: AudioNode): void {
    this.tone('sine', freq, freq, t, dur, vol, dest, 0.003);
    this.tone('sine', freq * 2.76, freq * 2.76, t, dur * 0.5, vol * 0.3, dest, 0.002);
    this.tone('triangle', freq * 2, freq * 2, t, dur * 0.35, vol * 0.25, dest, 0.002);
  }

  /** Returns duration in seconds. */
  private synth(name: SoundName, t: number, vol: number, p: number): number {
    const o = this.out(vol);
    switch (name) {
      case 'launch':
        this.tone('triangle', 180 * p, 720 * p, t, 0.28, 0.35, o, 0.01);
        this.noise(t, 0.35, 0.35, o, 'bandpass', 600, 3200, 1.2, 0.02);
        this.tone('sine', 90, 50, t, 0.18, 0.4, o);
        return 0.35;
      case 'hit':
        this.noise(t, 0.12, 0.5, o, 'lowpass', 2400 * p, 500, 0.8);
        this.tone('sine', 220 * p, 110 * p, t, 0.1, 0.35, o);
        return 0.12;
      case 'kill':
        this.noise(t, 0.25, 0.5, o, 'bandpass', 1800 * p, 400, 0.9);
        this.tone('square', 520 * p, 260 * p, t, 0.12, 0.12, o);
        this.tone('sine', 780 * p, 1560 * p, t + 0.05, 0.12, 0.15, o);
        return 0.25;
      case 'strike': {
        const notes = [523, 659, 784, 1047, 1319];
        notes.forEach((n, i) => this.bell(n * p, t + i * 0.06, 0.5, 0.22, o));
        this.noise(t, 0.4, 0.3, o, 'highpass', 3000, 6000, 0.7);
        return 0.8;
      }
      case 'coin':
        this.tone('square', 988 * p, 988 * p, t, 0.07, 0.12, o, 0.002);
        this.bell(1319 * p, t + 0.06, 0.35, 0.22, o);
        return 0.4;
      case 'baseHit':
        this.tone('sine', 110, 40, t, 0.4, 0.8, o, 0.004);
        this.noise(t, 0.3, 0.45, o, 'lowpass', 900, 120, 1);
        this.tone('square', 70, 45, t, 0.15, 0.12, o);
        return 0.4;
      case 'plowHit':
        this.tone('square', 340 * p, 300 * p, t, 0.25, 0.14, o, 0.002);
        this.tone('square', 512 * p, 470 * p, t, 0.22, 0.1, o, 0.002);
        this.tone('triangle', 1210 * p, 1180 * p, t, 0.3, 0.12, o, 0.001);
        this.noise(t, 0.08, 0.4, o, 'highpass', 2500, 2500, 1);
        return 0.3;
      case 'burst':
        this.noise(t, 0.45, 0.7, o, 'lowpass', 3000 * p, 300, 0.7, 0.004);
        this.noise(t, 0.2, 0.3, o, 'bandpass', 900, 600, 2, 0.002, 0.7);
        this.tone('sine', 140 * p, 60, t, 0.2, 0.4, o);
        return 0.45;
      case 'explosion':
        this.noise(t, 0.9, 0.9, o, 'lowpass', 2200, 90, 0.8, 0.005, 0.6);
        this.tone('sine', 120, 30, t, 0.7, 0.9, o, 0.004);
        this.tone('sawtooth', 80, 35, t, 0.35, 0.15, o);
        return 0.9;
      case 'waveStart':
        this.tone('sawtooth', 220, 220, t, 0.25, 0.12, o, 0.02);
        this.tone('sawtooth', 330, 330, t + 0.18, 0.35, 0.12, o, 0.02);
        this.tone('square', 440, 440, t + 0.36, 0.5, 0.1, o, 0.02);
        this.tone('sine', 110, 110, t, 0.8, 0.3, o, 0.02);
        return 0.9;
      case 'waveClear': {
        const notes = [523, 659, 784, 1047, 784, 1047];
        notes.forEach((n, i) => this.bell(n, t + i * 0.09, 0.55, 0.25, o));
        return 1.1;
      }
      case 'victory': {
        const notes = [523, 659, 784, 1047, 1319, 1568];
        notes.forEach((n, i) => this.bell(n, t + i * 0.12, 0.7, 0.25, o));
        [523, 659, 784].forEach((n) => this.tone('triangle', n, n, t + 0.8, 1.4, 0.12, o, 0.05));
        return 2.3;
      }
      case 'gameOver': {
        const notes = [392, 349, 311, 262];
        notes.forEach((n, i) => this.tone('triangle', n, n * 0.97, t + i * 0.28, 0.5, 0.25, o, 0.01));
        this.tone('sawtooth', 130, 65, t + 1.1, 1.2, 0.12, o, 0.05);
        return 2.3;
      }
      case 'boss':
        for (let i = 0; i < 3; i++) {
          this.tone('sawtooth', 440, 660, t + i * 0.35, 0.17, 0.14, o, 0.01, 'lin');
          this.tone('sawtooth', 660, 440, t + i * 0.35 + 0.17, 0.17, 0.14, o, 0.01, 'lin');
        }
        this.tone('sine', 55, 45, t, 1.1, 0.4, o, 0.05);
        return 1.1;
      case 'roar': {
        const ac = this.ac!;
        const lfo = ac.createOscillator();
        lfo.frequency.value = 28;
        const lg = ac.createGain();
        lg.gain.value = 30;
        const osc = ac.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(110 * p, t);
        osc.frequency.linearRampToValueAtTime(150 * p, t + 0.25);
        osc.frequency.exponentialRampToValueAtTime(60 * p, t + 0.9);
        lfo.connect(lg).connect(osc.frequency);
        const f = ac.createBiquadFilter();
        f.type = 'lowpass';
        f.frequency.value = 800;
        f.Q.value = 4;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.35, t + 0.08);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
        osc.connect(f).connect(g).connect(o);
        osc.start(t);
        lfo.start(t);
        osc.stop(t + 1);
        lfo.stop(t + 1);
        this.noise(t, 0.9, 0.25, o, 'bandpass', 500, 250, 2);
        return 1;
      }
      case 'stall':
        this.tone('sawtooth', 300, 60, t, 0.8, 0.18, o, 0.01);
        this.tone('square', 200, 40, t + 0.1, 0.7, 0.08, o, 0.01);
        this.noise(t + 0.2, 0.5, 0.2, o, 'bandpass', 1500, 300, 3);
        return 0.9;
      case 'turbo':
        this.tone('sawtooth', 120, 600, t, 0.5, 0.15, o, 0.02);
        this.noise(t, 0.6, 0.35, o, 'bandpass', 400, 4000, 1.5, 0.05);
        return 0.6;
      case 'freeze':
        for (let i = 0; i < 6; i++) {
          const f = (2000 + Math.random() * 2500) * p;
          this.tone('sine', f, f * 1.02, t + i * 0.04, 0.4, 0.07, o, 0.002);
        }
        this.noise(t, 0.6, 0.18, o, 'highpass', 5000, 9000, 1, 0.05);
        return 0.65;
      case 'fireball':
        for (let i = 0; i < 7; i++) {
          this.noise(t + Math.random() * 0.3, 0.05, 0.3, o, 'bandpass', 1500 + Math.random() * 3000, 1500, 4);
        }
        this.noise(t, 0.45, 0.35, o, 'lowpass', 1200 * p, 400, 1, 0.03);
        this.tone('sine', 200 * p, 90 * p, t, 0.35, 0.2, o, 0.02);
        return 0.45;
      case 'countdown':
        this.tone('square', 880 * p, 880 * p, t, 0.14, 0.12, o, 0.002);
        this.tone('sine', 880 * p, 880 * p, t, 0.2, 0.2, o, 0.002);
        return 0.2;
      case 'click':
        this.tone('square', 1400 * p, 900 * p, t, 0.04, 0.08, o, 0.001);
        return 0.05;
      case 'buy':
        this.tone('square', 660, 660, t, 0.08, 0.1, o, 0.002);
        this.bell(990, t + 0.07, 0.3, 0.22, o);
        this.bell(1320, t + 0.14, 0.4, 0.2, o);
        return 0.55;
      case 'error':
        this.tone('square', 180, 160, t, 0.12, 0.13, o, 0.003);
        this.tone('square', 140, 120, t + 0.13, 0.18, 0.13, o, 0.003);
        return 0.32;
      default:
        return 0.1;
    }
  }
}

function midi(n: number): number {
  return 440 * Math.pow(2, (n - 69) / 12);
}
