import './ui.css';
import type { GameContext, HudState, RunSummary, SoundName, UIAPI, UIHandlers } from '../core/types';
import { MIN_BALL_RADIUS } from '../core/types';
import { UPGRADES, type UpgradeCategory, type UpgradeDef } from '../config/upgrades';
import { ZONES } from '../config/zones';
import { ENEMIES, type EnemyType } from '../config/enemies';

type ScreenName = 'menu' | 'zones' | 'garage' | 'howto' | 'pause' | 'result';

const hex = (n: number) => `#${n.toString(16).padStart(6, '0')}`;
const fmt = (n: number) => Math.floor(n).toLocaleString('en-US');

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  if (parent) parent.appendChild(e);
  return e;
}

const CATEGORIES: { id: UpgradeCategory; label: string; icon: string }[] = [
  { id: 'plow', label: 'Plow', icon: '🚜' },
  { id: 'ball', label: 'Snowball', icon: '⚪' },
  { id: 'defense', label: 'Defense', icon: '🛡️' },
  { id: 'special', label: 'Specials', icon: '✨' },
];

const ENEMY_ICON: Record<EnemyType, string> = {
  snowman: '⛄', penguin: '🐧', imp: '🔥', golem: '🧊', rival: '🚜', kingSnowman: '👑', yeti: '🦍',
};

const CONTROLS: [string[], string][] = [
  [['W', '↑'], 'Accelerate'],
  [['S', '↓'], 'Brake / reverse'],
  [['A', 'D'], 'Steer'],
  [['SPACE'], 'Launch snowball'],
  [['SHIFT'], 'Turbo boost (upgrade)'],
  [['ESC', 'P'], 'Pause'],
  [['M'], 'Mute sound'],
];

function tierName(r: number): string {
  if (r < 0.6) return 'Snowball';
  if (r < 1.0) return 'Boulder';
  if (r < 1.6) return 'Avalanche';
  if (r < 2.4) return 'Glacier';
  return 'SNOWPOCALYPSE';
}
function tierIndex(r: number): number {
  return r < 0.6 ? 0 : r < 1.0 ? 1 : r < 1.6 ? 2 : r < 2.4 ? 3 : 4;
}

interface CardRefs {
  def: UpgradeDef;
  root: HTMLElement;
  pips: HTMLElement[];
  cur: HTMLElement;
  next: HTMLElement;
  arrow: HTMLElement;
  buy: HTMLButtonElement;
}

const GAUGE_R = 46;
const GAUGE_C = 2 * Math.PI * GAUGE_R;

export class UI implements UIAPI {
  private ctx: GameContext;
  private handlers: UIHandlers;
  private rootEl: HTMLElement;
  private screens = {} as Record<ScreenName, HTMLElement>;
  private current: ScreenName | null = null;
  private shownAt = 0;

  // menu
  private menuCoins!: HTMLElement;
  private menuStats!: HTMLElement;
  private muteBtns: HTMLButtonElement[] = [];
  private resetBtn!: HTMLButtonElement;
  private resetArmed = 0;

  // zones
  private zoneGrid!: HTMLElement;

  // garage / shop
  private shopTitle!: HTMLElement;
  private shopSub!: HTMLElement;
  private shopCoins!: HTMLElement;
  private shopWave!: HTMLElement;
  private shopFooter!: HTMLElement;
  private shopBack!: HTMLButtonElement;
  private shopStart!: HTMLButtonElement;
  private shopHint!: HTMLElement;
  private cards: CardRefs[] = [];
  private shopContinue: (() => void) | null = null;
  private garageBack: 'menu' | 'quit' = 'menu';

  // result
  private resultPanel!: HTMLElement;

  // hud
  private hud!: HTMLElement;
  private hudVisible = false;
  private h = {} as {
    zone: HTMLElement; wave: HTMLElement; enemies: HTMLElement;
    boss: HTMLElement; bossName: HTMLElement; bossFill: HTMLElement; bossHp: HTMLElement;
    coins: HTMLElement; coinBox: HTMLElement;
    plowFill: HTMLElement; plowTxt: HTMLElement; baseFill: HTMLElement; baseTxt: HTMLElement; baseBar: HTMLElement;
    gauge: HTMLElement; ring: SVGCircleElement; radius: HTMLElement; tier: HTMLElement; launch: HTMLElement;
    turbo: HTMLElement; turboFill: HTMLElement;
    snowFill: HTMLElement; snowTxt: HTMLElement;
    stall: HTMLElement; stallTxt: HTMLElement;
    count: HTMLElement; hint: HTMLElement;
  };
  private last = {
    zone: '', wave: -1, total: -1, enemies: -1, bossOn: false, bossName: '', bossHp: -1, bossFrac: -1,
    coins: -1, plowHp: -1, plowMax: -1, baseHp: -1, baseMax: -1, baseLow: false,
    ballR: -1, ballFrac: -1, tier: -1, ready: false, full: false, turbo: -2, turboFull: false,
    snow: -1, stall: -1, count: -1,
  };
  private hintTimer = 0;

  // fx
  private vignette!: HTMLElement;
  private toastBox!: HTMLElement;
  private bigBox!: HTMLElement;

  constructor(ctx: GameContext, root: HTMLElement, handlers: UIHandlers) {
    this.ctx = ctx;
    this.handlers = handlers;
    this.rootEl = el('div', 'ss-root', undefined, root);

    this.vignette = el('div', 'ss-vignette', undefined, this.rootEl);
    this.buildHud();
    this.buildMenu();
    this.buildHowTo();
    this.buildZones();
    this.buildShop();
    this.buildPause();
    this.buildResult();
    this.toastBox = el('div', 'ss-toasts', undefined, this.rootEl);
    this.bigBox = el('div', 'ss-bigtoasts', undefined, this.rootEl);

    ctx.progression.onChange(() => this.refreshProgress());
    ctx.events.on('baseDamaged', ({ amount }) => this.pulse(amount >= 15 ? 'heavy' : 'base'));
    ctx.events.on('plowDamaged', () => this.pulse('plow'));

    window.addEventListener('keydown', (e) => this.onKey(e));
    this.refreshProgress();
  }

  /* ================================================================== helpers */

  private sfx(name: SoundName): void {
    this.ctx.audio?.play(name);
  }

  private btn(label: string, cls: string, onClick: () => void, parent?: HTMLElement, sound: SoundName | null = 'click'): HTMLButtonElement {
    const b = el('button', `ss-btn ${cls}`, undefined, parent);
    b.type = 'button';
    b.innerHTML = label;
    b.addEventListener('click', () => {
      if (sound) this.sfx(sound);
      onClick();
    });
    return b;
  }

  private screen(name: ScreenName, cls: string): HTMLElement {
    const s = el('div', `ss-screen ${cls}`, undefined, this.rootEl);
    this.screens[name] = s;
    return s;
  }

  private show(name: ScreenName): void {
    for (const k in this.screens) {
      const s = this.screens[k as ScreenName];
      s.classList.toggle('show', k === name);
      s.setAttribute('aria-hidden', k === name ? 'false' : 'true');
    }
    this.current = name;
    this.shownAt = performance.now();
    if (name === 'result') {
      // Stale in-game toasts would sit on top of the end screens.
      this.bigBox?.replaceChildren();
      this.toastBox?.replaceChildren();
    }
    const target = this.screens[name].querySelector<HTMLButtonElement>('[data-primary]:not(.hidden)');
    const a = document.activeElement as HTMLElement | null;
    if (a && a.blur) a.blur();
    if (target) setTimeout(() => this.current === name && target.focus({ preventScroll: true }), 30);
  }

  private controlsList(parent: HTMLElement): HTMLElement {
    const list = el('div', 'ss-controls', undefined, parent);
    for (const [keys, label] of CONTROLS) {
      const row = el('div', 'ss-ctrl-row', undefined, list);
      const k = el('div', 'ss-keys', undefined, row);
      keys.forEach((key, i) => {
        if (i) el('span', 'ss-key-sep', '/', k);
        el('kbd', 'ss-kbd', key, k);
      });
      el('span', 'ss-ctrl-label', label, row);
    }
    return list;
  }

  private coinPill(parent: HTMLElement, cls = ''): HTMLElement {
    const pill = el('div', `ss-coinpill ${cls}`, undefined, parent);
    el('span', 'ss-coin', undefined, pill);
    return el('span', 'ss-coin-val', '0', pill);
  }

  private refreshMute(): void {
    const muted = !!this.ctx.audio?.muted;
    for (const b of this.muteBtns) {
      b.innerHTML = muted ? '🔇 SOUND: OFF' : '🔊 SOUND: ON';
      b.classList.toggle('off', muted);
    }
  }

  private refreshProgress(): void {
    const p = this.ctx.progression;
    const c = fmt(p.coins);
    this.menuCoins.textContent = c;
    this.shopCoins.textContent = c;
    const unlocked = Math.min(ZONES.length, p.data.unlockedZones);
    this.menuStats.textContent = `Zones ${unlocked}/${ZONES.length}  ·  ${fmt(p.data.totalKills)} enemies flattened`;
    this.refreshCards();
    if (this.current === 'zones') this.renderZones();
  }

  /* ================================================================== keyboard */

  private onKey(e: KeyboardEvent): void {
    if (e.code === 'KeyM') setTimeout(() => this.refreshMute(), 0);
    const name = this.current;
    if (!name) return;
    const scr = this.screens[name];
    const code = e.code;
    const isActivate = code === 'Enter' || code === 'NumpadEnter' || code === 'Space';
    if (isActivate) {
      e.preventDefault();
      if (e.repeat || performance.now() - this.shownAt < 450) return;
      if (name === 'garage' && this.shopContinue && code !== 'Space') {
        this.shopStart.click();
        return;
      }
      const a = document.activeElement;
      if (a instanceof HTMLButtonElement && scr.contains(a)) {
        a.click();
      } else if (code !== 'Space') {
        scr.querySelector<HTMLButtonElement>('[data-primary]:not(.hidden)')?.click();
      }
      return;
    }
    const nav: Record<string, number> = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1, Tab: e.shiftKey ? -1 : 1 };
    const dir = nav[code];
    if (!dir) return;
    e.preventDefault();
    const btns = Array.from(scr.querySelectorAll<HTMLButtonElement>('button')).filter((b) => b.offsetParent !== null && !b.disabled);
    if (!btns.length) return;
    let i = btns.indexOf(document.activeElement as HTMLButtonElement);
    i = i < 0 ? (dir > 0 ? 0 : btns.length - 1) : (i + dir + btns.length) % btns.length;
    const next = btns[i];
    next.focus();
    next.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  /* ================================================================== main menu */

  private buildMenu(): void {
    const s = this.screen('menu', 'ss-menu');
    const panel = el('div', 'ss-menu-panel ss-glass ss-icicles', undefined, s);
    const title = el('h1', 'ss-title', undefined, panel);
    el('span', 'ss-title-a', 'SNOWPLOW', title);
    el('span', 'ss-title-b', 'SIEGE', title);
    el('p', 'ss-tagline', 'Plow the snow. Roll the boulder. Save the cocoa.', panel);
    this.menuCoins = this.coinPill(panel, 'ss-menu-coins');

    const btns = el('div', 'ss-menu-btns', undefined, panel);
    this.btn('▶ PLAY', 'ss-primary ss-big', () => this.showZoneSelect(), btns).dataset.primary = '1';
    this.btn('🔧 GARAGE', 'ss-ice', () => this.openGarage('menu'), btns);
    this.btn('❓ HOW TO PLAY', 'ss-ice', () => this.show('howto'), btns);
    const row = el('div', 'ss-menu-row', undefined, btns);
    const mute = this.btn('', 'ss-ice ss-small', () => {
      this.handlers.onToggleMute();
      this.refreshMute();
    }, row);
    this.muteBtns.push(mute);
    this.resetBtn = this.btn('🗑 RESET SAVE', 'ss-ice ss-small ss-danger', () => this.onResetClick(), row);

    this.menuStats = el('div', 'ss-menu-stats', '', panel);
    el('div', 'ss-credits', 'A tiny winter toy-world · Three.js · procedural everything', panel);
    this.refreshMute();
  }

  private onResetClick(): void {
    const now = performance.now();
    if (now - this.resetArmed < 3000) {
      this.resetArmed = 0;
      this.resetBtn.innerHTML = '🗑 RESET SAVE';
      this.resetBtn.classList.remove('armed');
      this.handlers.onResetSave();
      this.refreshProgress();
      this.toast('Save data reset. Fresh snow!', 'info');
      return;
    }
    this.resetArmed = now;
    this.resetBtn.innerHTML = '⚠ CLICK AGAIN TO CONFIRM';
    this.resetBtn.classList.add('armed');
    setTimeout(() => {
      if (performance.now() - this.resetArmed >= 2900) {
        this.resetBtn.innerHTML = '🗑 RESET SAVE';
        this.resetBtn.classList.remove('armed');
      }
    }, 3050);
  }

  /* ================================================================== how to play */

  private buildHowTo(): void {
    const s = this.screen('howto', 'ss-center ss-dim');
    const panel = el('div', 'ss-panel ss-glass ss-howto ss-icicles', undefined, s);
    el('h2', 'ss-h2', 'HOW TO PLAY', panel);
    const cols = el('div', 'ss-howto-cols', undefined, panel);
    const left = el('div', 'ss-howto-col', undefined, cols);
    el('h3', 'ss-h3', 'Controls', left);
    this.controlsList(left);
    const right = el('div', 'ss-howto-col', undefined, cols);
    el('h3', 'ss-h3', 'The Plan', right);
    const steps: [string, string, string][] = [
      ['🚜', 'Plow snow', 'Drive through deep snow — your blade packs it into a snowball that grows as you plow.'],
      ['🎳', 'Launch it', 'Press SPACE to roll it like a bowling ball. Bigger balls hit harder and plow through crowds.'],
      ['💥', 'STRIKE!', 'Flatten 3+ enemies with one ball for a STRIKE coin bonus. 5+ is an AVALANCHE.'],
      ['🧊', 'Mind the armor', 'Ice golems and bosses shrug off pebbles. Bring a Boulder or bigger.'],
      ['☕', 'Protect the cabin', 'Enemies march from the north toward your cocoa cabin. If it falls, the run ends.'],
      ['🪙', 'Upgrade', 'Coins from kills buy permanent upgrades in the Garage and between waves.'],
    ];
    const list = el('div', 'ss-steps', undefined, right);
    for (const [icon, t, d] of steps) {
      const row = el('div', 'ss-step', undefined, list);
      el('div', 'ss-step-icon', icon, row);
      const tx = el('div', 'ss-step-text', undefined, row);
      el('b', '', t, tx);
      el('span', '', d, tx);
    }
    const foot = el('div', 'ss-panel-foot', undefined, panel);
    this.btn('◀ BACK', 'ss-primary', () => this.showMainMenu(), foot).dataset.primary = '1';
  }

  /* ================================================================== zone select */

  private buildZones(): void {
    const s = this.screen('zones', 'ss-center ss-dim');
    const panel = el('div', 'ss-panel ss-glass ss-zones ss-icicles', undefined, s);
    el('h2', 'ss-h2', 'CHOOSE YOUR BATTLEFIELD', panel);
    this.zoneGrid = el('div', 'ss-zone-grid', undefined, panel);
    const foot = el('div', 'ss-panel-foot', undefined, panel);
    this.btn('◀ BACK', 'ss-ice', () => this.showMainMenu(), foot);
  }

  private renderZones(): void {
    const p = this.ctx.progression;
    this.zoneGrid.textContent = '';
    let firstPlayable: HTMLButtonElement | null = null;
    ZONES.forEach((z, i) => {
      const unlocked = p.isZoneUnlocked(i);
      const rec = p.zoneRecord(z.id);
      const card = el('button', `ss-zone ${unlocked ? '' : 'locked'} ${rec.cleared ? 'cleared' : ''}`, undefined, this.zoneGrid);
      card.type = 'button';
      card.style.setProperty('--sky-top', hex(z.skyTop));
      card.style.setProperty('--sky-bottom', hex(z.skyBottom));
      el('div', 'ss-zone-num', String(i + 1), card);
      const top = el('div', 'ss-zone-top', undefined, card);
      el('div', 'ss-zone-name', z.name, top);
      el('div', 'ss-zone-tag', z.tagline, top);
      const bottom = el('div', 'ss-zone-bottom', undefined, card);
      el('div', 'ss-zone-stat', `🌊 ${z.waves.length} waves`, bottom);
      el('div', 'ss-zone-stat', rec.bestWave > 0 ? `🏁 Best: wave ${Math.min(rec.bestWave, z.waves.length)}/${z.waves.length}` : '🏁 Best: —', bottom);
      el('div', 'ss-zone-stat ss-zone-reward', `🪙 ${fmt(rec.cleared ? Math.round(z.clearReward * 0.4) : z.clearReward)} clear reward`, bottom);
      if (rec.cleared) el('div', 'ss-zone-badge', '✓ CLEARED', card);
      if (!unlocked) {
        const lock = el('div', 'ss-zone-lock', undefined, card);
        el('div', 'ss-lock-icon', '🔒', lock);
        el('div', 'ss-lock-text', `Clear ${ZONES[i - 1]?.name ?? 'the previous zone'} to unlock`, lock);
      }
      card.addEventListener('click', () => {
        if (!unlocked) {
          this.sfx('error');
          card.classList.remove('shake');
          void card.offsetWidth;
          card.classList.add('shake');
          return;
        }
        this.sfx('click');
        this.handlers.onStartZone(i);
      });
      if (unlocked && !rec.cleared && !firstPlayable) firstPlayable = card;
      if (unlocked && i === p.data.unlockedZones - 1) firstPlayable = card;
    });
    const fp = firstPlayable as HTMLButtonElement | null;
    this.zoneGrid.querySelectorAll('[data-primary]').forEach((n) => delete (n as HTMLElement).dataset.primary);
    if (fp) fp.dataset.primary = '1';
  }

  /* ================================================================== garage / shop */

  private buildShop(): void {
    const s = this.screen('garage', 'ss-center ss-dim');
    const panel = el('div', 'ss-panel ss-glass ss-shop ss-icicles', undefined, s);
    const head = el('div', 'ss-shop-head', undefined, panel);
    const titles = el('div', 'ss-shop-titles', undefined, head);
    this.shopTitle = el('h2', 'ss-h2', 'GARAGE', titles);
    this.shopSub = el('div', 'ss-shop-sub', '', titles);
    this.shopCoins = this.coinPill(head, 'ss-shop-coins');
    this.shopWave = el('div', 'ss-wave-preview', undefined, panel);

    const body = el('div', 'ss-shop-body', undefined, panel);
    for (const cat of CATEGORIES) {
      const sec = el('section', `ss-cat ss-cat-${cat.id}`, undefined, body);
      const h = el('h3', 'ss-cat-title', undefined, sec);
      el('span', 'ss-cat-icon', cat.icon, h);
      el('span', '', cat.label, h);
      const grid = el('div', 'ss-card-grid', undefined, sec);
      for (const def of UPGRADES.filter((u) => u.category === cat.id)) this.cards.push(this.buildCard(def, grid));
    }

    this.shopFooter = el('div', 'ss-panel-foot ss-shop-foot', undefined, panel);
    this.shopBack = this.btn('◀ BACK', 'ss-ice', () => {
      if (this.garageBack === 'quit') this.handlers.onQuitToMenu();
      else this.showMainMenu();
    }, this.shopFooter);
    this.shopHint = el('div', 'ss-foot-hint', 'Press ENTER to start', this.shopFooter);
    this.shopStart = this.btn('START WAVE ▶', 'ss-primary ss-big', () => {
      const fn = this.shopContinue;
      this.shopContinue = null;
      if (fn) fn();
    }, this.shopFooter);
  }

  private buildCard(def: UpgradeDef, parent: HTMLElement): CardRefs {
    const root = el('div', 'ss-card', undefined, parent);
    root.dataset.id = def.id;
    el('div', 'ss-card-icon', def.icon, root);
    const info = el('div', 'ss-card-info', undefined, root);
    el('div', 'ss-card-name', def.name, info);
    el('div', 'ss-card-desc', def.description, info);
    const pipsEl = el('div', 'ss-pips', undefined, info);
    const pips: HTMLElement[] = [];
    for (let i = 0; i < def.maxLevel; i++) pips.push(el('span', 'ss-pip', undefined, pipsEl));
    const val = el('div', 'ss-card-val', undefined, info);
    const cur = el('span', 'ss-val-cur', '', val);
    const arrow = el('span', 'ss-val-arrow', '→', val);
    const next = el('span', 'ss-val-next', '', val);
    const buy = el('button', 'ss-btn ss-buy', '', root);
    buy.type = 'button';
    buy.addEventListener('click', () => this.onBuy(def, root));
    return { def, root, pips, cur, next, arrow, buy };
  }

  private onBuy(def: UpgradeDef, card: HTMLElement): void {
    const p = this.ctx.progression;
    if (p.isMaxed(def.id) || !p.canBuy(def.id)) {
      this.sfx('error');
      card.classList.remove('shake');
      void card.offsetWidth;
      card.classList.add('shake');
      return;
    }
    if (p.buy(def.id)) {
      this.sfx('buy');
      card.classList.remove('bought');
      void card.offsetWidth;
      card.classList.add('bought');
    }
  }

  private refreshCards(): void {
    const p = this.ctx.progression;
    for (const c of this.cards) {
      const lvl = p.level(c.def.id);
      const maxed = p.isMaxed(c.def.id);
      const afford = p.canBuy(c.def.id);
      c.pips.forEach((pip, i) => pip.classList.toggle('on', i < lvl));
      c.cur.textContent = c.def.valueLabel(lvl);
      c.next.textContent = maxed ? '' : c.def.valueLabel(lvl + 1);
      c.arrow.style.display = maxed ? 'none' : '';
      c.root.classList.toggle('maxed', maxed);
      c.root.classList.toggle('poor', !maxed && !afford);
      c.root.classList.toggle('afford', afford);
      c.buy.innerHTML = maxed ? '★ MAXED' : `<span class="ss-coin sm"></span>${fmt(p.cost(c.def.id))}`;
      c.buy.setAttribute('aria-disabled', afford ? 'false' : 'true');
    }
  }

  private openGarage(back: 'menu' | 'quit'): void {
    this.garageBack = back;
    this.shopContinue = null;
    this.shopTitle.textContent = 'GARAGE';
    this.shopSub.textContent = 'Spend your coins on permanent upgrades.';
    this.shopWave.classList.add('hidden');
    this.shopBack.classList.remove('hidden');
    this.shopStart.classList.add('hidden');
    this.shopHint.classList.add('hidden');
    delete this.shopStart.dataset.primary;
    this.shopBack.dataset.primary = '1';
    this.refreshCards();
    this.show('garage');
  }

  private renderWavePreview(nextWave: number, totalWaves: number): void {
    const w = this.shopWave;
    w.textContent = '';
    w.classList.remove('hidden');
    const t = el('div', 'ss-wave-title', undefined, w);
    t.innerHTML = `Wave <b>${nextWave}</b> of ${totalWaves} next`;
    const wave = this.ctx.zone.waves[nextWave - 1];
    const counts = new Map<EnemyType, number>();
    if (wave) for (const g of wave.groups) counts.set(g.type, (counts.get(g.type) ?? 0) + g.count);
    const chips = el('div', 'ss-chips', undefined, w);
    for (const [type, n] of counts) {
      const def = ENEMIES[type];
      const chip = el('div', `ss-chip ${def.isBoss ? 'boss' : ''}`, undefined, chips);
      chip.style.setProperty('--chip', hex(def.color));
      el('span', 'ss-chip-icon', ENEMY_ICON[type], chip);
      el('span', 'ss-chip-name', def.name, chip);
      el('span', 'ss-chip-count', `×${n}`, chip);
      if (def.isBoss) el('span', 'ss-chip-tag', 'BOSS', chip);
      else if (def.armor >= 8) el('span', 'ss-chip-tag armor', 'ARMORED', chip);
    }
  }

  /* ================================================================== pause */

  private buildPause(): void {
    const s = this.screen('pause', 'ss-center ss-dim');
    const panel = el('div', 'ss-panel ss-glass ss-pause ss-icicles', undefined, s);
    el('h2', 'ss-h2', 'PAUSED', panel);
    el('div', 'ss-sub', 'The snowmen are politely waiting.', panel);
    const btns = el('div', 'ss-stack', undefined, panel);
    this.btn('▶ RESUME', 'ss-primary ss-big', () => this.handlers.onResume(), btns).dataset.primary = '1';
    const mute = this.btn('', 'ss-ice', () => {
      this.handlers.onToggleMute();
      this.refreshMute();
    }, btns);
    this.muteBtns.push(mute);
    this.btn('⏏ QUIT TO MENU', 'ss-ice ss-danger', () => this.handlers.onQuitToMenu(), btns);
    this.controlsList(panel).classList.add('compact');
    this.refreshMute();
  }

  /* ================================================================== result */

  private buildResult(): void {
    const s = this.screen('result', 'ss-center ss-dim');
    this.resultPanel = el('div', 'ss-panel ss-glass ss-result ss-icicles', undefined, s);
  }

  private renderResult(sum: RunSummary, win: boolean): void {
    const p = this.resultPanel;
    p.textContent = '';
    p.classList.toggle('win', win);
    p.classList.toggle('lose', !win);
    el('div', 'ss-result-emoji', win ? '🏆' : '🏚️', p);
    el('h2', 'ss-h2 ss-result-title', win ? 'Zone cleared!' : 'The cabin has fallen!', p);
    el('div', 'ss-sub', win ? `${sum.zoneName} is safe. The cocoa is still warm.` : `${sum.zoneName} — the snowmen got their cocoa.`, p);

    const grid = el('div', 'ss-stats', undefined, p);
    const stat = (icon: string, label: string, value: string, delay: number) => {
      const s = el('div', 'ss-stat', undefined, grid);
      s.style.animationDelay = `${delay}ms`;
      el('div', 'ss-stat-icon', icon, s);
      el('div', 'ss-stat-val', value, s);
      el('div', 'ss-stat-label', label, s);
    };
    stat('🌊', 'Waves cleared', `${sum.wavesCleared}/${sum.totalWaves}`, 100);
    stat('💀', 'Kills', fmt(sum.kills), 180);
    stat('🎳', 'Strikes', fmt(sum.strikes), 260);
    stat('⚪', 'Biggest ball', `${sum.biggestBall.toFixed(2)} m`, 340);
    stat('🪙', 'Coins earned', `+${fmt(sum.coinsEarned)}`, 420);

    if (win && sum.clearReward > 0) {
      const r = el('div', 'ss-reward', undefined, p);
      r.innerHTML = `<span class="ss-coin"></span> +${fmt(sum.clearReward)} ${sum.firstClear ? 'first-clear reward!' : 'clear reward'}`;
    }
    if (win && sum.unlockedZoneName) {
      const u = el('div', 'ss-unlock', undefined, p);
      u.innerHTML = `🔓 New zone unlocked: <b>${sum.unlockedZoneName}</b>`;
    }

    const btns = el('div', 'ss-result-btns', undefined, p);
    if (win) {
      const nextIdx = this.ctx.zone.index + 1;
      if (nextIdx < ZONES.length && this.ctx.progression.isZoneUnlocked(nextIdx)) {
        this.btn(`NEXT ZONE ▶`, 'ss-primary ss-big', () => this.handlers.onStartZone(nextIdx), btns).dataset.primary = '1';
      } else if (nextIdx >= ZONES.length) {
        btns.before(el('div', 'ss-unlock', '🌟 Every zone conquered. You are the Snowplow Legend!'));
      }
    } else {
      this.btn('↻ RETRY', 'ss-primary ss-big', () => this.handlers.onRetry(), btns).dataset.primary = '1';
    }
    const g = this.btn('🔧 GARAGE', 'ss-ice', () => this.openGarage('quit'), btns);
    const m = this.btn('🏠 MAIN MENU', 'ss-ice', () => this.handlers.onQuitToMenu(), btns);
    if (!btns.querySelector('[data-primary]')) (win ? m : g).dataset.primary = '1';
  }

  /* ================================================================== HUD */

  private buildHud(): void {
    const hud = (this.hud = el('div', 'ss-hud', undefined, this.rootEl));
    const H = this.h;

    const tl = el('div', 'ss-hud-tl ss-glass-dark', undefined, hud);
    H.zone = el('div', 'ss-hud-zone', '', tl);
    const wv = el('div', 'ss-hud-waverow', undefined, tl);
    H.wave = el('div', 'ss-hud-wave', '', wv);
    H.enemies = el('div', 'ss-hud-enemies', '', wv);

    H.boss = el('div', 'ss-hud-boss hidden', undefined, hud);
    H.bossName = el('div', 'ss-boss-name', '', H.boss);
    const bb = el('div', 'ss-boss-bar', undefined, H.boss);
    H.bossFill = el('div', 'ss-boss-fill', undefined, bb);
    H.bossHp = el('div', 'ss-boss-hp', '', bb);

    H.coinBox = el('div', 'ss-hud-tr ss-glass-dark', undefined, hud);
    el('span', 'ss-coin', undefined, H.coinBox);
    H.coins = el('span', 'ss-hud-coins', '0', H.coinBox);

    const bl = el('div', 'ss-hud-bl ss-glass-dark', undefined, hud);
    const bar = (label: string, cls: string) => {
      const row = el('div', `ss-bar-row ${cls}`, undefined, bl);
      const lab = el('div', 'ss-bar-label', undefined, row);
      lab.innerHTML = label;
      const track = el('div', 'ss-bar', undefined, row);
      const fill = el('div', 'ss-bar-fill', undefined, track);
      const txt = el('div', 'ss-bar-txt', '', track);
      return { row, fill, txt };
    };
    const pb = bar('🚜 PLOW', 'plow');
    H.plowFill = pb.fill;
    H.plowTxt = pb.txt;
    const cb = bar('🏠 CABIN', 'cabin');
    H.baseFill = cb.fill;
    H.baseTxt = cb.txt;
    H.baseBar = cb.row;

    const bc = el('div', 'ss-hud-bc', undefined, hud);
    H.gauge = el('div', 'ss-gauge', undefined, bc);
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 110 110');
    svg.classList.add('ss-gauge-svg');
    const track = document.createElementNS(NS, 'circle');
    track.setAttribute('cx', '55');
    track.setAttribute('cy', '55');
    track.setAttribute('r', String(GAUGE_R));
    track.setAttribute('class', 'ss-gauge-track');
    const ring = document.createElementNS(NS, 'circle');
    ring.setAttribute('cx', '55');
    ring.setAttribute('cy', '55');
    ring.setAttribute('r', String(GAUGE_R));
    ring.setAttribute('class', 'ss-gauge-ring');
    ring.setAttribute('stroke-dasharray', `${GAUGE_C} ${GAUGE_C}`);
    ring.setAttribute('stroke-dashoffset', String(GAUGE_C));
    ring.setAttribute('transform', 'rotate(-90 55 55)');
    svg.appendChild(track);
    svg.appendChild(ring);
    H.gauge.appendChild(svg);
    H.ring = ring;
    const inner = el('div', 'ss-gauge-inner', undefined, H.gauge);
    H.radius = el('div', 'ss-gauge-r', '0.00m', inner);
    H.tier = el('div', 'ss-gauge-tier', 'Snowball', inner);
    H.launch = el('div', 'ss-launch-hint', undefined, bc);
    H.launch.innerHTML = '<kbd class="ss-kbd">SPACE</kbd> to launch';
    H.turbo = el('div', 'ss-turbo hidden', undefined, bc);
    el('span', 'ss-turbo-label', '🔥 TURBO', H.turbo);
    const tt = el('div', 'ss-turbo-bar', undefined, H.turbo);
    H.turboFill = el('div', 'ss-turbo-fill', undefined, tt);

    const br = el('div', 'ss-hud-br ss-glass-dark', undefined, hud);
    el('span', 'ss-snow-label', '❄ SNOW', br);
    const sb = el('div', 'ss-snow-bar', undefined, br);
    H.snowFill = el('div', 'ss-snow-fill', undefined, sb);
    H.snowTxt = el('span', 'ss-snow-txt', '', br);

    H.stall = el('div', 'ss-stall hidden', undefined, hud);
    el('div', 'ss-stall-icon', '⚡', H.stall);
    H.stallTxt = el('div', 'ss-stall-txt', '', H.stall);

    H.count = el('div', 'ss-count hidden', '', hud);
    H.hint = el('div', 'ss-hint hidden', 'W/S drive  ·  A/D steer  ·  plow deep snow to grow a ball  ·  SPACE launch  ·  ESC pause', hud);
  }

  private pulse(kind: 'base' | 'plow' | 'heavy'): void {
    if (!this.hudVisible) return;
    const v = this.vignette;
    v.classList.remove('base', 'plow', 'heavy', 'go');
    void v.offsetWidth;
    v.classList.add(kind, 'go');
  }

  /* ================================================================== UIAPI */

  get overlayOpen(): boolean {
    return this.current !== null;
  }

  showMainMenu(): void {
    this.shopContinue = null;
    this.refreshProgress();
    this.refreshMute();
    this.show('menu');
  }

  showZoneSelect(): void {
    this.renderZones();
    this.show('zones');
  }

  showGarage(): void {
    this.openGarage('menu');
  }

  showShop(nextWave: number, totalWaves: number, onContinue: () => void): void {
    this.shopContinue = onContinue;
    this.shopTitle.textContent = 'UPGRADE SHOP';
    this.shopSub.textContent = `${this.ctx.zone.name} — wave cleared! Gear up before the next one.`;
    this.renderWavePreview(nextWave, totalWaves);
    this.shopBack.classList.add('hidden');
    this.shopStart.classList.remove('hidden');
    this.shopHint.classList.remove('hidden');
    delete this.shopBack.dataset.primary;
    this.shopStart.dataset.primary = '1';
    this.refreshCards();
    this.show('garage');
  }

  showPause(): void {
    this.refreshMute();
    this.show('pause');
  }

  showGameOver(summary: RunSummary): void {
    this.renderResult(summary, false);
    this.show('result');
  }

  showVictory(summary: RunSummary): void {
    this.renderResult(summary, true);
    this.show('result');
  }

  hideOverlays(): void {
    for (const k in this.screens) {
      const s = this.screens[k as ScreenName];
      s.classList.remove('show');
      s.setAttribute('aria-hidden', 'true');
    }
    this.current = null;
    const a = document.activeElement as HTMLElement | null;
    if (a && a !== document.body && a.blur) a.blur();
  }

  setHudVisible(visible: boolean): void {
    if (visible === this.hudVisible) return;
    this.hudVisible = visible;
    this.hud.classList.toggle('show', visible);
    if (!visible) {
      this.vignette.classList.remove('go');
      this.h.count.classList.add('hidden');
      this.h.stall.classList.add('hidden');
      this.last.count = -1;
      this.last.stall = -1;
      clearTimeout(this.hintTimer);
      this.h.hint.classList.add('hidden');
    } else {
      const d = this.ctx.progression.data;
      const firstRun = d.totalKills < 15 && !Object.values(d.zones).some((z) => z.bestWave > 0);
      this.h.hint.classList.toggle('hidden', !firstRun);
      clearTimeout(this.hintTimer);
      if (firstRun) this.hintTimer = window.setTimeout(() => this.h.hint.classList.add('hidden'), 45000);
    }
  }

  updateHud(s: HudState): void {
    if (!this.hudVisible) return;
    const H = this.h;
    const L = this.last;

    if (s.zoneName !== L.zone) {
      L.zone = s.zoneName;
      H.zone.textContent = s.zoneName;
    }
    if (s.wave !== L.wave || s.totalWaves !== L.total) {
      L.wave = s.wave;
      L.total = s.totalWaves;
      H.wave.textContent = `Wave ${s.wave}/${s.totalWaves}`;
    }
    const en = Math.max(0, Math.round(s.enemiesRemaining));
    if (en !== L.enemies) {
      L.enemies = en;
      H.enemies.textContent = en > 0 ? `${en} enem${en === 1 ? 'y' : 'ies'} left` : 'Get ready…';
    }

    // boss
    const bossOn = !!s.boss;
    if (bossOn !== L.bossOn) {
      L.bossOn = bossOn;
      H.boss.classList.toggle('hidden', !bossOn);
    }
    if (s.boss) {
      if (s.boss.name !== L.bossName) {
        L.bossName = s.boss.name;
        H.bossName.textContent = `👑 ${s.boss.name}`;
      }
      const frac = Math.round((Math.max(0, s.boss.hp) / Math.max(1, s.boss.maxHp)) * 400) / 400;
      if (frac !== L.bossFrac) {
        L.bossFrac = frac;
        H.bossFill.style.transform = `scaleX(${frac})`;
      }
      const hp = Math.ceil(Math.max(0, s.boss.hp));
      if (hp !== L.bossHp) {
        L.bossHp = hp;
        H.bossHp.textContent = `${fmt(hp)} / ${fmt(s.boss.maxHp)}`;
      }
    }

    // coins
    const coins = Math.floor(s.coins);
    if (coins !== L.coins) {
      if (L.coins >= 0 && coins > L.coins) {
        H.coinBox.classList.remove('bump');
        void H.coinBox.offsetWidth;
        H.coinBox.classList.add('bump');
      }
      L.coins = coins;
      H.coins.textContent = fmt(coins);
    }

    // hp bars
    const php = Math.ceil(Math.max(0, s.plowHp));
    if (php !== L.plowHp || s.plowMaxHp !== L.plowMax) {
      L.plowHp = php;
      L.plowMax = s.plowMaxHp;
      const f = Math.min(1, php / Math.max(1, s.plowMaxHp));
      H.plowFill.style.transform = `scaleX(${f})`;
      H.plowFill.classList.toggle('low', f < 0.3);
      H.plowTxt.textContent = `${php} / ${Math.round(s.plowMaxHp)}`;
    }
    const bhp = Math.ceil(Math.max(0, s.baseHp));
    if (bhp !== L.baseHp || s.baseMaxHp !== L.baseMax) {
      L.baseHp = bhp;
      L.baseMax = s.baseMaxHp;
      const f = Math.min(1, bhp / Math.max(1, s.baseMaxHp));
      H.baseFill.style.transform = `scaleX(${f})`;
      H.baseTxt.textContent = `${bhp} / ${Math.round(s.baseMaxHp)}`;
      const low = f < 0.3;
      if (low !== L.baseLow) {
        L.baseLow = low;
        H.baseBar.classList.toggle('danger', low);
      }
    }

    // snowball gauge
    const r = Math.round(s.ballRadius * 100) / 100;
    if (r !== L.ballR) {
      L.ballR = r;
      H.radius.textContent = `${r.toFixed(2)}m`;
      const t = tierIndex(r);
      if (t !== L.tier) {
        if (L.tier >= 0 && t > L.tier) {
          H.gauge.classList.remove('tierup');
          void H.gauge.offsetWidth;
          H.gauge.classList.add('tierup');
        }
        L.tier = t;
        H.tier.textContent = tierName(r);
        H.gauge.dataset.tier = String(t);
      }
      const ready = s.ballRadius >= MIN_BALL_RADIUS;
      if (ready !== L.ready) {
        L.ready = ready;
        H.gauge.classList.toggle('ready', ready);
        H.launch.classList.toggle('show', ready);
      }
    }
    const frac = Math.round(Math.min(1, s.ballRadius / Math.max(0.01, s.ballMaxRadius)) * 200) / 200;
    if (frac !== L.ballFrac) {
      L.ballFrac = frac;
      H.ring.setAttribute('stroke-dashoffset', String(GAUGE_C * (1 - frac)));
      const full = frac >= 0.99;
      if (full !== L.full) {
        L.full = full;
        H.gauge.classList.toggle('full', full);
      }
    }

    // turbo
    const tc = s.turboCharge < 0 ? -1 : Math.round(s.turboCharge * 100) / 100;
    if (tc !== L.turbo) {
      if ((tc < 0) !== (L.turbo < 0) || L.turbo === -2) H.turbo.classList.toggle('hidden', tc < 0);
      L.turbo = tc;
      if (tc >= 0) {
        H.turboFill.style.transform = `scaleX(${tc})`;
        const tf = tc >= 0.99;
        if (tf !== L.turboFull) {
          L.turboFull = tf;
          H.turbo.classList.toggle('full', tf);
        }
      }
    }

    // snow remaining
    const sf = Math.round(Math.max(0, Math.min(1, s.snowFraction)) * 100);
    if (sf !== L.snow) {
      L.snow = sf;
      H.snowFill.style.transform = `scaleX(${sf / 100})`;
      H.snowTxt.textContent = `${sf}%`;
      H.snowFill.classList.toggle('low', sf < 25);
    }

    // stalled
    const st = s.stalledSeconds > 0 ? Math.ceil(s.stalledSeconds * 10) / 10 : 0;
    if (st !== L.stall) {
      if ((st > 0) !== (L.stall > 0)) H.stall.classList.toggle('hidden', st <= 0);
      L.stall = st;
      if (st > 0) H.stallTxt.textContent = `REBOOTING ${st.toFixed(1)}s`;
    }

    // countdown
    const cn = s.countdown > 0 ? Math.ceil(s.countdown) : 0;
    if (cn !== L.count) {
      if ((cn > 0) !== (L.count > 0)) H.count.classList.toggle('hidden', cn <= 0);
      L.count = cn;
      if (cn > 0) {
        H.count.textContent = String(cn);
        H.count.classList.remove('pop');
        void H.count.offsetWidth;
        H.count.classList.add('pop');
      }
    }
  }

  toast(text: string, kind: 'info' | 'good' | 'bad' | 'big' = 'info'): void {
    if (kind === 'big') {
      const box = this.bigBox;
      for (const c of Array.from(box.children)) c.classList.add('old');
      while (box.children.length >= 2) box.firstElementChild!.remove();
      const t = el('div', 'ss-bigtoast', text, box);
      t.addEventListener('animationend', (e) => {
        if (e.target === t && e.animationName === 'ss-big-life') t.remove();
      });
      return;
    }
    const box = this.toastBox;
    const live = box.querySelectorAll('.ss-toast:not(.out)');
    if (live.length >= 4) this.killToast(live[0] as HTMLElement);
    const t = el('div', `ss-toast ${kind}`, text, box);
    t.addEventListener('animationend', (e) => {
      if (e.target === t && e.animationName === 'ss-toast-life') t.remove();
    });
  }

  private killToast(t: HTMLElement): void {
    t.classList.add('out');
    setTimeout(() => t.remove(), 260);
  }
}
