import * as THREE from 'three';
import { BASE_POSITION, BASE_RADIUS } from '../core/types';
import type { CameraRigAPI, GameContext } from '../core/types';

const BACK = 11;
const UP = 7.5;
const AHEAD = 6;

function damp(k: number, dt: number): number {
  return 1 - Math.exp(-k * dt);
}

function angleLerp(a: number, b: number, t: number): number {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

/** Cheap smooth 1D value noise from summed sines. */
function noise(t: number, seed: number): number {
  return (
    Math.sin(t * 1.0 + seed) * 0.5 +
    Math.sin(t * 2.31 + seed * 1.7) * 0.3 +
    Math.sin(t * 5.13 + seed * 3.1) * 0.2
  );
}

export class CameraRig implements CameraRigAPI {
  private ctx: GameContext;
  private mode: 'follow' | 'menu' = 'menu';
  private pos = new THREE.Vector3(0, 24, 50);
  private look = new THREE.Vector3();
  private heading = Math.PI;
  private fov = 60;
  private trauma = 0;
  private t = 0;
  private orbit = 0;
  private needSnap = true;
  private tmpPos = new THREE.Vector3();
  private tmpLook = new THREE.Vector3();

  constructor(ctx: GameContext) {
    this.ctx = ctx;
  }

  setMode(mode: 'follow' | 'menu'): void {
    if (mode === this.mode) return;
    this.mode = mode;
    if (mode === 'follow') {
      const plow = this.ctx.plow;
      if (plow) this.heading = plow.heading;
    }
  }

  snap(): void {
    this.needSnap = true;
    const plow = this.ctx.plow;
    if (plow) this.heading = plow.heading;
    this.computeTarget(0);
    this.pos.copy(this.tmpPos);
    this.look.copy(this.tmpLook);
    this.needSnap = false;
    this.apply();
  }

  addShake(intensity: number): void {
    this.trauma = Math.min(1.6, this.trauma + intensity);
  }

  private computeTarget(dt: number): void {
    const plow = this.ctx.plow;
    if (this.mode === 'menu' || !plow) {
      this.orbit += dt * 0.06;
      const r = 50;
      this.tmpPos.set(Math.sin(this.orbit) * r, 24, Math.cos(this.orbit) * r);
      this.tmpLook.set(0, 0, 0);
      return;
    }
    this.heading = dt > 0 ? angleLerp(this.heading, plow.heading, damp(3.2, dt)) : plow.heading;
    const sx = Math.sin(this.heading);
    const cz = Math.cos(this.heading);
    const p = plow.position;
    this.tmpPos.set(p.x - sx * BACK, p.y + UP, p.z - cz * BACK);
    // Lift the camera over the cabin instead of clipping into its roof.
    const bx = this.tmpPos.x - BASE_POSITION.x;
    const bz = this.tmpPos.z - BASE_POSITION.z;
    const bd = Math.sqrt(bx * bx + bz * bz);
    const lift = BASE_RADIUS + 4;
    if (bd < lift) this.tmpPos.y += (lift - bd) * 0.9;
    this.tmpLook.set(p.x + sx * AHEAD, p.y + 0.5, p.z + cz * AHEAD);
  }

  update(dt: number): void {
    this.t += dt;
    this.computeTarget(dt);
    if (this.needSnap) {
      this.pos.copy(this.tmpPos);
      this.look.copy(this.tmpLook);
      this.needSnap = false;
    } else {
      const kp = this.mode === 'menu' ? 1.2 : 5;
      const kl = this.mode === 'menu' ? 1.5 : 7;
      this.pos.lerp(this.tmpPos, damp(kp, dt));
      this.look.lerp(this.tmpLook, damp(kl, dt));
    }

    // FOV
    let targetFov = 60;
    const plow = this.ctx.plow;
    if (this.mode === 'follow' && plow) {
      const max = this.ctx.stats.maxSpeed || 1;
      targetFov = 60 + 8 * Math.min(1, Math.abs(plow.speed) / max);
    }
    this.fov += (targetFov - this.fov) * damp(3, dt);

    this.trauma = Math.max(0, this.trauma - 1.5 * dt);
    this.apply();
  }

  private apply(): void {
    const cam = this.ctx.camera;
    cam.position.copy(this.pos);
    cam.lookAt(this.look);
    const s = this.trauma * this.trauma;
    if (s > 0.0001) {
      const tt = this.t * 22;
      // Offset in camera-local space so it doesn't depend on heading
      cam.translateX(noise(tt, 1.3) * s * 0.9);
      cam.translateY(noise(tt, 7.7) * s * 0.7);
      cam.rotateZ(noise(tt, 4.2) * s * 0.06);
    }
    if (Math.abs(cam.fov - this.fov) > 0.01) {
      cam.fov = this.fov;
      cam.updateProjectionMatrix();
    }
  }
}
