import * as THREE from 'three';
import {
  ARENA,
  MIN_BALL_RADIUS,
  PLOW_SPAWN,
  ballRadius,
  ballVolume,
  type GameContext,
  type PlayerStats,
  type PlowAPI,
} from '../core/types';
import { getSnowballGeometry, getSnowballMaterial } from './Snowballs';

/* Model layout (local, facing +Z): rear dump bed at -Z, cab mid-front, hood, blade at BLADE_Z. */
const BLADE_Z = 2.35;
const WHEEL_R = 0.48;
const STALL_SECONDS = 3;

const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _c = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _q = new THREE.Quaternion();

export class Plow implements PlowAPI {
  readonly object = new THREE.Group();
  readonly position = this.object.position;
  heading: number = PLOW_SPAWN.heading;
  speed = 0;
  readonly radius = 1.6;
  hp = 100;
  maxHp = 100;

  private ctx: GameContext;
  private _stalled = false;
  private _stallTime = 0;
  private heldVolume = 0;
  private _turbo = 1;
  private boosting = false;
  private pushVel = new THREE.Vector3();
  private bladeWidth = 2.6;
  private grace = 0;

  // visuals
  private body = new THREE.Group();
  private bladeGroup = new THREE.Group();
  private bladeSheet!: THREE.Mesh;
  private bladeCaps: THREE.Mesh[] = [];
  private bladeArms: THREE.Mesh[] = [];
  private wheels: THREE.Object3D[] = [];
  private paintMat: THREE.MeshStandardMaterial;
  private bedMat: THREE.MeshStandardMaterial;
  private beaconMat: THREE.MeshStandardMaterial;
  private beaconLight: THREE.PointLight;
  private beaconSpinner = new THREE.Group();
  private headMat: THREE.MeshStandardMaterial;
  private flame: THREE.Mesh;
  private flameMat: THREE.MeshBasicMaterial;
  private exhaustTip = new THREE.Vector3(-0.72, 2.55, 0.05);
  private ball: THREE.Mesh;
  private ballR = 0;
  private glow: THREE.Mesh;
  private glowMat: THREE.MeshBasicMaterial;

  private roll = 0;
  private pitch = 0;
  private kick = 0;
  private flash = 0;
  private bobT = 0;
  private puffT = 0;
  private lastSpeed = 0;
  private plowSmooth = 0;
  private time = 0;

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    this.object.name = 'plow';

    this.paintMat = new THREE.MeshStandardMaterial({ color: 0xff7a1a, roughness: 0.45, metalness: 0.15, emissive: 0xff0000, emissiveIntensity: 0 });
    this.bedMat = new THREE.MeshStandardMaterial({ color: 0xffb21f, roughness: 0.5, metalness: 0.1, emissive: 0xff0000, emissiveIntensity: 0 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x2b2f38, roughness: 0.7, metalness: 0.3 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x1b2a40, roughness: 0.12, metalness: 0.6, emissive: 0x0b1830, emissiveIntensity: 0.4 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0xffd23a, roughness: 0.35, metalness: 0.55, side: THREE.DoubleSide });
    const chromeMat = new THREE.MeshStandardMaterial({ color: 0xc9d2dc, roughness: 0.25, metalness: 0.85 });
    const rubberMat = new THREE.MeshStandardMaterial({ color: 0x1c1c22, roughness: 0.9, flatShading: true });
    const hubMat = new THREE.MeshStandardMaterial({ color: 0xffd23a, roughness: 0.4, metalness: 0.4 });
    const stripeMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
    const redMat = new THREE.MeshStandardMaterial({ color: 0xe8283a, roughness: 0.4, emissive: 0x550000, emissiveIntensity: 0.4 });
    this.headMat = new THREE.MeshStandardMaterial({ color: 0xfff6d0, emissive: 0xfff1b8, emissiveIntensity: 1.6 });
    this.beaconMat = new THREE.MeshStandardMaterial({ color: 0xffb000, emissive: 0xff9a00, emissiveIntensity: 1, transparent: true, opacity: 0.92, roughness: 0.2 });

    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D = this.body, shadow = true) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      m.castShadow = shadow;
      m.receiveShadow = shadow;
      parent.add(m);
      return m;
    };

    // Chassis + bumpers.
    add(new THREE.BoxGeometry(1.7, 0.35, 4.0), darkMat, 0, 0.62, 0.05);
    add(new THREE.BoxGeometry(2.05, 0.22, 0.25), darkMat, 0, 0.62, -2.0);
    // Rear dump bed (yellow-orange) with rim.
    add(new THREE.BoxGeometry(2.1, 0.95, 2.1), this.bedMat, 0, 1.3, -0.95);
    add(new THREE.BoxGeometry(2.2, 0.12, 2.2), darkMat, 0, 1.82, -0.95);
    add(new THREE.BoxGeometry(2.12, 0.14, 0.9), stripeMat, 0, 1.1, -0.95).scale.set(1, 1, 2.3);
    // Tail lights.
    add(new THREE.BoxGeometry(0.28, 0.18, 0.06), redMat, -0.78, 1.05, -2.02, this.body, false);
    add(new THREE.BoxGeometry(0.28, 0.18, 0.06), redMat, 0.78, 1.05, -2.02, this.body, false);
    // Cab.
    add(new THREE.BoxGeometry(2.0, 1.25, 1.35), this.paintMat, 0, 1.55, 0.72);
    add(new THREE.BoxGeometry(2.08, 0.12, 1.45), this.paintMat, 0, 2.22, 0.72);
    // Windows: windshield + side windows + rear.
    const ws = add(new THREE.BoxGeometry(1.7, 0.6, 0.06), glassMat, 0, 1.85, 1.41, this.body, false);
    ws.rotation.x = -0.12;
    add(new THREE.BoxGeometry(0.06, 0.55, 0.95), glassMat, -1.01, 1.85, 0.75, this.body, false);
    add(new THREE.BoxGeometry(0.06, 0.55, 0.95), glassMat, 1.01, 1.85, 0.75, this.body, false);
    add(new THREE.BoxGeometry(1.5, 0.45, 0.06), glassMat, 0, 1.88, 0.04, this.body, false);
    // Hood + grille.
    add(new THREE.BoxGeometry(1.85, 0.7, 0.85), this.paintMat, 0, 1.18, 1.78);
    add(new THREE.BoxGeometry(1.3, 0.42, 0.06), chromeMat, 0, 1.15, 2.22);
    // Headlights.
    add(new THREE.BoxGeometry(0.3, 0.2, 0.08), this.headMat, -0.72, 1.3, 2.22, this.body, false);
    add(new THREE.BoxGeometry(0.3, 0.2, 0.08), this.headMat, 0.72, 1.3, 2.22, this.body, false);
    // White stripe along the cab doors.
    add(new THREE.BoxGeometry(2.04, 0.1, 1.38), stripeMat, 0, 1.25, 0.72, this.body, false);
    // Mirrors.
    add(new THREE.BoxGeometry(0.08, 0.3, 0.18), darkMat, -1.18, 1.85, 1.2, this.body, false);
    add(new THREE.BoxGeometry(0.08, 0.3, 0.18), darkMat, 1.18, 1.85, 1.2, this.body, false);
    // Exhaust stack.
    add(new THREE.CylinderGeometry(0.09, 0.09, 1.4, 10), chromeMat, -0.72, 1.85, 0.05);
    add(new THREE.CylinderGeometry(0.12, 0.12, 0.12, 10), darkMat, -0.72, 2.5, 0.05);

    // Turbo flame.
    this.flameMat = new THREE.MeshBasicMaterial({ color: 0xff8a1a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    const flameGeo = new THREE.ConeGeometry(0.13, 0.7, 8);
    flameGeo.translate(0, 0.35, 0);
    this.flame = add(flameGeo, this.flameMat, -0.72, 2.55, 0.05, this.body, false);
    this.flame.visible = false;

    // Roof beacon.
    add(new THREE.BoxGeometry(0.9, 0.08, 0.3), darkMat, 0, 2.32, 0.8);
    const beacon = add(new THREE.CylinderGeometry(0.16, 0.18, 0.24, 12), this.beaconMat, 0, 2.48, 0.8, this.body, false);
    beacon.add(this.beaconSpinner);
    const reflector = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.16, 0.04), new THREE.MeshBasicMaterial({ color: 0xffe08a }));
    this.beaconSpinner.add(reflector);
    this.beaconLight = new THREE.PointLight(0xffa020, 0, 7, 2);
    this.beaconLight.position.set(0, 2.8, 0.8);
    this.body.add(this.beaconLight);

    // Wheels.
    const tireGeo = new THREE.CylinderGeometry(WHEEL_R, WHEEL_R, 0.42, 14);
    tireGeo.rotateZ(Math.PI / 2);
    const hubGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.44, 8);
    hubGeo.rotateZ(Math.PI / 2);
    const treadGeo = new THREE.BoxGeometry(0.44, 0.1, 0.16);
    for (const [x, z] of [[-0.95, 1.45], [0.95, 1.45], [-0.95, -1.25], [0.95, -1.25]] as const) {
      const w = new THREE.Group();
      w.position.set(x, WHEEL_R, z);
      const t = new THREE.Mesh(tireGeo, rubberMat);
      t.castShadow = true;
      w.add(t);
      w.add(new THREE.Mesh(hubGeo, hubMat));
      for (let i = 0; i < 6; i++) {
        const tr = new THREE.Mesh(treadGeo, rubberMat);
        const a = (i / 6) * Math.PI * 2;
        tr.position.set(0, Math.sin(a) * WHEEL_R, Math.cos(a) * WHEEL_R);
        tr.rotation.x = -a;
        w.add(tr);
      }
      this.body.add(w);
      this.wheels.push(w);
    }
    // Fenders.
    for (const [x, z] of [[-0.95, 1.45], [0.95, 1.45], [-0.95, -1.25], [0.95, -1.25]] as const) {
      add(new THREE.BoxGeometry(0.5, 0.1, 1.1), darkMat, x, WHEEL_R * 2 + 0.08, z);
    }

    // Blade: curved sheet (unit width, scaled on X) + mounting arms.
    const R = 0.78;
    const sheetGeo = new THREE.CylinderGeometry(R, R, 1, 14, 1, true, Math.PI - 0.95, 1.9);
    sheetGeo.rotateZ(Math.PI / 2);
    // After rotation: y' = R sin(theta), z' = R cos(theta) -> concave side faces +Z.
    sheetGeo.translate(0, 0.72, R - 0.05);
    this.bladeSheet = new THREE.Mesh(sheetGeo, steelMat);
    this.bladeSheet.castShadow = true;
    this.bladeSheet.receiveShadow = true;
    this.bladeGroup.add(this.bladeSheet);
    const edgeGeo = new THREE.BoxGeometry(1, 0.1, 0.12);
    const edge = new THREE.Mesh(edgeGeo, darkMat);
    edge.position.set(0, 0.08, 0.22);
    this.bladeSheet.add(edge);
    // Bladeside hazard caps (repositioned in applyStats).
    const capGeo = new THREE.BoxGeometry(0.08, 1.2, 0.5);
    for (let i = 0; i < 2; i++) {
      const cap = new THREE.Mesh(capGeo, redMat);
      cap.position.set(0, 0.7, 0.1);
      cap.castShadow = true;
      this.bladeGroup.add(cap);
      this.bladeCaps.push(cap);
    }
    const armGeo = new THREE.BoxGeometry(0.14, 0.14, 0.9);
    for (const x of [-0.55, 0.55]) {
      const arm = new THREE.Mesh(armGeo, darkMat);
      arm.position.set(x, 0.75, -0.3);
      arm.castShadow = true;
      this.bladeGroup.add(arm);
      this.bladeArms.push(arm);
    }
    const ram = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.8, 8), chromeMat);
    ram.rotation.x = Math.PI / 2 - 0.5;
    ram.position.set(0, 1.0, -0.3);
    this.bladeGroup.add(ram);
    this.bladeGroup.position.set(0, 0, BLADE_Z - 0.1);
    this.body.add(this.bladeGroup);

    this.object.add(this.body);

    // Held snowball (world-space, not parented to the truck).
    this.ball = new THREE.Mesh(getSnowballGeometry(), getSnowballMaterial(false));
    this.ball.castShadow = true;
    this.ball.receiveShadow = true;
    this.ball.visible = false;
    ctx.scene.add(this.ball);

    this.glowMat = new THREE.MeshBasicMaterial({ color: 0x8fd8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const glowGeo = new THREE.RingGeometry(1.05, 1.45, 40);
    glowGeo.rotateX(-Math.PI / 2);
    this.glow = new THREE.Mesh(glowGeo, this.glowMat);
    this.glow.visible = false;
    this.glow.renderOrder = 2;
    ctx.scene.add(this.glow);

    ctx.scene.add(this.object);
    this.applyStats(ctx.stats);
    this.reset();
  }

  /* ------------------------------------------------------------------ API */

  get stalled(): boolean {
    return this._stalled;
  }
  get stallTimeLeft(): number {
    return this._stallTime;
  }
  get heldBallRadius(): number {
    return ballRadius(this.heldVolume);
  }
  get turboCharge(): number {
    return this._turbo;
  }

  getForward(out: THREE.Vector3): THREE.Vector3 {
    return out.set(Math.sin(this.heading), 0, Math.cos(this.heading));
  }

  getBladeTip(out: THREE.Vector3): THREE.Vector3 {
    const s = Math.sin(this.heading);
    const c = Math.cos(this.heading);
    return out.set(this.position.x + s * (BLADE_Z + 0.15), 0, this.position.z + c * (BLADE_Z + 0.15));
  }

  damage(amount: number): void {
    if (this._stalled || this.grace > 0 || amount <= 0) return;
    const ctx = this.ctx;
    this.hp = Math.max(0, this.hp - amount);
    this.flash = 1;
    ctx.events.emit('plowDamaged', { amount });
    ctx.audio?.play('plowHit');
    ctx.fx?.shake(0.12 + Math.min(0.4, amount * 0.01));
    if (this.hp <= 0) this.stall();
  }

  stealSnow(fraction: number): number {
    const f = THREE.MathUtils.clamp(fraction, 0, 1);
    const v = this.heldVolume * f;
    this.heldVolume -= v;
    return v;
  }

  push(vx: number, vz: number): void {
    this.pushVel.x += vx;
    this.pushVel.z += vz;
  }

  reset(): void {
    this.position.set(PLOW_SPAWN.x, 0, PLOW_SPAWN.z);
    this.heading = PLOW_SPAWN.heading;
    this.object.rotation.set(0, this.heading, 0);
    this.speed = 0;
    this.lastSpeed = 0;
    this.pushVel.set(0, 0, 0);
    this.hp = this.maxHp;
    this._stalled = false;
    this._stallTime = 0;
    this.heldVolume = 0;
    this.ballR = 0;
    this._turbo = 1;
    this.boosting = false;
    this.grace = 0;
    this.flash = 0;
    this.kick = 0;
    this.roll = 0;
    this.pitch = 0;
    this.ball.visible = false;
    this.glow.visible = false;
    this.flame.visible = false;
    this.body.visible = true;
    this.paintMat.emissiveIntensity = 0;
    this.bedMat.emissiveIntensity = 0;
  }

  applyStats(stats: PlayerStats): void {
    const ratio = this.maxHp > 0 ? this.hp / this.maxHp : 1;
    this.maxHp = stats.maxHp;
    this.hp = Math.max(0, Math.min(this.maxHp, ratio * this.maxHp));
    if (!this._stalled && this.hp <= 0) this.hp = this.maxHp;
    this.setBladeWidth(stats.bladeWidth);
    const cap = ballVolume(stats.maxBallRadius);
    if (this.heldVolume > cap) this.heldVolume = cap;
  }

  private setBladeWidth(w: number): void {
    this.bladeWidth = w;
    this.bladeSheet.scale.x = w;
    this.bladeCaps[0].position.x = -w / 2;
    this.bladeCaps[1].position.x = w / 2;
  }

  /* ------------------------------------------------------------------ internals */

  private stall(): void {
    const ctx = this.ctx;
    this._stalled = true;
    this._stallTime = STALL_SECONDS;
    this.hp = 0;
    ctx.events.emit('plowStalled', { seconds: STALL_SECONDS });
    ctx.audio?.play('stall');
    ctx.fx?.shake(0.5);
    if (this.heldVolume > 0) {
      const r = this.heldBallRadius;
      this.ballCenter(_c, r);
      ctx.snow?.addSnow(_c.x, _c.z, Math.max(1, r * 1.5), this.heldVolume);
      ctx.fx?.burst(_c, { color: 0xffffff, count: 14, speed: 3, size: 0.3, gravity: 10, life: 0.9 });
      this.heldVolume = 0;
    }
    ctx.audio?.setPlowing(0);
  }

  private respawn(): void {
    const ctx = this.ctx;
    this.position.set(PLOW_SPAWN.x, 0, PLOW_SPAWN.z);
    this.heading = PLOW_SPAWN.heading;
    this.speed = 0;
    this.pushVel.set(0, 0, 0);
    this.hp = this.maxHp;
    this._stalled = false;
    this._stallTime = 0;
    this.grace = 1.5;
    this.object.rotation.set(0, this.heading, 0);
    ctx.fx?.burst(_c.set(this.position.x, 1, this.position.z), { color: 0xfff1a0, count: 20, speed: 5, size: 0.25, gravity: 4, life: 0.8 });
    ctx.cameraRig?.snap();
  }

  private ballCenter(out: THREE.Vector3, r: number): THREE.Vector3 {
    this.getBladeTip(out);
    const s = Math.sin(this.heading);
    const c = Math.cos(this.heading);
    out.x += s * r;
    out.z += c * r;
    const snow = this.ctx.snow;
    out.y = (snow ? snow.getDepth(out.x, out.z) : 0) + r;
    return out;
  }

  update(dt: number): void {
    const ctx = this.ctx;
    const stats = ctx.stats;
    const input = ctx.input;
    const snow = ctx.snow;
    this.time += dt;
    if (stats.bladeWidth !== this.bladeWidth) this.setBladeWidth(stats.bladeWidth);
    if (stats.maxHp !== this.maxHp) this.applyStats(stats);
    if (this.grace > 0) this.grace -= dt;

    const maxBallR = stats.maxBallRadius;
    let throttle = 0;
    let steer = 0;
    let plowIntensity = 0;

    if (this._stalled) {
      this._stallTime -= dt;
      this.speed *= Math.exp(-3 * dt);
      this.puffT -= dt;
      if (this.puffT <= 0) {
        this.puffT = 0.12;
        this.exhaustWorld(_c);
        ctx.fx?.burst(_c, { color: 0x3a3a40, count: 3, speed: 1.2, size: 0.45, gravity: -2.5, life: 1.3 });
        _c.set(this.position.x + (Math.random() - 0.5), 1.6, this.position.z + (Math.random() - 0.5));
        ctx.fx?.burst(_c, { color: 0x55555c, count: 2, speed: 0.8, size: 0.6, gravity: -1.5, life: 1.5 });
      }
      if (this._stallTime <= 0) this.respawn();
    } else {
      throttle = input.throttle;
      steer = input.steer;
    }

    // ---- turbo
    const wantBoost = !this._stalled && stats.hasTurbo && input.turbo && this._turbo > 0 && throttle > 0;
    if (wantBoost && !this.boosting) ctx.audio?.play('turbo');
    this.boosting = wantBoost;
    if (this.boosting) this._turbo = Math.max(0, this._turbo - 0.5 * dt);
    else this._turbo = Math.min(1, this._turbo + 0.18 * dt);

    // ---- longitudinal
    const heldR = this.heldBallRadius;
    let maxF = stats.maxSpeed * (1 - 0.25 * Math.min(1, heldR / maxBallR));
    let accel = stats.accel;
    if (this.boosting) {
      maxF *= 1.6;
      accel *= 2;
    }
    const maxRev = stats.maxSpeed * 0.45;
    if (throttle > 0) {
      if (this.speed < 0) this.speed += accel * 2.2 * dt;
      else if (this.speed < maxF) this.speed = Math.min(maxF, this.speed + accel * dt * (1 - 0.35 * (this.speed / maxF)));
    } else if (throttle < 0) {
      if (this.speed > 0) this.speed -= accel * 2.2 * dt;
      else if (this.speed > -maxRev) this.speed = Math.max(-maxRev, this.speed - accel * 0.7 * dt);
    } else if (!this._stalled) {
      const drag = (3 + Math.abs(this.speed) * 0.35) * dt;
      this.speed = Math.abs(this.speed) <= drag ? 0 : this.speed - Math.sign(this.speed) * drag;
    }
    // Over cap (turbo ended / ball got heavier): settle back smoothly.
    if (this.speed > maxF) this.speed = Math.max(maxF, this.speed - 10 * dt);

    // ---- steering
    const absS = Math.abs(this.speed);
    const f = 0.35 + 0.65 * Math.min(1, absS / 4);
    const reversing = this.speed < -0.2 || (absS <= 0.2 && throttle < 0);
    const turn = steer * stats.turnRate * f * (reversing ? -1 : 1);
    this.heading += turn * dt;

    // ---- integrate
    this.getForward(_fwd);
    this.position.x += _fwd.x * this.speed * dt + this.pushVel.x * dt;
    this.position.z += _fwd.z * this.speed * dt + this.pushVel.z * dt;
    const pd = Math.exp(-7 * dt);
    this.pushVel.multiplyScalar(pd);

    // Arena clamp with a bit of bounce.
    const r = this.radius;
    if (this.position.x < ARENA.minX + r) { this.position.x = ARENA.minX + r; this.pushVel.x = Math.abs(this.pushVel.x) * 0.5 + 2; this.speed *= 0.6; }
    if (this.position.x > ARENA.maxX - r) { this.position.x = ARENA.maxX - r; this.pushVel.x = -Math.abs(this.pushVel.x) * 0.5 - 2; this.speed *= 0.6; }
    if (this.position.z < ARENA.minZ + r) { this.position.z = ARENA.minZ + r; this.pushVel.z = Math.abs(this.pushVel.z) * 0.5 + 2; this.speed *= 0.6; }
    if (this.position.z > ARENA.maxZ - r) { this.position.z = ARENA.maxZ - r; this.pushVel.z = -Math.abs(this.pushVel.z) * 0.5 - 2; this.speed *= 0.6; }
    // Cabin.
    const base = ctx.base;
    if (base) {
      const dx = this.position.x - base.position.x;
      const dz = this.position.z - base.position.z;
      const minD = base.radius + r;
      const d2 = dx * dx + dz * dz;
      if (d2 < minD * minD) {
        const d = Math.sqrt(d2) || 0.001;
        const nx = dx / d;
        const nz = dz / d;
        this.position.x = base.position.x + nx * minD;
        this.position.z = base.position.z + nz * minD;
        // Kill velocity into the cabin.
        const into = (_fwd.x * nx + _fwd.z * nz) * this.speed;
        if (into < 0) this.speed *= 0.6;
        this.pushVel.x += nx * 1.5;
        this.pushVel.z += nz * 1.5;
      }
    }

    // ---- plowing
    _right.set(Math.cos(this.heading), 0, -Math.sin(this.heading));
    const bx = this.position.x + _fwd.x * BLADE_Z;
    const bz = this.position.z + _fwd.z * BLADE_Z;
    const hw = this.bladeWidth / 2;
    if (!this._stalled && this.speed > 0.5 && snow) {
      _a.set(bx - _right.x * hw, 0, bz - _right.z * hw);
      _b.set(bx + _right.x * hw, 0, bz + _right.z * hw);
      const removed = snow.plowLine(_a.x, _a.z, _b.x, _b.z, this.speed * dt + 0.35, 0.9);
      if (removed > 0) {
        const cap = ballVolume(maxBallR);
        const add = removed * stats.collectRate;
        const room = Math.max(0, cap - this.heldVolume);
        if (add > room) {
          this.heldVolume = cap;
          const excess = add - room;
          // Spill sideways off the blade ends.
          snow.addSnow(_a.x - _right.x * 0.7, _a.z - _right.z * 0.7, 0.9, excess * 0.5);
          snow.addSnow(_b.x + _right.x * 0.7, _b.z + _right.z * 0.7, 0.9, excess * 0.5);
        } else {
          this.heldVolume += add;
        }
        plowIntensity = Math.min(1, removed / dt / 8);
        if (ctx.fx && plowIntensity > 0.02) {
          _a.y = snow.getDepth(_a.x, _a.z) + 0.3;
          _b.y = snow.getDepth(_b.x, _b.z) + 0.3;
          _dir.set(-_right.x + _fwd.x * 0.5, 0.9, -_right.z + _fwd.z * 0.5).normalize();
          ctx.fx.spray(_a, _dir, plowIntensity);
          _dir.set(_right.x + _fwd.x * 0.5, 0.9, _right.z + _fwd.z * 0.5).normalize();
          ctx.fx.spray(_b, _dir, plowIntensity);
        }
      }
    }
    this.plowSmooth += (plowIntensity - this.plowSmooth) * Math.min(1, dt * 10);
    ctx.audio?.setPlowing(this.plowSmooth < 0.02 ? 0 : this.plowSmooth);

    // ---- launch
    if (!this._stalled && input.launch) {
      const lr = this.heldBallRadius;
      if (lr >= MIN_BALL_RADIUS) {
        this.ballCenter(_c, lr);
        ctx.snowballs?.launch(_c, _fwd, lr, stats.launchSpeed + Math.max(0, this.speed));
        this.heldVolume = 0;
        this.ballR = 0;
        this.speed -= 3;
        this.kick = 1;
        const frac = Math.min(1, lr / maxBallR);
        ctx.audio?.play('launch', { pitch: 1.35 - 0.65 * frac, volume: 0.6 + 0.4 * frac });
        ctx.fx?.shake(0.15 + lr * 0.15);
        ctx.fx?.burst(_c, { color: 0xffffff, count: Math.round(8 + lr * 8), speed: 4, size: 0.25, gravity: 10, life: 0.6 });
        ctx.events.emit('snowballLaunched', { radius: lr });
      } else {
        ctx.audio?.play('error');
      }
    }

    // ---- visuals
    this.updateVisuals(dt, turn, throttle);
  }

  private exhaustWorld(out: THREE.Vector3): THREE.Vector3 {
    out.copy(this.exhaustTip);
    return this.body.localToWorld(out);
  }

  private updateVisuals(dt: number, turn: number, throttle: number): void {
    const ctx = this.ctx;
    const snow = ctx.snow;
    const absS = Math.abs(this.speed);
    this.object.rotation.set(0, this.heading, 0);

    // Ride height: sink a little into the snow, bob more in deep snow.
    const depth = snow ? snow.getDepth(this.position.x, this.position.z) : 0;
    this.bobT += dt * (3 + absS * 1.4);
    const bob = Math.sin(this.bobT) * (0.015 + Math.min(0.05, depth * 0.08)) * Math.min(1, absS / 3 + 0.25);
    const targetY = Math.min(0.25, depth * 0.3);
    this.position.y += (targetY - this.position.y) * Math.min(1, dt * 6);

    // Lean into turns, pitch with acceleration, recoil kick.
    const lean = THREE.MathUtils.clamp(turn * Math.min(1, absS / 6) * 0.07, -0.12, 0.12);
    this.roll += (-lean - this.roll) * Math.min(1, dt * 6);
    const acc = (this.speed - this.lastSpeed) / Math.max(dt, 1e-4);
    this.lastSpeed = this.speed;
    const targetPitch = THREE.MathUtils.clamp(-acc * 0.004, -0.06, 0.06);
    this.pitch += (targetPitch - this.pitch) * Math.min(1, dt * 5);
    this.kick = Math.max(0, this.kick - dt * 3.5);
    const kickP = Math.sin(this.kick * Math.PI) * 0.12 * this.kick;
    this.body.rotation.set(this.pitch - kickP, 0, this.roll);
    this.body.position.set(0, bob, -kickP * 1.5);

    if (this._stalled) {
      this.body.rotation.z += Math.sin(this.time * 30) * 0.01;
    }

    // Wheels.
    const spin = (this.speed * dt) / WHEEL_R;
    for (const w of this.wheels) w.rotation.x += spin;
    // Front wheel steer.
    const st = this._stalled ? 0 : this.ctx.input.steer * 0.35;
    this.wheels[0].rotation.y = this.wheels[1].rotation.y = st;
    this.wheels[0].rotation.order = this.wheels[1].rotation.order = 'YXZ';

    // Beacon.
    const pulse = 0.5 + 0.5 * Math.sin(this.time * 9);
    this.beaconMat.emissiveIntensity = this._stalled ? 0.2 + (Math.sin(this.time * 25) > 0 ? 2 : 0) : 0.6 + pulse * 2.2;
    this.beaconLight.intensity = this._stalled ? 0 : 2 + pulse * 8;
    this.beaconSpinner.rotation.y += dt * 9;
    this.headMat.emissiveIntensity = this._stalled ? 0.1 : 1.6;

    // Damage flash + grace blink.
    this.flash = Math.max(0, this.flash - dt * 4);
    const fl = this.flash * 1.4;
    this.paintMat.emissiveIntensity = fl;
    this.bedMat.emissiveIntensity = fl;
    this.body.visible = this.grace > 0 ? Math.sin(this.time * 40) > -0.3 : true;

    // Turbo flame / exhaust puffs.
    this.flame.visible = this.boosting;
    if (this.boosting) {
      const s = 0.8 + Math.random() * 0.6;
      this.flame.scale.set(1, s, 1);
      this.flameMat.color.setHSL(0.06 + Math.random() * 0.05, 1, 0.55);
    }
    if (!this._stalled) {
      this.puffT -= dt;
      if (this.puffT <= 0) {
        this.puffT = this.boosting ? 0.05 : throttle !== 0 ? 0.18 : 0.45;
        this.exhaustWorld(_c);
        ctx.fx?.burst(_c, this.boosting
          ? { color: 0xff9a2a, count: 3, speed: 2, size: 0.22, gravity: -3, life: 0.35 }
          : { color: 0x9aa0aa, count: 1, speed: 0.6, size: 0.25 + 0.1 * Math.abs(throttle), gravity: -2, life: 0.8 });
      }
    }

    // Held ball.
    const target = this.heldBallRadius;
    this.ballR += (target - this.ballR) * Math.min(1, dt * 10);
    if (target === 0 && this.ballR < 0.15) this.ballR = 0;
    if (this.ballR >= 0.15) {
      this.ball.visible = true;
      const pr = this.ballR;
      const prevX = this.ball.position.x;
      const prevZ = this.ball.position.z;
      this.ballCenter(_c, pr);
      if (!this.ballWasVisible) {
        this.ball.position.copy(_c);
      } else {
        const dx = _c.x - prevX;
        const dz = _c.z - prevZ;
        const dist = Math.hypot(dx, dz);
        if (dist > 1e-5 && dist < 3) {
          _dir.set(dz, 0, -dx).normalize(); // up x travelDir
          _q.setFromAxisAngle(_dir, dist / pr);
          this.ball.quaternion.premultiply(_q);
        }
        this.ball.position.copy(_c);
      }
      this.ball.scale.setScalar(pr);
      this.ballWasVisible = true;

      const full = target >= ctx.stats.maxBallRadius * 0.995;
      if (full) {
        this.glow.visible = true;
        const p = 0.5 + 0.5 * Math.sin(this.time * 6);
        this.glowMat.opacity = 0.35 + 0.45 * p;
        this.glow.position.set(_c.x, _c.y - pr + 0.06, _c.z);
        this.glow.scale.setScalar(pr * (1 + 0.08 * p));
      } else {
        this.glow.visible = false;
      }
    } else {
      this.ball.visible = false;
      this.glow.visible = false;
      this.ballWasVisible = false;
    }
  }

  private ballWasVisible = false;
}
