import type { GameContext, WaveDirectorAPI, ZoneDef } from '../core/types';
import { ARENA, ENEMY_SPAWN_Z } from '../core/types';
import { ENEMIES, type EnemyType } from '../config/enemies';

interface QueuedSpawn {
  t: number;
  type: EnemyType;
}

export class WaveDirector implements WaveDirectorAPI {
  private ctx: GameContext;
  private queue: QueuedSpawn[] = [];
  private next = 0;
  private time = 0;
  private started = false;
  private hpMult = 1;
  private lastX = 0;

  constructor(ctx: GameContext) {
    this.ctx = ctx;
  }

  start(zone: ZoneDef, waveIndex: number): void {
    this.queue.length = 0;
    this.next = 0;
    this.time = 0;
    this.hpMult = zone.enemyHpMult;
    const wave = zone.waves[Math.min(waveIndex, zone.waves.length - 1)];
    if (wave) {
      for (const g of wave.groups) {
        for (let i = 0; i < g.count; i++) this.queue.push({ t: g.delay + i * g.interval, type: g.type });
      }
    }
    this.queue.sort((a, b) => a.t - b.t);
    this.started = true;
  }

  get done(): boolean {
    return this.started && this.next >= this.queue.length && this.ctx.enemies.aliveCount() === 0;
  }

  get remaining(): number {
    return this.queue.length - this.next + this.ctx.enemies.aliveCount();
  }

  clear(): void {
    this.queue.length = 0;
    this.next = 0;
    this.time = 0;
    this.started = false;
  }

  update(dt: number): void {
    if (!this.started) return;
    this.time += dt;
    while (this.next < this.queue.length && this.queue[this.next].t <= this.time) {
      const s = this.queue[this.next++];
      let x = 0;
      if (!ENEMIES[s.type].isBoss) {
        // random, but avoid stacking right on top of the previous spawn
        const lo = ARENA.minX + 4, hi = ARENA.maxX - 4;
        for (let k = 0; k < 4; k++) {
          x = lo + Math.random() * (hi - lo);
          if (Math.abs(x - this.lastX) > 6) break;
        }
        this.lastX = x;
      }
      this.ctx.enemies.spawn(s.type, x, ENEMY_SPAWN_Z, { hpMult: this.hpMult });
    }
  }
}
