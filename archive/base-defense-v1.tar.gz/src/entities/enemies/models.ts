import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { EnemyType } from '../../config/enemies';

/* Procedural enemy models. Each type is built once as a template (static parts merged per material),
 * instances are template.clone(true) (shared geometry/materials) with tintable materials cloned. */

const M = new Map<string, THREE.Material>();
function std(key: string, color: number, o: Partial<THREE.MeshStandardMaterialParameters> = {}, tint = false): THREE.MeshStandardMaterial {
  let m = M.get(key) as THREE.MeshStandardMaterial | undefined;
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0, flatShading: true, ...o });
    if (tint) m.userData.tint = true;
    M.set(key, m);
  }
  return m;
}

export const mats = {
  snow: () => std('snow', 0xf4f8ff, { roughness: 0.9 }, true),
  kingSnow: () => std('kingSnow', 0xeaf6ff, { roughness: 0.85 }, true),
  coal: () => std('coal', 0x1b1b24, { roughness: 0.5 }),
  carrot: () => std('carrot', 0xff7a1a, { roughness: 0.6 }),
  stick: () => std('stick', 0x6b3f22, { roughness: 0.9 }),
  hat: () => std('hat', 0x23232e, { roughness: 0.55 }),
  red: () => std('red', 0xe0263a, { roughness: 0.6 }),
  gold: () => std('gold', 0xffc93a, { roughness: 0.3, metalness: 0.7, emissive: 0x553300, emissiveIntensity: 0.4 }),
  gem: () => std('gem', 0x3fd0ff, { roughness: 0.2, emissive: 0x1a88ff, emissiveIntensity: 0.8 }),
  cape: () => std('cape', 0x6a1fb0, { roughness: 0.7, side: THREE.DoubleSide }),
  ermine: () => std('ermine', 0xffffff, { roughness: 1 }),
  icicle: () => std('icicle', 0xbfe9ff, { roughness: 0.2, transparent: true, opacity: 0.9 }),
  pengBlack: () => std('pengBlack', 0x1d2433, { roughness: 0.55 }, true),
  pengWhite: () => std('pengWhite', 0xffffff, { roughness: 0.7 }),
  beak: () => std('beak', 0xffa41b, { roughness: 0.5 }),
  eyeWhite: () => std('eyeWhite', 0xffffff, { roughness: 0.4 }),
  sled: () => std('sled', 0xe8283c, { roughness: 0.45 }),
  runner: () => std('runner', 0xffd23a, { roughness: 0.3, metalness: 0.5 }),
  impBody: () => std('impBody', 0xff5a1f, { roughness: 0.5, emissive: 0xff2a00, emissiveIntensity: 0.9 }, true),
  impHorn: () => std('impHorn', 0x2a1410, { roughness: 0.6 }),
  impEye: () => std('impEye', 0xfff27a, { emissive: 0xffe040, emissiveIntensity: 2 }),
  flame: () => std('flame', 0xffc23a, { emissive: 0xff8a00, emissiveIntensity: 2.2, transparent: true, opacity: 0.85, depthWrite: false }),
  ice: () => std('ice', 0x8fd3ff, { roughness: 0.12, metalness: 0.1, transparent: true, opacity: 0.82, emissive: 0x1a5a99, emissiveIntensity: 0.35 }, true),
  iceCore: () => std('iceCore', 0xc8f4ff, { emissive: 0x3fd0ff, emissiveIntensity: 1.6 }),
  purple: () => std('purple', 0x7a2a8a, { roughness: 0.45, metalness: 0.25 }, true),
  darkMetal: () => std('darkMetal', 0x2c2c38, { roughness: 0.4, metalness: 0.6 }),
  spike: () => std('spike', 0xc9ccd6, { roughness: 0.25, metalness: 0.85 }),
  tire: () => std('tire', 0x16161c, { roughness: 0.9 }),
  window: () => std('window', 0x1a0f2a, { roughness: 0.15, metalness: 0.4, emissive: 0x30104a, emissiveIntensity: 0.6 }),
  headlight: () => std('headlight', 0xff2a2a, { emissive: 0xff1010, emissiveIntensity: 2.5 }),
  fur: () => std('fur', 0xdfe8f0, { roughness: 1 }, true),
  yetiFace: () => std('yetiFace', 0x5f95d6, { roughness: 0.7 }),
  horn: () => std('horn', 0xe8dcc0, { roughness: 0.6 }),
  redEye: () => std('redEye', 0xff3030, { emissive: 0xff0000, emissiveIntensity: 1.5 }),
  tooth: () => std('tooth', 0xffffff, { roughness: 0.4 }),
  fireball: () => std('fireball', 0xffb030, { emissive: 0xff5a00, emissiveIntensity: 2.5 }),
  boulder: () => std('boulder', 0xa8e4ff, { roughness: 0.2, emissive: 0x2a6aa0, emissiveIntensity: 0.4 }),
};

// ------------------------------------------------------------------ geometry helpers
const G = new Map<string, THREE.BufferGeometry>();
function geo(key: string, f: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = G.get(key);
  if (!g) {
    g = f();
    if (g.index) g = g.toNonIndexed();
    G.set(key, g);
  }
  return g;
}
const sph = (d = 2) => geo('ico' + d, () => new THREE.IcosahedronGeometry(1, d));
const box = () => geo('box', () => new THREE.BoxGeometry(1, 1, 1));
const cyl = (seg = 10) => geo('cyl' + seg, () => new THREE.CylinderGeometry(1, 1, 1, seg));
const cone = (seg = 8) => geo('cone' + seg, () => new THREE.ConeGeometry(1, 1, seg));

const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();

/** Collects transformed primitives into per-material buckets, then merges them into a few meshes. */
class PB {
  private buckets = new Map<THREE.Material, THREE.BufferGeometry[]>();
  add(g: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, sx = 1, sy = sx, sz = sx, rx = 0, ry = 0, rz = 0): this {
    _e.set(rx, ry, rz);
    _q.setFromEuler(_e);
    return this.addQ(g, mat, x, y, z, sx, sy, sz, _q);
  }
  addQ(g: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, sx: number, sy: number, sz: number, q: THREE.Quaternion): this {
    _m.compose(_p.set(x, y, z), q, _s.set(sx, sy, sz));
    const c = g.clone();
    c.applyMatrix4(_m);
    let list = this.buckets.get(mat);
    if (!list) this.buckets.set(mat, (list = []));
    list.push(c);
    return this;
  }
  build(target: THREE.Object3D, shadow = true): THREE.Object3D {
    for (const [mat, list] of this.buckets) {
      const merged = list.length === 1 ? list[0] : mergeGeometries(list, false)!;
      if (list.length > 1) for (const g of list) g.dispose();
      merged.computeBoundingSphere();
      const mesh = new THREE.Mesh(merged, mat);
      mesh.castShadow = shadow && !(mat as THREE.MeshStandardMaterial).transparent;
      mesh.receiveShadow = false;
      target.add(mesh);
    }
    this.buckets.clear();
    return target;
  }
}

function group(name: string, parent: THREE.Object3D, x = 0, y = 0, z = 0): THREE.Group {
  const g = new THREE.Group();
  g.name = name;
  g.position.set(x, y, z);
  parent.add(g);
  return g;
}

let glowTex: THREE.Texture | null = null;
export function glowTexture(): THREE.Texture {
  if (glowTex) return glowTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.35, 'rgba(255,255,255,0.45)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  glowTex = new THREE.CanvasTexture(c);
  glowTex.colorSpace = THREE.SRGBColorSpace;
  return glowTex;
}
const SM = new Map<number, THREE.SpriteMaterial>();
export function glowMaterial(color: number): THREE.SpriteMaterial {
  let m = SM.get(color);
  if (!m) {
    m = new THREE.SpriteMaterial({ map: glowTexture(), color, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, fog: true });
    SM.set(color, m);
  }
  return m;
}

// ------------------------------------------------------------------ snowman (& king)
function buildSnowman(king: boolean): THREE.Group {
  const root = new THREE.Group();
  const body = group('body', root);
  const pb = new PB();
  const snow = king ? mats.kingSnow() : mats.snow();
  const coal = mats.coal();
  pb.add(sph(2), snow, 0, 0.55, 0, 0.66, 0.6, 0.66);
  pb.add(sph(2), snow, 0, 1.33, 0, 0.48, 0.46, 0.48);
  pb.add(sph(2), snow, 0, 1.95, 0, 0.36);
  // coal eyes (big, menacing), buttons
  pb.add(sph(1), coal, -0.13, 2.02, 0.31, 0.065);
  pb.add(sph(1), coal, 0.13, 2.02, 0.31, 0.065);
  for (let i = 0; i < 3; i++) pb.add(sph(1), coal, 0, 1.18 + i * 0.17, 0.46 - Math.abs(i - 1) * 0.02, 0.055);
  // mouth: coal pebbles in a frown
  for (let i = -2; i <= 2; i++) pb.add(sph(0), coal, i * 0.07, 1.82 + Math.abs(i) * -0.025 + 0.0, 0.32 - Math.abs(i) * 0.02, 0.03);
  // angry brows (inner ends lower)
  pb.add(box(), coal, -0.14, 2.13, 0.31, 0.18, 0.04, 0.05, 0, 0, -0.45);
  pb.add(box(), coal, 0.14, 2.13, 0.31, 0.18, 0.04, 0.05, 0, 0, 0.45);
  // carrot nose pointing +Z
  pb.add(cone(8), mats.carrot(), 0, 1.95, 0.5, 0.07, 0.34, 0.07, Math.PI / 2, 0, 0);
  if (!king) {
    // scarf
    pb.add(cyl(12), mats.red(), 0, 1.66, 0, 0.36, 0.11, 0.36);
    pb.add(box(), mats.red(), 0.18, 1.45, 0.3, 0.12, 0.34, 0.05, 0.2, 0, 0.15);
    // top hat
    pb.add(cyl(14), mats.hat(), 0, 2.27, 0, 0.42, 0.04, 0.42);
    pb.add(cyl(14), mats.hat(), 0, 2.5, 0, 0.27, 0.44, 0.27, 0, 0, 0);
    pb.add(cyl(14), mats.red(), 0, 2.34, 0, 0.275, 0.08, 0.275);
  } else {
    // icicle beard (Frostbeard)
    for (let i = 0; i < 7; i++) {
      const a = -0.9 + (i / 6) * 1.8;
      const len = 0.28 - Math.abs(a) * 0.08;
      pb.add(cone(5), mats.icicle(), Math.sin(a) * 0.27, 1.76 - len / 2, Math.cos(a) * 0.27, 0.05, len, 0.05, Math.PI, 0, 0);
    }
    // crown
    pb.add(cyl(12), mats.gold(), 0, 2.33, 0, 0.27, 0.14, 0.27);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      pb.add(cone(4), mats.gold(), Math.sin(a) * 0.24, 2.5, Math.cos(a) * 0.24, 0.06, 0.2, 0.06);
      pb.add(sph(0), mats.gem(), Math.sin(a) * 0.28, 2.33, Math.cos(a) * 0.28, 0.04);
    }
    // ermine collar
    pb.add(cyl(12), mats.ermine(), 0, 1.66, 0, 0.4, 0.12, 0.4);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      pb.add(sph(0), coal, Math.sin(a) * 0.4, 1.66, Math.cos(a) * 0.4, 0.03);
    }
  }
  pb.build(body);

  // stick arms (pivot at shoulder)
  for (const side of [-1, 1]) {
    const arm = group(side < 0 ? 'armL' : 'armR', body, side * 0.4, 1.4, 0);
    const ap = new PB();
    const st = mats.stick();
    ap.add(cyl(5), st, side * 0.38, 0.1, 0, 0.035, 0.8, 0.035, 0, 0, side * -1.2);
    ap.add(cyl(5), st, side * 0.68, 0.3, 0.02, 0.025, 0.25, 0.025, 0, 0, side * -0.4);
    ap.add(cyl(5), st, side * 0.7, 0.18, 0.02, 0.025, 0.22, 0.025, 0, 0, side * -1.9);
    if (king && side > 0) {
      // scepter
      ap.add(cyl(6), mats.gold(), 0.72, 0.15, 0.05, 0.04, 1.1, 0.04);
      ap.add(sph(1), mats.gem(), 0.72, 0.75, 0.05, 0.11);
      ap.add(cone(4), mats.gold(), 0.72, 0.9, 0.05, 0.05, 0.18, 0.05);
    }
    ap.build(arm);
  }
  if (king) {
    const cape = group('cape', body, 0, 1.75, -0.32);
    const cp = new PB();
    cp.add(box(), mats.cape(), 0, -0.75, -0.12, 1.05, 1.5, 0.05, -0.12, 0, 0);
    cp.add(box(), mats.gold(), 0, -1.5, -0.21, 1.07, 0.07, 0.07, -0.12, 0, 0);
    cp.build(cape);
    root.scale.setScalar(2.2);
  }
  return root;
}

// ------------------------------------------------------------------ penguin
function buildPenguin(): THREE.Group {
  const root = new THREE.Group();
  const sled = new PB();
  sled.add(box(), mats.sled(), 0, 0.2, 0, 0.8, 0.1, 1.3);
  sled.add(cyl(10), mats.sled(), 0, 0.33, 0.65, 0.17, 0.8, 0.17, 0, 0, Math.PI / 2);
  sled.add(box(), mats.sled(), -0.38, 0.32, -0.1, 0.06, 0.18, 1.1);
  sled.add(box(), mats.sled(), 0.38, 0.32, -0.1, 0.06, 0.18, 1.1);
  for (const s of [-1, 1]) {
    sled.add(box(), mats.runner(), s * 0.3, 0.05, 0, 0.06, 0.05, 1.4);
    sled.add(box(), mats.runner(), s * 0.3, 0.12, 0.4, 0.05, 0.15, 0.05);
    sled.add(box(), mats.runner(), s * 0.3, 0.12, -0.4, 0.05, 0.15, 0.05);
    sled.add(cyl(8), mats.runner(), s * 0.3, 0.17, 0.75, 0.08, 0.06, 0.08, 0, 0, Math.PI / 2);
  }
  sled.build(root);
  const body = group('body', root, 0, 0.25, -0.05);
  const pb = new PB();
  pb.add(sph(2), mats.pengBlack(), 0, 0.5, 0, 0.42, 0.55, 0.38);
  pb.add(sph(2), mats.pengWhite(), 0, 0.45, 0.12, 0.34, 0.45, 0.3);
  pb.add(sph(2), mats.pengBlack(), 0, 1.08, 0.02, 0.3);
  pb.add(sph(1), mats.pengWhite(), 0, 1.04, 0.16, 0.22, 0.2, 0.17);
  for (const s of [-1, 1]) {
    pb.add(sph(1), mats.eyeWhite(), s * 0.1, 1.13, 0.26, 0.07);
    pb.add(sph(1), mats.coal(), s * 0.1, 1.12, 0.32, 0.035);
    pb.add(box(), mats.coal(), s * 0.1, 1.22, 0.27, 0.13, 0.035, 0.04, 0, 0, s * 0.5);
    pb.add(sph(1), mats.beak(), s * 0.14, 0.03, 0.2, 0.12, 0.05, 0.16);
  }
  pb.add(cone(6), mats.beak(), 0, 1.03, 0.36, 0.07, 0.2, 0.06, Math.PI / 2, 0, 0);
  // little red scarf / goggles band
  pb.add(cyl(10), mats.red(), 0, 0.86, 0, 0.31, 0.07, 0.29);
  pb.build(body);
  for (const s of [-1, 1]) {
    const f = group(s < 0 ? 'armL' : 'armR', body, s * 0.38, 0.7, 0);
    new PB().add(sph(1), mats.pengBlack(), s * 0.05, -0.22, 0, 0.08, 0.3, 0.16, 0, 0, s * 0.25).build(f);
  }
  return root;
}

// ------------------------------------------------------------------ fire imp
function buildImp(): THREE.Group {
  const root = new THREE.Group();
  const body = group('body', root, 0, 0.35, 0);
  const pb = new PB();
  const b = mats.impBody();
  pb.add(sph(1), b, 0, 0.75, 0, 0.45, 0.5, 0.42);
  pb.add(sph(1), b, 0, 1.3, 0.05, 0.36);
  // legs
  pb.add(cone(5), b, -0.18, 0.25, 0, 0.12, 0.4, 0.12, Math.PI, 0, 0);
  pb.add(cone(5), b, 0.18, 0.25, 0, 0.12, 0.4, 0.12, Math.PI, 0, 0);
  // horns
  pb.add(cone(6), mats.impHorn(), -0.22, 1.6, 0.02, 0.08, 0.32, 0.08, 0, 0, 0.5);
  pb.add(cone(6), mats.impHorn(), 0.22, 1.6, 0.02, 0.08, 0.32, 0.08, 0, 0, -0.5);
  // eyes + grin
  pb.add(sph(1), mats.impEye(), -0.13, 1.36, 0.3, 0.08, 0.06, 0.05, 0, 0, -0.3);
  pb.add(sph(1), mats.impEye(), 0.13, 1.36, 0.3, 0.08, 0.06, 0.05, 0, 0, 0.3);
  pb.add(box(), mats.impHorn(), 0, 1.18, 0.33, 0.22, 0.05, 0.04);
  pb.add(box(), mats.impHorn(), -0.12, 1.21, 0.31, 0.06, 0.05, 0.04, 0, 0, 0.6);
  pb.add(box(), mats.impHorn(), 0.12, 1.21, 0.31, 0.06, 0.05, 0.04, 0, 0, -0.6);
  // pointy tail
  pb.add(cone(4), b, 0, 0.6, -0.5, 0.06, 0.45, 0.06, -1.1, 0, 0);
  pb.add(cone(4), mats.impHorn(), 0, 0.82, -0.72, 0.08, 0.14, 0.04, -0.3, 0, 0);
  pb.build(body);
  for (const s of [-1, 1]) {
    const a = group(s < 0 ? 'armL' : 'armR', body, s * 0.4, 0.95, 0);
    new PB().add(cone(5), b, s * 0.1, -0.15, 0.05, 0.08, 0.4, 0.08, 0, 0, s * 2.6).build(a);
  }
  // flames on head (each its own mesh for flicker)
  const flames = group('flames', body, 0, 1.55, -0.02);
  const fg = cone(6);
  for (let i = 0; i < 4; i++) {
    const m = new THREE.Mesh(fg, mats.flame());
    const a = (i / 4) * Math.PI * 2;
    m.position.set(Math.sin(a) * 0.13, 0.12, Math.cos(a) * 0.13);
    m.scale.set(0.12, 0.42, 0.12);
    m.name = 'flame';
    flames.add(m);
  }
  const center = new THREE.Mesh(fg, mats.flame());
  center.position.set(0, 0.2, 0);
  center.scale.set(0.16, 0.6, 0.16);
  center.name = 'flame';
  flames.add(center);
  const glow = new THREE.Sprite(glowMaterial(0xff6a1a));
  glow.scale.setScalar(3.2);
  glow.position.set(0, 0.9, 0);
  body.add(glow);
  return root;
}

// ------------------------------------------------------------------ ice golem
function buildGolem(): THREE.Group {
  const root = new THREE.Group();
  const body = group('body', root, 0, 0, 0);
  const ice = mats.ice();
  const pb = new PB();
  pb.add(box(), ice, 0, 2.0, 0, 1.9, 1.4, 1.3, 0.08, 0.1, 0.04);
  pb.add(box(), ice, 0, 1.25, 0.05, 1.4, 0.6, 1.0, 0, -0.1, 0);
  pb.add(box(), ice, 0.1, 3.0, 0.15, 0.85, 0.7, 0.8, 0.05, -0.15, 0.06);
  // shoulder crystals
  pb.add(cone(5), ice, -0.85, 2.85, -0.1, 0.25, 0.7, 0.25, 0, 0, 0.4);
  pb.add(cone(5), ice, 0.85, 2.9, -0.1, 0.22, 0.8, 0.22, 0, 0, -0.35);
  pb.add(cone(5), ice, 0, 2.9, -0.55, 0.2, 0.7, 0.2, -0.5, 0, 0);
  pb.build(body);
  const core = new PB();
  core.add(sph(1), mats.iceCore(), 0, 2.0, 0.1, 0.38);
  core.add(box(), mats.iceCore(), -0.18, 3.05, 0.56, 0.16, 0.09, 0.05);
  core.add(box(), mats.iceCore(), 0.28, 3.05, 0.53, 0.16, 0.09, 0.05);
  core.build(body, false);
  const glow = new THREE.Sprite(glowMaterial(0x3fb8ff));
  glow.scale.setScalar(2.2);
  glow.position.set(0, 2.0, 0.2);
  body.add(glow);
  for (const s of [-1, 1]) {
    const a = group(s < 0 ? 'armL' : 'armR', body, s * 1.15, 2.5, 0);
    new PB()
      .add(box(), ice, s * 0.15, -0.5, 0, 0.55, 1.0, 0.6, 0, 0, s * 0.1)
      .add(box(), ice, s * 0.22, -1.25, 0.05, 0.75, 0.65, 0.75, 0.2, 0.3, 0)
      .build(a);
    const l = group(s < 0 ? 'legL' : 'legR', root, s * 0.45, 1.0, 0);
    new PB().add(box(), ice, 0, -0.5, 0, 0.6, 1.0, 0.7).add(box(), ice, 0, -0.9, 0.12, 0.7, 0.25, 0.9).build(l);
  }
  return root;
}

// ------------------------------------------------------------------ rogue plow
function buildRival(): THREE.Group {
  const root = new THREE.Group();
  const body = group('body', root);
  const p = mats.purple();
  const pb = new PB();
  pb.add(box(), p, 0, 0.75, -0.15, 1.6, 0.55, 2.1);
  pb.add(box(), p, 0, 1.35, -0.45, 1.4, 0.75, 1.0);
  pb.add(box(), mats.window(), 0, 1.42, 0.06, 1.25, 0.45, 0.04, -0.15, 0, 0);
  pb.add(box(), mats.window(), -0.71, 1.42, -0.45, 0.03, 0.4, 0.75);
  pb.add(box(), mats.window(), 0.71, 1.42, -0.45, 0.03, 0.4, 0.75);
  pb.add(box(), mats.darkMetal(), 0, 0.42, -0.1, 1.5, 0.18, 2.2);
  // roof bar + exhaust
  pb.add(box(), mats.darkMetal(), 0, 1.78, -0.45, 1.2, 0.08, 0.2);
  pb.add(cyl(8), mats.darkMetal(), 0.6, 1.6, -1.0, 0.07, 1.0, 0.07);
  // red eyes / headlights
  pb.add(box(), mats.headlight(), -0.55, 0.85, 0.92, 0.28, 0.14, 0.05, 0, 0, -0.25);
  pb.add(box(), mats.headlight(), 0.55, 0.85, 0.92, 0.28, 0.14, 0.05, 0, 0, 0.25);
  // blade arms
  pb.add(box(), mats.darkMetal(), -0.45, 0.55, 1.05, 0.12, 0.12, 0.5);
  pb.add(box(), mats.darkMetal(), 0.45, 0.55, 1.05, 0.12, 0.12, 0.5);
  // spiked blade
  pb.add(box(), mats.darkMetal(), 0, 0.6, 1.35, 2.3, 0.75, 0.14, -0.2, 0, 0);
  pb.add(box(), mats.purple(), 0, 0.98, 1.27, 2.3, 0.08, 0.16, -0.2, 0, 0);
  for (let i = 0; i < 6; i++) {
    const x = -0.95 + i * 0.38;
    pb.add(cone(4), mats.spike(), x, 0.6, 1.62, 0.1, 0.42, 0.1, Math.PI / 2, 0, 0);
  }
  pb.build(body);
  const beacon = new THREE.Mesh(sph(1), mats.headlight());
  beacon.name = 'beacon';
  beacon.scale.setScalar(0.13);
  beacon.position.set(0, 1.9, -0.45);
  body.add(beacon);
  const wg = new PB();
  wg.add(cyl(12), mats.tire(), 0, 0, 0, 0.36, 0.3, 0.36, 0, 0, Math.PI / 2);
  wg.add(cyl(8), mats.spike(), 0, 0, 0, 0.18, 0.32, 0.18, 0, 0, Math.PI / 2);
  const wheelProto = wg.build(new THREE.Group());
  let i = 0;
  for (const z of [0.6, -0.95]) for (const s of [-1, 1]) {
    const w = wheelProto.clone(true);
    w.name = 'wheel' + i++;
    w.position.set(s * 0.82, 0.36, z);
    root.add(w);
  }
  return root;
}

// ------------------------------------------------------------------ yeti
function furShell(pb: PB, mat: THREE.Material, cx: number, cy: number, cz: number, rx: number, ry: number, rz: number, n: number, len: number, seed: number) {
  const up = new THREE.Vector3(0, 1, 0);
  const dir = new THREE.Vector3();
  const q = new THREE.Quaternion();
  let s = seed;
  const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  pb.add(sph(2), mat, cx, cy, cz, rx, ry, rz);
  for (let i = 0; i < n; i++) {
    const y = 1 - (2 * (i + 0.5)) / n;
    const r = Math.sqrt(1 - y * y);
    const phi = i * 2.399963;
    const nx = Math.cos(phi) * r, nz = Math.sin(phi) * r;
    dir.set(nx / rx, y / ry, nz / rz).normalize();
    dir.y -= 0.55;
    dir.normalize();
    q.setFromUnitVectors(up, dir);
    const l = len * (0.6 + rnd() * 0.8);
    const w = 0.1 + rnd() * 0.08;
    pb.addQ(cone(4), mat, cx + nx * rx * 0.92 + dir.x * l * 0.4, cy + y * ry * 0.92 + dir.y * l * 0.4, cz + nz * rz * 0.92 + dir.z * l * 0.4, w, l, w, q);
    if (i % 3 === 0) pb.add(sph(0), mat, cx + nx * rx, cy + y * ry, cz + nz * rz, 0.18 + rnd() * 0.12);
  }
}

function buildYeti(): THREE.Group {
  const root = new THREE.Group();
  const body = group('body', root);
  const fur = mats.fur();
  const pb = new PB();
  furShell(pb, fur, 0, 2.3, 0, 1.45, 1.6, 1.15, 160, 0.55, 7);
  pb.build(body);
  const head = group('head', body, 0, 3.85, 0.35);
  const hp = new PB();
  furShell(hp, fur, 0, 0, 0, 0.85, 0.75, 0.8, 70, 0.4, 13);
  hp.add(sph(2), mats.yetiFace(), 0, -0.05, 0.55, 0.6, 0.55, 0.35);
  for (const s of [-1, 1]) {
    hp.add(sph(1), mats.coal(), s * 0.22, 0.1, 0.84, 0.1, 0.08, 0.05);
    hp.add(sph(1), mats.redEye(), s * 0.22, 0.1, 0.88, 0.045);
    hp.add(box(), mats.coal(), s * 0.22, 0.25, 0.84, 0.28, 0.07, 0.07, 0, 0, s * 0.45);
    hp.add(cone(6), mats.horn(), s * 0.75, 0.5, 0, 0.13, 0.6, 0.13, 0, 0, s * -0.9);
    hp.add(cone(4), mats.tooth(), s * 0.18, -0.2, 0.85, 0.05, 0.16, 0.05, Math.PI, 0, 0);
  }
  hp.add(box(), mats.coal(), 0, -0.22, 0.8, 0.5, 0.12, 0.1);
  hp.add(sph(1), mats.yetiFace(), 0, 0.0, 0.92, 0.1, 0.08, 0.08);
  hp.build(head);
  for (const s of [-1, 1]) {
    const a = group(s < 0 ? 'armL' : 'armR', body, s * 1.45, 3.1, 0);
    const ap = new PB();
    furShell(ap, fur, s * 0.25, -0.9, 0.1, 0.5, 1.1, 0.5, 50, 0.35, 21 + s);
    ap.add(sph(1), mats.yetiFace(), s * 0.3, -2.0, 0.2, 0.45, 0.35, 0.45);
    for (let k = 0; k < 3; k++) ap.add(cone(4), mats.horn(), s * 0.3 + (k - 1) * 0.18, -2.25, 0.55, 0.06, 0.2, 0.06, Math.PI / 2 + 0.6, 0, 0);
    ap.build(a);
    const l = group(s < 0 ? 'legL' : 'legR', root, s * 0.6, 1.1, 0);
    const lp = new PB();
    furShell(lp, fur, 0, -0.45, 0, 0.5, 0.65, 0.5, 30, 0.3, 31 + s);
    lp.add(sph(1), mats.yetiFace(), 0, -1.0, 0.2, 0.45, 0.18, 0.6);
    lp.build(l);
  }
  return root;
}

// ------------------------------------------------------------------ templates & instancing
const templates = new Map<EnemyType, THREE.Group>();
const builders: Record<EnemyType, () => THREE.Group> = {
  snowman: () => buildSnowman(false),
  kingSnowman: () => buildSnowman(true),
  penguin: buildPenguin,
  imp: buildImp,
  golem: buildGolem,
  rival: buildRival,
  yeti: buildYeti,
};

export interface Rig {
  root: THREE.Group;
  body: THREE.Object3D;
  armL: THREE.Object3D | null;
  armR: THREE.Object3D | null;
  legL: THREE.Object3D | null;
  legR: THREE.Object3D | null;
  head: THREE.Object3D | null;
  cape: THREE.Object3D | null;
  beacon: THREE.Object3D | null;
  flames: THREE.Object3D[];
  wheels: THREE.Object3D[];
  /** Per-instance cloned materials (flash / freeze tint). */
  tintMats: THREE.MeshStandardMaterial[];
  baseScale: number;
}

export function createRig(type: EnemyType): Rig {
  let t = templates.get(type);
  if (!t) templates.set(type, (t = builders[type]()));
  const root = t.clone(true);
  const clones = new Map<THREE.Material, THREE.MeshStandardMaterial>();
  const flames: THREE.Object3D[] = [];
  const wheels: THREE.Object3D[] = [];
  root.traverse((o) => {
    if (o.name === 'flame') flames.push(o);
    if (o.name.startsWith('wheel')) wheels.push(o);
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const m = mesh.material as THREE.MeshStandardMaterial;
    if (m.userData?.tint) {
      let c = clones.get(m);
      if (!c) {
        c = m.clone();
        c.userData = { tint: true, baseEmissive: m.emissive.clone(), baseIntensity: m.emissiveIntensity };
        clones.set(m, c);
      }
      mesh.material = c;
    }
  });
  const f = (n: string) => root.getObjectByName(n) ?? null;
  return {
    root,
    body: f('body') ?? root,
    armL: f('armL'),
    armR: f('armR'),
    legL: f('legL'),
    legR: f('legR'),
    head: f('head'),
    cape: f('cape'),
    beacon: f('beacon'),
    flames,
    wheels,
    tintMats: [...clones.values()],
    baseScale: root.scale.x,
  };
}

export function disposeRig(rig: Rig): void {
  for (const m of rig.tintMats) m.dispose();
}

// projectile / misc shared geometry
export const sharedGeo = {
  sphere: () => sph(1),
  rock: () => sph(0),
  ring: () => geo('targetRing', () => new THREE.RingGeometry(0.85, 1, 32).rotateX(-Math.PI / 2)),
  disc: () => geo('targetDisc', () => new THREE.CircleGeometry(1, 32).rotateX(-Math.PI / 2)),
  barBg: () => geo('barBg', () => new THREE.PlaneGeometry(1, 1)),
  barFg: () => geo('barFg', () => new THREE.PlaneGeometry(1, 1).translate(0.5, 0, 0)),
};
