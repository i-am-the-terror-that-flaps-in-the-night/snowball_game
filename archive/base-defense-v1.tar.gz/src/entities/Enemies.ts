import * as THREE from 'three';
import type { DamageOpts, EnemyHandle, EnemyManagerAPI, GameContext } from '../core/types';
import { ARENA } from '../core/types';
import { ENEMIES, type EnemyDef, type EnemyType } from '../config/enemies';
import { createRig, disposeRig, glowMaterial, mats, sharedGeo, type Rig } from './enemies/models';

/** Per-type presentation tuning. */
const META: Record<EnemyType, { height: number; mass: number; burst: number; burst2: number }> = {
  snowman: { height: 2.95, mass: 1, burst: 0xf4f8ff, burst2: 0x222222 },
  penguin: { height: 1.75, mass: 0.6, burst: 0x1d2433, burst2: 0xffffff },
  imp: { height: 2.3, mass: 0.7, burst: 0xff6a1f, burst2: 0xffd23a },
  golem: { height: 3.9, mass: 4, burst: 0x8fd3ff, burst2: 0xd8f6ff },
  rival: { height: 2.4, mass: 2.5, burst: 0x7a2a8a, burst2: 0x2c2c38 },
  kingSnowman: { height: 6, mass: 8, burst: 0xeaf6ff, burst2: 0xffc93a },
  yeti: { height: 5, mass: 12, burst: 0xdfe8f0, burst2: 0x5f95d6 },
};

const FLASH_COLOR = new THREE.Color(0xffffff);
const FREEZE_COLOR = new THREE.Color(0x4aa8ff);
const _c = new THREE.Color();
const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _fx = new THREE.Vector3();

class Enemy implements EnemyHandle {
  readonly id: number;
  readonly type: EnemyType;
  readonly def: EnemyDef;
  readonly position = new THREE.Vector3();
  readonly radius: number;
  hp: number;
  readonly maxHp: number;
  alive = true;
  readonly isBoss: boolean;
  readonly rig: Rig;
  readonly vel = new THREE.Vector3();
  hpMult: number;
  heading = 0;
  age = 0;
  phase = Math.random() * Math.PI * 2;
  lateral: number;
  flash = 0;
  freeze = 0;
  tinted = false;
  contactCd = 0;
  ramCd = 0;
  attackT = 0;
  lunge = 0;
  dying = -1;
  special = 0;
  special2 = 0;
  enraged = false;
  // rival
  state: 'chase' | 'backoff' = 'chase';
  stateT = 0;
  drive = 0;
  moveSpeed = 0;
  bar: THREE.Group | null = null;
  barFg: THREE.Mesh | null = null;

  constructor(id: number, type: EnemyType, x: number, z: number, hpMult: number) {
    this.id = id;
    this.type = type;
    this.def = ENEMIES[type];
    this.radius = this.def.radius;
    this.maxHp = Math.max(1, Math.round(this.def.hp * hpMult));
    this.hp = this.maxHp;
    this.hpMult = hpMult;
    this.isBoss = this.def.isBoss;
    this.position.set(x, 0, z);
    this.heading = 0;
    this.lateral = (Math.random() * 2 - 1) * 3.6;
    this.rig = createRig(type);
    this.rig.root.position.copy(this.position);
    this.rig.root.scale.setScalar(0.01);
    this.special = 2 + Math.random() * 2;
    this.attackT = Math.random() * this.def.attackInterval;
  }
}

interface Projectile {
  kind: 'fireball' | 'boulder';
  mesh: THREE.Object3D;
  ring: THREE.Mesh | null;
  from: THREE.Vector3;
  to: THREE.Vector3;
  t: number;
  dur: number;
  arc: number;
  trail: number;
}

const BAR_W = 1.3;
const BAR_H = 0.14;

export class EnemyManager implements EnemyManagerAPI {
  private ctx: GameContext;
  private list: Enemy[] = [];
  private projectiles: Projectile[] = [];
  private nextId = 1;
  private barBgMat = new THREE.MeshBasicMaterial({ color: 0x1a1020, transparent: true, opacity: 0.75, depthWrite: false, fog: false });
  private barMats = {
    green: new THREE.MeshBasicMaterial({ color: 0x5ee35a, depthWrite: false, fog: false }),
    yellow: new THREE.MeshBasicMaterial({ color: 0xffd23a, depthWrite: false, fog: false }),
    red: new THREE.MeshBasicMaterial({ color: 0xff3b3b, depthWrite: false, fog: false }),
  };
  private ringMat = new THREE.MeshBasicMaterial({ color: 0xff3b3b, transparent: true, opacity: 0.8, depthWrite: false, side: THREE.DoubleSide });
  private discMat = new THREE.MeshBasicMaterial({ color: 0xff3b3b, transparent: true, opacity: 0.18, depthWrite: false });
  private camQ = new THREE.Quaternion();

  constructor(ctx: GameContext) {
    this.ctx = ctx;
  }

  get boss(): EnemyHandle | null {
    for (const e of this.list) if (e.alive && e.isBoss) return e;
    return null;
  }

  aliveCount(): number {
    let n = 0;
    for (const e of this.list) if (e.alive) n++;
    return n;
  }

  spawn(type: EnemyType, x: number, z: number, opts?: { hpMult?: number }): EnemyHandle {
    const e = new Enemy(this.nextId++, type, x, z, opts?.hpMult ?? 1);
    e.heading = Math.atan2(this.ctx.base.position.x - x, this.ctx.base.position.z - z);
    e.rig.root.rotation.y = e.heading;
    this.ctx.scene.add(e.rig.root);
    this.list.push(e);
    const fx = this.ctx.fx;
    _fx.set(x, 0.4, z);
    fx.burst(_fx, { color: 0xffffff, count: e.isBoss ? 30 : 8, speed: 3, size: 0.25, life: 0.6 });
    if (e.isBoss) {
      this.ctx.events.emit('bossSpawned', { enemy: e, name: e.def.name });
      _fx.set(x, 0.1, z);
      fx.ring(_fx, 7, META[type].burst2);
      fx.shake(0.8);
    }
    return e;
  }

  query(x: number, z: number, radius: number, out: EnemyHandle[] = []): EnemyHandle[] {
    out.length = 0;
    for (const e of this.list) {
      if (!e.alive) continue;
      const dx = e.position.x - x, dz = e.position.z - z;
      const r = radius + e.radius;
      if (dx * dx + dz * dz < r * r) out.push(e);
    }
    return out;
  }

  damage(handle: EnemyHandle, amount: number, opts?: DamageOpts): boolean {
    const e = handle as Enemy;
    if (!e.alive) return false;
    const src = opts?.source ?? 'other';
    let dmg = amount;
    if (src === 'snowball' || src === 'explosion') dmg = Math.max(1, amount - e.def.armor);
    e.hp -= dmg;
    e.flash = 0.16;
    if (opts?.knockback) {
      const m = META[e.type].mass;
      e.vel.x += opts.knockback.x / Math.sqrt(m);
      e.vel.z += opts.knockback.z / Math.sqrt(m);
    }
    if (opts?.freezeSeconds) e.freeze = Math.max(e.freeze, opts.freezeSeconds);
    this.ctx.events.emit('enemyHit', { enemy: e, damage: dmg });
    if (e.hp <= 0) {
      e.hp = 0;
      this.kill(e);
      return true;
    }
    if (!e.isBoss) this.showBar(e);
    return false;
  }

  private kill(e: Enemy): void {
    const ctx = this.ctx;
    e.alive = false;
    e.dying = 0;
    this.hideBar(e);
    ctx.audio.play('kill', { pitch: e.isBoss ? 0.6 : 0.9 + Math.random() * 0.3 });
    const meta = META[e.type];
    _fx.set(e.position.x, e.position.y + meta.height * 0.45, e.position.z);
    const big = e.isBoss ? 3 : 1;
    ctx.fx.burst(_fx, { color: meta.burst, count: 18 * big, speed: 5 * Math.sqrt(big), size: 0.35 * Math.sqrt(big), gravity: 14, life: 0.9 });
    ctx.fx.burst(_fx, { color: meta.burst2, count: 8 * big, speed: 4, size: 0.22 * Math.sqrt(big), gravity: 14, life: 0.8 });
    if (e.isBoss) {
      ctx.fx.shake(1.2);
      _fx.y = 0.1;
      ctx.fx.ring(_fx, 9, meta.burst2);
    }
    const coins = Math.round(e.def.coins * ctx.zone.coinMult);
    ctx.events.emit('enemyKilled', { enemy: e, coins });
    if (coins > 0) ctx.pickups.spawnCoins(e.position.clone(), coins);
  }

  clear(): void {
    for (const e of this.list) this.removeEnemy(e);
    this.list.length = 0;
    for (const p of this.projectiles) this.removeProjectile(p);
    this.projectiles.length = 0;
  }

  private removeEnemy(e: Enemy): void {
    this.ctx.scene.remove(e.rig.root);
    disposeRig(e.rig);
    if (e.bar) this.ctx.scene.remove(e.bar);
  }

  /* ------------------------------------------------------------------ HP bars */
  private showBar(e: Enemy): void {
    if (!e.bar) {
      const g = new THREE.Group();
      const bg = new THREE.Mesh(sharedGeo.barBg(), this.barBgMat);
      bg.scale.set(BAR_W + 0.1, BAR_H + 0.08, 1);
      bg.renderOrder = 10;
      const fg = new THREE.Mesh(sharedGeo.barFg(), this.barMats.green);
      fg.position.set(-BAR_W / 2, 0, 0.01);
      fg.scale.set(BAR_W, BAR_H, 1);
      fg.renderOrder = 11;
      g.add(bg, fg);
      e.bar = g;
      e.barFg = fg;
    }
    if (!e.bar.parent) this.ctx.scene.add(e.bar);
    const r = Math.max(0, e.hp / e.maxHp);
    e.barFg!.scale.x = Math.max(0.001, BAR_W * r);
    e.barFg!.material = r > 0.6 ? this.barMats.green : r > 0.3 ? this.barMats.yellow : this.barMats.red;
  }
  private hideBar(e: Enemy): void {
    if (e.bar?.parent) this.ctx.scene.remove(e.bar);
  }

  /* ------------------------------------------------------------------ projectiles */
  private launch(kind: Projectile['kind'], from: THREE.Vector3, to: THREE.Vector3): void {
    let mesh: THREE.Object3D;
    let ring: THREE.Mesh | null = null;
    if (kind === 'fireball') {
      const m = new THREE.Mesh(sharedGeo.sphere(), mats.fireball());
      m.scale.setScalar(0.32);
      const g = new THREE.Sprite(glowMaterial(0xff7a1a));
      g.scale.setScalar(6);
      m.add(g);
      mesh = m;
    } else {
      const m = new THREE.Mesh(sharedGeo.rock(), mats.boulder());
      m.scale.setScalar(0.85);
      m.castShadow = true;
      mesh = m;
      ring = new THREE.Mesh(sharedGeo.ring(), this.ringMat);
      const disc = new THREE.Mesh(sharedGeo.disc(), this.discMat);
      ring.add(disc);
      ring.scale.setScalar(2);
      ring.position.set(to.x, 0.06 + this.ctx.snow.getDepth(to.x, to.z), to.z);
      ring.renderOrder = 5;
      this.ctx.scene.add(ring);
    }
    mesh.position.copy(from);
    this.ctx.scene.add(mesh);
    const dist = Math.hypot(to.x - from.x, to.z - from.z);
    const dur = kind === 'fireball' ? 0.7 + dist * 0.045 : 1.3 + dist * 0.02;
    this.projectiles.push({ kind, mesh, ring, from: from.clone(), to: to.clone(), t: 0, dur, arc: kind === 'fireball' ? 2.5 + dist * 0.12 : 6 + dist * 0.15, trail: 0 });
  }

  private removeProjectile(p: Projectile): void {
    this.ctx.scene.remove(p.mesh);
    if (p.ring) this.ctx.scene.remove(p.ring);
  }

  private updateProjectiles(dt: number): void {
    const ctx = this.ctx;
    const pulse = 0.55 + 0.35 * Math.sin(ctx.time * 14);
    this.ringMat.opacity = pulse;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.t += dt;
      const k = Math.min(1, p.t / p.dur);
      const m = p.mesh;
      m.position.lerpVectors(p.from, p.to, k);
      m.position.y += p.arc * 4 * k * (1 - k);
      m.rotation.x += dt * 6;
      m.rotation.z += dt * 4;
      if (p.ring) {
        const s = 2 * (1.25 - 0.25 * k);
        p.ring.scale.setScalar(s);
      }
      p.trail -= dt;
      if (p.trail <= 0) {
        p.trail = 0.05;
        if (p.kind === 'fireball') ctx.fx.burst(m.position, { color: 0xff8a2a, count: 2, speed: 0.6, size: 0.28, gravity: -2, life: 0.4 });
        else ctx.fx.burst(m.position, { color: 0xcff2ff, count: 1, speed: 0.4, size: 0.2, gravity: 4, life: 0.4 });
      }
      if (k < 1) continue;
      // impact
      const plow = ctx.plow;
      const base = ctx.base;
      _fx.set(p.to.x, ctx.snow.getDepth(p.to.x, p.to.z) + 0.1, p.to.z);
      if (p.kind === 'fireball') {
        ctx.fx.burst(_fx, { color: 0xff6a1f, count: 14, speed: 4, size: 0.3, gravity: 6, life: 0.6 });
        ctx.fx.burst(_fx, { color: 0xffd23a, count: 6, speed: 3, size: 0.2, gravity: 6, life: 0.5 });
        ctx.snow.melt(p.to.x, p.to.z, 1.6, 0.35);
        const pr = 1.0 + plow.radius;
        if (!plow.stalled && plow.position.distanceToSquared(_v.set(p.to.x, plow.position.y, p.to.z)) < pr * pr) {
          plow.damage(10);
          ctx.fx.shake(0.25);
        }
        ctx.audio.play('hit', { volume: 0.5, pitch: 0.7 });
      } else {
        ctx.fx.ring(_fx, 2.6, 0x9fe0ff);
        ctx.fx.burst(_fx, { color: 0xa8e4ff, count: 24, speed: 6, size: 0.35, gravity: 14, life: 0.9 });
        ctx.fx.burst(_fx, { color: 0xffffff, count: 14, speed: 4, size: 0.3, gravity: 10, life: 0.8 });
        ctx.fx.shake(0.5);
        ctx.audio.play('explosion', { volume: 0.6, pitch: 1.3 });
        const pr = 2 + plow.radius;
        if (!plow.stalled && Math.hypot(plow.position.x - p.to.x, plow.position.z - p.to.z) < pr) {
          plow.damage(25);
          const dx = plow.position.x - p.to.x, dz = plow.position.z - p.to.z;
          const d = Math.hypot(dx, dz) || 1;
          plow.push((dx / d) * 6, (dz / d) * 6);
        }
        if (Math.hypot(base.position.x - p.to.x, base.position.z - p.to.z) < 2 + base.radius) base.damage(25);
        ctx.snow.addSnow(p.to.x, p.to.z, 1.6, 1.2);
      }
      this.removeProjectile(p);
      this.projectiles.splice(i, 1);
    }
  }

  /* ------------------------------------------------------------------ main update */
  update(dt: number): void {
    const ctx = this.ctx;
    const plow = ctx.plow;
    const base = ctx.base;
    const stats = ctx.stats;
    this.camQ.copy(ctx.camera.quaternion);

    for (let i = this.list.length - 1; i >= 0; i--) {
      const e = this.list[i];
      if (e.dying >= 0) {
        e.dying += dt;
        const k = e.dying / 0.26;
        const root = e.rig.root;
        const s = e.rig.baseScale * (1 + 0.45 * Math.sin(Math.min(1, k) * Math.PI * 0.6));
        root.scale.set(s, s * (1 - 0.5 * k), s);
        if (k >= 1) {
          this.removeEnemy(e);
          this.list.splice(i, 1);
        }
        continue;
      }
      this.updateEnemy(e, dt);
    }

    // separation between enemies
    const L = this.list;
    for (let i = 0; i < L.length; i++) {
      const a = L[i];
      if (!a.alive) continue;
      for (let j = i + 1; j < L.length; j++) {
        const b = L[j];
        if (!b.alive) continue;
        const dx = b.position.x - a.position.x, dz = b.position.z - a.position.z;
        const min = (a.radius + b.radius) * 0.95;
        const d2 = dx * dx + dz * dz;
        if (d2 >= min * min || d2 < 1e-6) continue;
        const d = Math.sqrt(d2);
        const push = min - d;
        const ma = META[a.type].mass, mb = META[b.type].mass;
        const wa = mb / (ma + mb), wb = ma / (ma + mb);
        const nx = dx / d, nz = dz / d;
        a.position.x -= nx * push * wa;
        a.position.z -= nz * push * wa;
        b.position.x += nx * push * wb;
        b.position.z += nz * push * wb;
      }
    }

    // contacts with plow + sync transforms
    const fast = Math.abs(plow.speed) > 0.6 * stats.maxSpeed;
    for (const e of L) {
      if (!e.alive) continue;
      if (!plow.stalled) this.plowContact(e, fast);
      if (!e.alive) continue;
      const p = e.position;
      p.x = Math.min(ARENA.maxX + 2, Math.max(ARENA.minX - 2, p.x));
      p.z = Math.min(ARENA.maxZ, Math.max(ARENA.minZ - 4, p.z));
      const r = e.rig.root;
      r.position.x = p.x;
      r.position.z = p.z;
      r.position.y = p.y;
      if (e.bar && e.bar.parent) {
        e.bar.position.set(p.x, p.y + META[e.type].height + 0.25, p.z);
        e.bar.quaternion.copy(this.camQ);
      }
    }
    void base;
    this.updateProjectiles(dt);
  }

  private plowContact(e: Enemy, fast: boolean): void {
    const ctx = this.ctx;
    const plow = ctx.plow;
    const dx = e.position.x - plow.position.x, dz = e.position.z - plow.position.z;
    const min = e.radius + plow.radius;
    const d2 = dx * dx + dz * dz;
    if (d2 >= min * min) return;
    const d = Math.sqrt(d2) || 0.001;
    const nx = dx / d, nz = dz / d;
    const spd = Math.abs(plow.speed);

    if (e.type === 'rival' && e.state === 'chase' && e.contactCd <= 0) {
      // the rival rams the player
      e.contactCd = 0.8;
      plow.damage(e.def.contactDamage);
      plow.push(-nx * 11, -nz * 11);
      const stolen = plow.stealSnow(0.5);
      _fx.set(plow.position.x, 1.2, plow.position.z);
      ctx.fx.burst(_fx, { color: 0xffffff, count: stolen > 0 ? 20 : 8, speed: 5, size: 0.3, life: 0.7 });
      if (stolen > 0.01) ctx.fx.floatText(_fx, 'SNOW STOLEN!', '#d58cff', 1);
      ctx.fx.shake(0.45);
      ctx.audio.play('hit', { pitch: 0.6 });
      e.state = 'backoff';
      e.stateT = 2;
      e.vel.x += nx * 6;
      e.vel.z += nz * 6;
    } else if (e.contactCd <= 0) {
      e.contactCd = 0.8;
      plow.damage(fast ? Math.round(e.def.contactDamage * 0.5) : e.def.contactDamage);
    }

    if (fast && e.ramCd <= 0) {
      e.ramCd = 0.45;
      _v2.set(nx, 0, nz).multiplyScalar(4 + spd * 0.7);
      ctx.fx.shake(e.isBoss ? 0.35 : 0.18);
      ctx.audio.play('hit', { pitch: 1.2 });
      _fx.set(e.position.x, e.position.y + 1, e.position.z);
      ctx.fx.burst(_fx, { color: META[e.type].burst, count: 8, speed: 4, size: 0.25, life: 0.5 });
      if (this.damage(e, 6 + 0.6 * spd, { source: 'ram', knockback: _v2 })) return;
    }

    // separate
    const push = min - d;
    const m = META[e.type].mass;
    if (m >= 3) {
      e.position.x += nx * push * 0.3;
      e.position.z += nz * push * 0.3;
      plow.push(-nx * (2 + spd * 0.5), -nz * (2 + spd * 0.5));
    } else {
      e.position.x += nx * push;
      e.position.z += nz * push;
    }
  }

  private updateEnemy(e: Enemy, dt: number): void {
    const ctx = this.ctx;
    const def = e.def;
    const base = ctx.base;
    const plow = ctx.plow;
    const rig = e.rig;
    e.age += dt;
    e.flash -= dt;
    e.contactCd -= dt;
    e.ramCd -= dt;
    e.lunge = Math.max(0, e.lunge - dt);
    const frozen = e.freeze > 0;
    if (frozen) e.freeze -= dt;
    const slow = frozen ? 0.5 : 1;
    const adt = dt * slow;

    // knockback
    e.position.x += e.vel.x * dt;
    e.position.z += e.vel.z * dt;
    const decay = Math.exp(-5 * dt);
    e.vel.x *= decay;
    e.vel.z *= decay;
    const knocked = e.vel.x * e.vel.x + e.vel.z * e.vel.z > 4;

    const depth = ctx.snow.getDepth(e.position.x, e.position.z);
    let speed = def.speed * slow;
    if (!e.isBoss && e.type !== 'imp' && e.type !== 'rival') speed *= 1 - Math.min(0.3, depth * 0.35);
    if (e.enraged) speed *= 1.5;
    if (e.age < 0.4) speed = 0;

    let vx = 0, vz = 0;
    let attacking = false;
    const plowAlive = !plow.stalled;

    if (def.behavior === 'player' && plowAlive) {
      // rival: vehicle steering
      let tx = plow.position.x, tz = plow.position.z;
      let want = def.speed * slow;
      if (e.state === 'backoff') {
        e.stateT -= dt;
        tx = e.position.x * 2 - plow.position.x;
        tz = e.position.z * 2 - plow.position.z;
        want *= 0.75;
        if (e.stateT <= 0) e.state = 'chase';
      }
      const desired = Math.atan2(tx - e.position.x, tz - e.position.z);
      e.heading = turnToward(e.heading, desired, 2.6 * slow * dt);
      e.moveSpeed += (want - e.moveSpeed) * Math.min(1, dt * 2);
      vx = Math.sin(e.heading) * e.moveSpeed;
      vz = Math.cos(e.heading) * e.moveSpeed;
    } else {
      const bx = base.position.x, bz = base.position.z;
      const dx = bx - e.position.x, dz = bz - e.position.z;
      const dist = Math.hypot(dx, dz);
      const stop = base.radius + e.radius + 0.15;
      if (dist <= stop) {
        attacking = true;
        const face = Math.atan2(dx, dz);
        e.heading = turnToward(e.heading, face, 4 * dt);
        e.attackT -= adt;
        if (e.attackT <= 0) {
          e.attackT = def.attackInterval;
          e.lunge = 0.3;
          base.damage(def.damage);
          _fx.set(e.position.x + (dx / dist) * e.radius, 1 + e.position.y, e.position.z + (dz / dist) * e.radius);
          ctx.fx.burst(_fx, { color: META[e.type].burst, count: e.isBoss ? 16 : 6, speed: 3, size: 0.22, life: 0.5 });
          if (e.isBoss) ctx.fx.shake(0.4);
        }
        if (e.type === 'rival') e.moveSpeed = 0;
      } else {
        // aim at a lateral slot in front of the cabin, converge as we get close
        const k = Math.min(1, dist / 18);
        const gx = bx + e.lateral * (0.35 + 0.65 * (1 - k)) * (e.isBoss ? 0.3 : 1);
        const gz = bz - stop * 0.6;
        let ux = gx - e.position.x, uz = gz - e.position.z;
        const ul = Math.hypot(ux, uz) || 1;
        ux /= ul;
        uz /= ul;
        vx = ux * speed;
        vz = uz * speed;
        if (e.type === 'penguin') {
          const w = Math.cos(e.age * 2.6 + e.phase) * speed * 0.75;
          vx += uz * w;
          vz += -ux * w;
        }
        if (e.type === 'rival') {
          const desired = Math.atan2(vx, vz);
          e.heading = turnToward(e.heading, desired, 2.6 * dt);
          e.moveSpeed += (def.speed * 0.6 * slow - e.moveSpeed) * Math.min(1, dt * 2);
          vx = Math.sin(e.heading) * e.moveSpeed;
          vz = Math.cos(e.heading) * e.moveSpeed;
        }
      }
    }
    if (knocked) {
      vx *= 0.2;
      vz *= 0.2;
    }
    e.position.x += vx * dt;
    e.position.z += vz * dt;
    const mv = Math.hypot(vx, vz);
    if (e.type !== 'rival' && mv > 0.1 && !attacking) e.heading = turnToward(e.heading, Math.atan2(vx, vz), 6 * dt);

    // vertical: wade into snow a bit
    if (e.type === 'imp') e.position.y = 0;
    else if (e.isBoss) e.position.y = 0;
    else e.position.y = Math.max(0, depth * 0.4 - (e.type === 'penguin' ? 0.05 : 0));

    // specials
    this.specials(e, dt, adt);

    // ---- animation
    const root = rig.root;
    root.rotation.y = e.heading;
    const pop = e.age < 0.4 ? easeOutBack(e.age / 0.4) : 1;
    let breathe = 1;
    if (e.isBoss) breathe = 1 + Math.sin(e.age * 2.2) * 0.025;
    root.scale.set(rig.baseScale * pop, rig.baseScale * pop * breathe, rig.baseScale * pop);
    const t = e.age * (frozen ? 0.4 : 1);
    const walk = attacking ? 0 : Math.min(1, mv / Math.max(0.1, def.speed));
    const lungeK = e.lunge > 0 ? Math.sin((e.lunge / 0.3) * Math.PI) : 0;
    const body = rig.body;
    switch (e.type) {
      case 'snowman':
      case 'kingSnowman': {
        const f = e.type === 'snowman' ? 7 : 4;
        body.position.y = Math.abs(Math.sin(t * f)) * 0.12 * walk;
        body.rotation.z = Math.sin(t * f) * 0.12 * walk;
        body.rotation.x = lungeK * 0.35;
        const swing = Math.sin(t * f) * 0.6 * walk;
        if (rig.armL) rig.armL.rotation.set(swing - lungeK * 1.2, 0, Math.sin(t * 2) * 0.1);
        if (rig.armR) {
          const raise = e.type === 'kingSnowman' && e.special2 > 0 ? Math.sin(Math.min(1, e.special2) * Math.PI) * 1.4 : 0;
          rig.armR.rotation.set(-swing - lungeK * 1.2, 0, -Math.sin(t * 2) * 0.1 + raise);
        }
        if (rig.cape) rig.cape.rotation.x = -0.1 - 0.15 * walk - Math.sin(t * 3) * 0.06;
        break;
      }
      case 'penguin': {
        body.rotation.z = Math.sin(t * 9 + e.phase) * 0.18;
        root.rotation.z = Math.cos(e.age * 2.6 + e.phase) * 0.18;
        body.rotation.x = -0.25 * walk + lungeK * 0.4;
        const fl = Math.sin(t * 14) * 0.5;
        if (rig.armL) rig.armL.rotation.z = -0.4 - fl;
        if (rig.armR) rig.armR.rotation.z = 0.4 + fl;
        break;
      }
      case 'imp': {
        body.position.y = 0.15 + Math.sin(t * 5 + e.phase) * 0.12;
        body.rotation.x = 0.15 * walk + lungeK * 0.5;
        for (let i = 0; i < rig.flames.length; i++) {
          const fl = rig.flames[i];
          const big = i === rig.flames.length - 1 ? 1.4 : 1;
          fl.scale.y = 0.42 * big * (0.75 + 0.35 * Math.abs(Math.sin(e.age * (17 + i * 3) + i)));
          fl.rotation.z = Math.sin(e.age * (11 + i * 2) + i) * 0.2;
        }
        const sw = Math.sin(t * 8) * 0.5 * walk;
        if (rig.armL) rig.armL.rotation.x = sw - lungeK * 1.5;
        if (rig.armR) rig.armR.rotation.x = -sw - lungeK * 1.5 - (e.special2 > 0 ? 2 * e.special2 : 0);
        break;
      }
      case 'golem': {
        const f = 3.2;
        const s = Math.sin(t * f);
        body.position.y = Math.abs(Math.cos(t * f)) * 0.12 * walk - 0.06 * walk;
        body.rotation.z = s * 0.05 * walk;
        body.rotation.x = lungeK * 0.25;
        if (rig.legL) rig.legL.rotation.x = s * 0.45 * walk;
        if (rig.legR) rig.legR.rotation.x = -s * 0.45 * walk;
        if (rig.armL) rig.armL.rotation.x = -s * 0.35 * walk - lungeK * 1.6;
        if (rig.armR) rig.armR.rotation.x = s * 0.35 * walk - lungeK * 1.6;
        break;
      }
      case 'rival': {
        const sp = e.moveSpeed * dt / 0.36;
        for (const w of rig.wheels) w.rotation.x += sp;
        body.position.y = Math.abs(Math.sin(e.age * 18)) * 0.03;
        body.rotation.x = e.state === 'backoff' ? 0.05 : -0.04 * walk;
        if (rig.beacon) rig.beacon.visible = Math.sin(e.age * 16) > 0;
        break;
      }
      case 'yeti': {
        const f = e.enraged ? 4.5 : 3;
        const s = Math.sin(t * f);
        body.position.y = Math.abs(Math.cos(t * f)) * 0.18 * walk;
        body.rotation.z = s * 0.06 * walk;
        body.rotation.x = lungeK * 0.3 + (e.enraged ? 0.1 : 0);
        if (rig.legL) rig.legL.rotation.x = s * 0.5 * walk;
        if (rig.legR) rig.legR.rotation.x = -s * 0.5 * walk;
        const throwK = e.special2 > 0 ? Math.sin(Math.min(1, e.special2 / 0.7) * Math.PI) : 0;
        if (rig.armL) rig.armL.rotation.set(-s * 0.5 * walk - lungeK * 1.8 + Math.sin(e.age * 1.5) * 0.08, 0, -0.15);
        if (rig.armR) rig.armR.rotation.set(s * 0.5 * walk - lungeK * 1.8 - throwK * 2.6, 0, 0.15);
        if (rig.head) rig.head.rotation.y = Math.sin(e.age * 0.9) * 0.25;
        break;
      }
    }

    // tint (flash / freeze)
    if (e.flash > 0 || frozen || e.tinted) {
      const fk = Math.max(0, e.flash) / 0.16;
      for (const m of rig.tintMats) {
        const ud = m.userData as { baseEmissive: THREE.Color; baseIntensity: number };
        _c.copy(ud.baseEmissive).multiplyScalar(ud.baseIntensity);
        if (frozen) _c.lerp(FREEZE_COLOR, 0.6);
        if (fk > 0) _c.lerp(FLASH_COLOR, fk);
        m.emissive.copy(_c);
        m.emissiveIntensity = 1;
      }
      e.tinted = e.flash > 0 || frozen;
      if (!e.tinted) {
        for (const m of rig.tintMats) {
          const ud = m.userData as { baseEmissive: THREE.Color; baseIntensity: number };
          m.emissive.copy(ud.baseEmissive);
          m.emissiveIntensity = ud.baseIntensity;
        }
      }
    }
  }

  private specials(e: Enemy, dt: number, adt: number): void {
    const ctx = this.ctx;
    const plow = ctx.plow;
    e.special2 = Math.max(0, e.special2 - dt);
    switch (e.type) {
      case 'imp': {
        ctx.snow.melt(e.position.x, e.position.z, 2.5, 0.6 * dt);
        e.special -= adt;
        if (e.special <= 0) {
          const dx = plow.position.x - e.position.x, dz = plow.position.z - e.position.z;
          if (!plow.stalled && dx * dx + dz * dz < 14 * 14) {
            e.special = 3;
            e.special2 = 0.35;
            _v.set(e.position.x, 1.6, e.position.z);
            // lead the target slightly (still dodgeable)
            _v2.set(plow.position.x + Math.sin(plow.heading) * plow.speed * 0.3, 0, plow.position.z + Math.cos(plow.heading) * plow.speed * 0.3);
            this.launch('fireball', _v, _v2);
            ctx.audio.play('fireball');
          } else e.special = 0.5;
        }
        break;
      }
      case 'kingSnowman': {
        e.special -= adt;
        if (e.special <= 0 && e.age > 1) {
          e.special = 8;
          e.special2 = 1;
          const px = Math.cos(e.heading), pz = -Math.sin(e.heading);
          const fx = Math.sin(e.heading), fz = Math.cos(e.heading);
          for (const s of [-1, 1]) {
            const x = e.position.x + px * s * 3.2 + fx * 1.5;
            const z = e.position.z + pz * s * 3.2 + fz * 1.5;
            this.spawn('snowman', x, z, { hpMult: e.hpMult });
          }
          _fx.set(e.position.x, 0.1, e.position.z);
          ctx.fx.ring(_fx, 5, 0xbfe9ff);
          ctx.fx.shake(0.3);
        }
        break;
      }
      case 'yeti': {
        if (!e.enraged && e.hp < e.maxHp * 0.5) {
          e.enraged = true;
          ctx.audio.play('roar');
          ctx.fx.shake(1.2);
          _fx.set(e.position.x, 0.1, e.position.z);
          ctx.fx.ring(_fx, 8, 0xff4a4a);
          ctx.fx.floatText(_v.set(e.position.x, 6, e.position.z), 'ENRAGED!', '#ff5a5a', 1.6);
        }
        e.special -= adt;
        if (e.special <= 0 && e.age > 1.5) {
          e.special = e.enraged ? 3 : 4;
          e.special2 = 0.7;
          const dx = plow.position.x - e.position.x, dz = plow.position.z - e.position.z;
          if (!plow.stalled && dx * dx + dz * dz < 30 * 30) _v2.set(plow.position.x, 0, plow.position.z);
          else {
            const b = ctx.base.position;
            _v2.set(b.x + (Math.random() - 0.5) * 2, 0, b.z - ctx.base.radius * 0.5);
          }
          const fx = Math.sin(e.heading), fz = Math.cos(e.heading);
          _v.set(e.position.x + fx * 1.2 + Math.cos(e.heading) * 1.4, 4.8, e.position.z + fz * 1.2 - Math.sin(e.heading) * 1.4);
          this.launch('boulder', _v, _v2);
          ctx.audio.play('launch', { pitch: 0.5 });
        }
        break;
      }
    }
  }
}

function turnToward(a: number, target: number, maxStep: number): number {
  let d = target - a;
  d = Math.atan2(Math.sin(d), Math.cos(d));
  if (Math.abs(d) <= maxStep) return target;
  return a + Math.sign(d) * maxStep;
}

function easeOutBack(x: number): number {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}
