import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {
  ARENA,
  BALL_DAMAGE_K,
  MIN_BALL_RADIUS,
  ballRadius,
  ballVolume,
  type EnemyHandle,
  type GameContext,
  type SnowballManagerAPI,
} from '../core/types';

/* ------------------------------------------------------------------ shared snowball look */

let sharedGeo: THREE.BufferGeometry | null = null;
let sharedMat: THREE.MeshStandardMaterial | null = null;
let sharedShardMat: THREE.MeshStandardMaterial | null = null;

function hashNoise(x: number, y: number, z: number): number {
  const s = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453;
  return s - Math.floor(s);
}

/** Unit-radius slightly lumpy snowball (smooth shaded, vertex-colored white with faint blue). */
export function getSnowballGeometry(): THREE.BufferGeometry {
  if (sharedGeo) return sharedGeo;
  let g: THREE.BufferGeometry = new THREE.IcosahedronGeometry(1, 3);
  g.deleteAttribute('uv');
  g.deleteAttribute('normal');
  g = mergeVertices(g, 1e-4);
  const pos = g.getAttribute('position') as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);
  const v = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i).normalize();
    const n =
      Math.sin(v.x * 4.1 + v.y * 2.3) * 0.5 +
      Math.sin(v.y * 5.7 - v.z * 3.1) * 0.35 +
      (hashNoise(v.x, v.y, v.z) - 0.5) * 0.5;
    const s = 1 + n * 0.045;
    pos.setXYZ(i, v.x * s, v.y * s, v.z * s);
    const b = 0.5 + 0.5 * Math.sin(v.x * 3.3 + v.z * 2.7 + v.y * 1.3);
    colors[i * 3] = 0.93 - b * 0.07;
    colors[i * 3 + 1] = 0.96 - b * 0.03;
    colors[i * 3 + 2] = 1.0;
  }
  g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  g.computeVertexNormals();
  sharedGeo = g;
  return g;
}

export function getSnowballMaterial(shard = false): THREE.MeshStandardMaterial {
  if (!shard) {
    if (!sharedMat) {
      sharedMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        vertexColors: true,
        roughness: 0.82,
        metalness: 0,
        emissive: 0x9cc6ff,
        emissiveIntensity: 0.1,
      });
    }
    return sharedMat;
  }
  if (!sharedShardMat) {
    sharedShardMat = new THREE.MeshStandardMaterial({
      color: 0xdff1ff,
      vertexColors: true,
      roughness: 0.5,
      metalness: 0.05,
      emissive: 0x6fb8ff,
      emissiveIntensity: 0.25,
    });
  }
  return sharedShardMat;
}

/* ------------------------------------------------------------------ manager */

interface Ball {
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  dir: THREE.Vector3;
  speed: number;
  volume: number;
  radius: number;
  hit: Set<number>;
  kills: number;
  shard: boolean;
  life: number;
  active: boolean;
}

interface PendingLaunch {
  pos: THREE.Vector3;
  dir: THREE.Vector3;
  radius: number;
  speed: number;
  shard: boolean;
}

const _axis = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _tmp = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);

export class SnowballManager implements SnowballManagerAPI {
  private ctx: GameContext;
  private balls: Ball[] = [];
  private pool: Ball[] = [];
  private pending: PendingLaunch[] = [];
  private queryOut: EnemyHandle[] = [];
  private aoeOut: EnemyHandle[] = [];
  private lastFreezeSound = -10;
  private group = new THREE.Group();

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    this.group.name = 'snowballs';
    ctx.scene.add(this.group);
  }

  get activeCount(): number {
    return this.balls.length;
  }

  launch(pos: THREE.Vector3, dir: THREE.Vector3, radius: number, speed: number, opts?: { shard?: boolean }): void {
    const shard = !!opts?.shard;
    let b = this.pool.pop();
    if (!b) {
      const mesh = new THREE.Mesh(getSnowballGeometry(), getSnowballMaterial(false));
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      b = {
        mesh,
        pos: new THREE.Vector3(),
        dir: new THREE.Vector3(),
        speed: 0,
        volume: 0,
        radius: 0,
        hit: new Set(),
        kills: 0,
        shard: false,
        life: 0,
        active: false,
      };
    }
    b.mesh.material = getSnowballMaterial(shard);
    b.pos.copy(pos);
    b.dir.set(dir.x, 0, dir.z);
    if (b.dir.lengthSq() < 1e-6) b.dir.set(0, 0, -1);
    b.dir.normalize();
    b.speed = speed;
    b.radius = radius;
    b.volume = ballVolume(radius);
    b.hit.clear();
    b.kills = 0;
    b.shard = shard;
    b.life = 0;
    b.active = true;
    b.mesh.visible = true;
    b.mesh.position.copy(pos);
    b.mesh.scale.setScalar(radius);
    b.mesh.quaternion.random();
    this.group.add(b.mesh);
    this.balls.push(b);
  }

  clear(): void {
    for (const b of this.balls) this.recycle(b);
    this.balls.length = 0;
    this.pending.length = 0;
  }

  private recycle(b: Ball): void {
    b.active = false;
    b.mesh.visible = false;
    this.group.remove(b.mesh);
    this.pool.push(b);
  }

  update(dt: number): void {
    const ctx = this.ctx;
    const stats = ctx.stats;
    const snow = ctx.snow;
    const enemies = ctx.enemies;
    const maxR = stats.maxBallRadius * 1.6;

    for (let i = this.balls.length - 1; i >= 0; i--) {
      const b = this.balls[i];
      b.life += dt;

      // Rolling resistance + light air drag.
      b.speed -= (2.5 + 0.012 * b.speed * b.speed) * dt;
      const ds = Math.max(0, b.speed) * dt;
      b.pos.x += b.dir.x * ds;
      b.pos.z += b.dir.z * ds;

      // Gather (or just carve) snow along the path.
      if (snow) {
        if (stats.rollingGrowth > 0) {
          const got = snow.collectDisc(b.pos.x, b.pos.z, b.radius * 0.7, 0.8);
          b.volume += got * stats.rollingGrowth * 0.6;
          const cap = ballVolume(maxR);
          if (b.volume > cap) b.volume = cap;
        } else {
          snow.collectDisc(b.pos.x, b.pos.z, b.radius * 0.7, 0.25);
        }
      }
      b.radius = ballRadius(b.volume);
      const ground = snow ? snow.getDepth(b.pos.x, b.pos.z) : 0;
      const targetY = ground + b.radius;
      b.pos.y += (targetY - b.pos.y) * Math.min(1, dt * 18);

      // Spin about axis perpendicular to travel.
      if (ds > 0 && b.radius > 0.01) {
        _axis.crossVectors(_up, b.dir).normalize();
        _q.setFromAxisAngle(_axis, ds / b.radius);
        b.mesh.quaternion.premultiply(_q);
      }
      b.mesh.position.copy(b.pos);
      b.mesh.scale.setScalar(b.radius);

      // Snow kicked up behind the rolling ball.
      if (ctx.fx && ds > 0) {
        _tmp.set(b.pos.x - b.dir.x * b.radius * 0.6, ground + 0.05, b.pos.z - b.dir.z * b.radius * 0.6);
        _axis.copy(b.dir).negate();
        ctx.fx.spray(_tmp, _axis, Math.min(0.6, 0.15 + b.speed / 40) * Math.min(1, b.radius));
      }

      // Hits.
      let burst = false;
      if (enemies) {
        const hits = enemies.query(b.pos.x, b.pos.z, b.radius, this.queryOut);
        for (let k = 0; k < hits.length; k++) {
          const e = hits[k];
          if (!e.alive || b.hit.has(e.id)) continue;
          b.hit.add(e.id);
          const speedF = THREE.MathUtils.clamp(b.speed / 12, 0.6, 1.4);
          const dmg = BALL_DAMAGE_K * b.radius * b.radius * stats.damageMult * speedF;
          const knock = new THREE.Vector3(b.dir.x * b.speed * 0.6, 0, b.dir.z * b.speed * 0.6);
          const killed = enemies.damage(e, dmg, {
            knockback: knock,
            freezeSeconds: stats.frostCore ? 3 : 0,
            source: 'snowball',
          });
          if (ctx.fx) {
            _tmp.set(e.position.x, e.position.y + e.radius + 1.2, e.position.z);
            ctx.fx.floatText(_tmp, `${Math.round(dmg)}`, stats.frostCore ? '#9fe6ff' : killed ? '#fff3a0' : '#ffffff', 0.8 + Math.min(0.8, b.radius * 0.35));
            _tmp.set(
              (b.pos.x + e.position.x) * 0.5,
              b.pos.y,
              (b.pos.z + e.position.z) * 0.5,
            );
            ctx.fx.burst(_tmp, {
              color: stats.frostCore ? 0xbfeaff : 0xffffff,
              count: 8 + Math.round(b.radius * 6),
              speed: 4 + b.speed * 0.2,
              size: 0.18 + b.radius * 0.1,
              gravity: 14,
              life: 0.7,
            });
          }
          ctx.audio?.play('hit', { pitch: THREE.MathUtils.clamp(1.3 - b.radius * 0.3, 0.6, 1.4), volume: Math.min(1, 0.5 + b.radius * 0.3) });
          if (stats.frostCore && ctx.time - this.lastFreezeSound > 0.4) {
            this.lastFreezeSound = ctx.time;
            ctx.audio?.play('freeze', { volume: 0.6 });
          }
          if (killed) {
            b.kills++;
            b.volume *= 0.85;
            b.speed *= 0.93;
            b.radius = ballRadius(b.volume);
          } else {
            burst = true;
            break;
          }
        }
      }

      if (
        !burst &&
        (b.speed < 1.5 ||
          b.life > 8 ||
          b.radius < MIN_BALL_RADIUS * 0.6 ||
          b.pos.x < ARENA.minX - 1 ||
          b.pos.x > ARENA.maxX + 1 ||
          b.pos.z < ARENA.minZ - 1 ||
          b.pos.z > ARENA.maxZ + 1)
      ) {
        burst = true;
      }

      if (burst) {
        this.burst(b);
        this.balls.splice(i, 1);
        this.recycle(b);
      }
    }

    if (this.pending.length) {
      const list = this.pending;
      this.pending = [];
      for (const p of list) this.launch(p.pos, p.dir, p.radius, p.speed, { shard: p.shard });
    }
  }

  private burst(b: Ball): void {
    const ctx = this.ctx;
    const stats = ctx.stats;
    const r = b.radius;
    const pos = b.pos.clone();

    ctx.fx?.burst(pos, {
      color: 0xffffff,
      count: Math.round(12 + r * 16),
      speed: 3 + r * 3,
      size: 0.22 + r * 0.18,
      gravity: 12,
      life: 1.0,
    });
    ctx.fx?.burst(pos, { color: 0xcfe6ff, count: Math.round(6 + r * 6), speed: 2 + r * 2, size: 0.12 + r * 0.1, gravity: 6, life: 1.3 });
    ctx.audio?.play('burst', { volume: Math.min(1, 0.4 + r * 0.35), pitch: THREE.MathUtils.clamp(1.25 - r * 0.25, 0.6, 1.3) });
    ctx.snow?.addSnow(pos.x, pos.z, r * 1.5, b.volume * 0.4);

    if (b.kills >= 3) ctx.events.emit('strike', { count: b.kills, position: pos.clone() });
    ctx.events.emit('snowballBurst', { position: pos, radius: r });

    if (stats.explosiveCore && ctx.enemies) {
      const aoeR = 2.5 + 1.5 * r;
      const dmg = 0.6 * BALL_DAMAGE_K * r * r * stats.damageMult;
      const hits = ctx.enemies.query(pos.x, pos.z, aoeR, this.aoeOut);
      // Copy since damage() may mutate enemy lists.
      const targets = hits.slice();
      for (const e of targets) {
        if (!e.alive) continue;
        const dx = e.position.x - pos.x;
        const dz = e.position.z - pos.z;
        const d = Math.hypot(dx, dz) || 1;
        const k = 8 + r * 3;
        ctx.enemies.damage(e, dmg, { knockback: new THREE.Vector3((dx / d) * k, 0, (dz / d) * k), source: 'explosion' });
      }
      ctx.fx?.ring(pos, aoeR, 0xff8a3d);
      ctx.fx?.burst(pos, { color: 0xffa040, count: Math.round(14 + r * 10), speed: 6 + r * 3, size: 0.3 + r * 0.1, gravity: 4, life: 0.8 });
      ctx.fx?.shake(0.3 + 0.2 * r);
      ctx.audio?.play('explosion', { volume: Math.min(1, 0.6 + r * 0.2) });
    }

    if (stats.shatterShot && !b.shard && r >= 0.8) {
      const sr = r * 0.55;
      const sp = Math.max(8, b.speed * 0.8);
      const baseAng = Math.atan2(b.dir.x, b.dir.z);
      for (const off of [-25, 0, 25]) {
        const a = baseAng + THREE.MathUtils.degToRad(off);
        const d = new THREE.Vector3(Math.sin(a), 0, Math.cos(a));
        const p = pos.clone().addScaledVector(d, r * 0.6);
        p.y = (ctx.snow ? ctx.snow.getDepth(p.x, p.z) : 0) + sr;
        this.pending.push({ pos: p, dir: d, radius: sr, speed: sp, shard: true });
      }
    }
  }
}
