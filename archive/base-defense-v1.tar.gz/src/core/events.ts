import type * as THREE from 'three';
import type { EnemyHandle } from './types';

/** Cross-cutting game events. Modules call ctx.audio / ctx.fx directly for their own feedback;
 *  events exist so Game/UI can track stats and show toasts without modules knowing about each other. */
export interface GameEvents {
  enemyKilled: { enemy: EnemyHandle; coins: number };
  enemyHit: { enemy: EnemyHandle; damage: number };
  snowballLaunched: { radius: number };
  snowballBurst: { position: THREE.Vector3; radius: number };
  /** One snowball killed `count` (>= 3) enemies. */
  strike: { count: number; position: THREE.Vector3 };
  plowDamaged: { amount: number };
  plowStalled: { seconds: number };
  baseDamaged: { amount: number };
  coinCollected: { amount: number };
  bossSpawned: { enemy: EnemyHandle; name: string };
  waveStarted: { wave: number; total: number };
}

type Handler<T> = (payload: T) => void;

export class EventBus {
  private handlers = new Map<keyof GameEvents, Set<Handler<any>>>();

  on<K extends keyof GameEvents>(type: K, fn: Handler<GameEvents[K]>): () => void {
    let set = this.handlers.get(type);
    if (!set) {
      set = new Set();
      this.handlers.set(type, set);
    }
    set.add(fn);
    return () => set!.delete(fn);
  }

  emit<K extends keyof GameEvents>(type: K, payload: GameEvents[K]): void {
    const set = this.handlers.get(type);
    if (!set) return;
    for (const fn of set) fn(payload);
  }
}
