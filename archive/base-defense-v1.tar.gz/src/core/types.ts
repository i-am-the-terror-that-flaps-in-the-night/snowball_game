import type * as THREE from 'three';
import type { EventBus } from './events';
import type { Input } from './input';
import type { ZoneDef } from '../config/zones';
import type { EnemyType } from '../config/enemies';
import type { UpgradeId } from '../config/upgrades';
import type { Progression } from './Progression';

/* ------------------------------------------------------------------------------------------------
 * WORLD LAYOUT & CONVENTIONS (every module relies on these)
 *  - Y is up. Ground is flat at y = 0. Snow sits on top: surface height = snow.getDepth(x, z).
 *  - Heading: yaw in radians. forward = (sin(heading), 0, cos(heading)).
 *    Setting object.rotation.y = heading makes the object's local +Z axis point forward,
 *    so BUILD ALL VEHICLE / CREATURE MODELS FACING LOCAL +Z.
 *  - The plow starts at PLOW_SPAWN facing north (-Z), i.e. heading = Math.PI.
 *  - Enemies spawn along the north edge (z = ENEMY_SPAWN_Z, x in [ARENA.minX, ARENA.maxX]) and travel
 *    south toward the cabin at BASE_POSITION.
 *  - Units are meters / seconds.
 * ---------------------------------------------------------------------------------------------- */

export const ARENA = { minX: -38, maxX: 38, minZ: -50, maxZ: 46 } as const;
/** The snow field mesh covers [-SNOW_FIELD_SIZE/2, SNOW_FIELD_SIZE/2] on both X and Z. */
export const SNOW_FIELD_SIZE = 104;
export const BASE_POSITION = { x: 0, z: 40 } as const;
export const BASE_RADIUS = 4.5;
export const PLOW_SPAWN = { x: 0, z: 25, heading: Math.PI } as const;
export const ENEMY_SPAWN_Z = -48;

/** Volume (m^3) <-> radius (m) of a snowball. */
export const ballVolume = (r: number) => (4 / 3) * Math.PI * r * r * r;
export const ballRadius = (v: number) => Math.cbrt((3 * Math.max(0, v)) / (4 * Math.PI));
/** Smallest snowball worth launching / keeping alive. */
export const MIN_BALL_RADIUS = 0.35;
/** Snowball hit damage before enemy armor: BALL_DAMAGE_K * r^2 * stats.damageMult * clamp(speed / 12, 0.6, 1.4). */
export const BALL_DAMAGE_K = 32;

/** Fully computed player stats (from upgrades). See Progression.computeStats. */
export interface PlayerStats {
  maxSpeed: number;
  accel: number;
  turnRate: number;
  /** Blade width in meters. */
  bladeWidth: number;
  /** Fraction of plowed snow volume that ends up in the snowball. */
  collectRate: number;
  maxBallRadius: number;
  launchSpeed: number;
  damageMult: number;
  /** 0..1 — fraction of snow a *launched* rolling ball picks up from the ground it rolls over. */
  rollingGrowth: number;
  maxHp: number;
  baseMaxHp: number;
  /** Fraction of cabin max HP repaired between waves. */
  baseRepair: number;
  /** Snow depth regenerated per second (m/s) before zone multiplier. */
  snowRegen: number;
  magnetRadius: number;
  hasTurbo: boolean;
  frostCore: boolean;
  shatterShot: boolean;
  explosiveCore: boolean;
}

/* ------------------------------------------------------------------ world */

export interface SnowFieldAPI {
  /** Edge length of the square field (SNOW_FIELD_SIZE). */
  readonly size: number;
  /** Snow depth (m) at a world position; 0 outside the field. */
  getDepth(x: number, z: number): number;
  /** Remove snow under a line segment (the plow blade) of the given thickness. `fraction` (0..1) of the
   *  depth is removed in cells touched. Returns the removed volume in m^3. */
  plowLine(x1: number, z1: number, x2: number, z2: number, thickness: number, fraction: number): number;
  /** Remove snow in a disc (rolling snowball). Returns removed volume in m^3. */
  collectDisc(x: number, z: number, radius: number, fraction: number): number;
  /** Deposit `volume` m^3 of snow spread over a disc (burst snowballs, plow side-spill). */
  addSnow(x: number, z: number, radius: number, volume: number): void;
  /** Melt snow in a disc: removes up to `amount` m of depth at the center, falling off to 0 at the edge. */
  melt(x: number, z: number, radius: number, amount: number): void;
  /** Remaining snow volume as a fraction of the zone's initial volume (0..1+). */
  totalSnowFraction(): number;
  /** Refill to the zone's initial depth (with gentle natural variation) and apply zone tint. */
  reset(zone: ZoneDef): void;
  /** Regenerates snow at ctx.stats.snowRegen * ctx.zone.snowRegenMult per second (capped at ~1.6x the
   *  zone's initial depth) and pushes changed heights to the GPU. */
  update(dt: number): void;
}

export interface WorldAPI {
  /** Apply sky gradient, fog, lights and themed decoration (trees, rocks, fences, mountains) for the zone. */
  setZone(zone: ZoneDef): void;
  /** Falling snow particles, subtle ambient animation. */
  update(dt: number): void;
}

export interface BaseAPI {
  readonly object: THREE.Object3D;
  readonly position: THREE.Vector3;
  readonly radius: number;
  hp: number;
  maxHp: number;
  /** Apply damage (clamped at 0). Emits 'baseDamaged', plays 'baseHit', flashes / shakes the model. */
  damage(amount: number): void;
  repair(amount: number): void;
  /** Set maxHp and refill. */
  reset(maxHp: number): void;
  update(dt: number): void;
}

/* ------------------------------------------------------------------ player */

export interface PlowAPI {
  readonly object: THREE.Object3D;
  readonly position: THREE.Vector3;
  heading: number;
  /** Signed forward speed, m/s. */
  speed: number;
  /** Collision radius, m. */
  readonly radius: number;
  hp: number;
  maxHp: number;
  /** True while knocked out (hp hit 0): uncontrollable for 3s, then respawns at PLOW_SPAWN with full hp. */
  readonly stalled: boolean;
  readonly stallTimeLeft: number;
  /** Radius of the snowball currently being pushed by the blade (0 = none). */
  readonly heldBallRadius: number;
  /** 0..1 turbo charge (meaningful only if stats.hasTurbo). */
  readonly turboCharge: number;
  /** World-space position of the front of the blade (where the held ball sits). */
  getBladeTip(out: THREE.Vector3): THREE.Vector3;
  getForward(out: THREE.Vector3): THREE.Vector3;
  /** Apply damage (ignored while stalled). Emits 'plowDamaged' (and 'plowStalled' on knock-out). */
  damage(amount: number): void;
  /** Remove `fraction` of the held ball's volume; returns the stolen volume. */
  stealSnow(fraction: number): number;
  /** External impulse (m/s) on the plow, e.g. enemy rams. Decays quickly. */
  push(vx: number, vz: number): void;
  /** Back to PLOW_SPAWN, full hp, no ball, zero speed. */
  reset(): void;
  /** Re-read stats (max hp, blade width visual, etc.). Keeps hp ratio. */
  applyStats(stats: PlayerStats): void;
  /** Reads ctx.input: drive, plow snow into the held ball, launch on Space via ctx.snowballs.launch. */
  update(dt: number): void;
}

export interface SnowballManagerAPI {
  /** Spawn a rolling snowball. `dir` is a horizontal unit vector. */
  launch(pos: THREE.Vector3, dir: THREE.Vector3, radius: number, speed: number, opts?: { shard?: boolean }): void;
  readonly activeCount: number;
  clear(): void;
  update(dt: number): void;
}

/* ------------------------------------------------------------------ enemies */

export interface EnemyHandle {
  readonly id: number;
  readonly type: EnemyType;
  readonly position: THREE.Vector3;
  readonly radius: number;
  hp: number;
  readonly maxHp: number;
  readonly alive: boolean;
  readonly isBoss: boolean;
}

export interface DamageOpts {
  /** Knockback velocity (m/s, horizontal). */
  knockback?: THREE.Vector3;
  freezeSeconds?: number;
  source?: 'snowball' | 'explosion' | 'ram' | 'other';
}

export interface EnemyManagerAPI {
  spawn(type: EnemyType, x: number, z: number, opts?: { hpMult?: number }): EnemyHandle;
  /** Living enemies whose collision circle overlaps the given circle. Reuses `out` if provided. */
  query(x: number, z: number, radius: number, out?: EnemyHandle[]): EnemyHandle[];
  /** Callers pass RAW damage; the manager subtracts the enemy's armor (min 1 damage) for sources
   *  'snowball' and 'explosion'. Returns true if this killed the enemy.
   *  On kill: emits 'enemyKilled', spawns coins (ctx.pickups.spawnCoins), plays fx/audio. */
  damage(enemy: EnemyHandle, amount: number, opts?: DamageOpts): boolean;
  aliveCount(): number;
  /** The first living boss, if any (for the HUD boss bar). */
  readonly boss: EnemyHandle | null;
  clear(): void;
  update(dt: number): void;
}

export interface WaveDirectorAPI {
  /** Begin spawning ctx.zone.waves[waveIndex]. Enemy hp is scaled by zone.enemyHpMult. */
  start(zone: ZoneDef, waveIndex: number): void;
  /** True once every enemy of the wave has spawned and none are alive. */
  readonly done: boolean;
  /** Enemies still to spawn + alive. */
  readonly remaining: number;
  clear(): void;
  update(dt: number): void;
}

/* ------------------------------------------------------------------ fx / audio / pickups / camera */

export interface PickupsAPI {
  /** Spawn coin pickups worth `amount` total near pos (split into a few coins). Collected coins call
   *  ctx.progression.addCoins and emit 'coinCollected'. Coins within stats.magnetRadius fly to the plow. */
  spawnCoins(pos: THREE.Vector3, amount: number): void;
  /** Instantly collect all remaining coins (end of wave). Returns the amount collected. */
  collectAll(): number;
  clear(): void;
  update(dt: number): void;
}

export interface FxAPI {
  burst(pos: THREE.Vector3, opts?: { color?: number; count?: number; speed?: number; size?: number; gravity?: number; life?: number }): void;
  /** Snow kicked up by the blade. `intensity` 0..1. Call every frame while plowing. */
  spray(pos: THREE.Vector3, dir: THREE.Vector3, intensity: number): void;
  /** Floating damage numbers / labels projected to screen. */
  floatText(pos: THREE.Vector3, text: string, color?: string, size?: number): void;
  /** Ring shockwave on the ground (explosions, boss stomps). */
  ring(pos: THREE.Vector3, radius: number, color?: number): void;
  /** Camera shake, intensity ~0.1 (tiny) .. 1.5 (huge). Delegates to ctx.cameraRig. */
  shake(intensity: number): void;
  clear(): void;
  update(dt: number): void;
}

export interface CameraRigAPI {
  /** 'follow' chases the plow (behind & above, looking ahead). 'menu' slowly orbits the arena. */
  setMode(mode: 'follow' | 'menu'): void;
  /** Jump to the target pose immediately (after reset/respawn). */
  snap(): void;
  addShake(intensity: number): void;
  update(dt: number): void;
}

export type SoundName =
  | 'launch' | 'hit' | 'kill' | 'strike' | 'coin' | 'baseHit' | 'plowHit' | 'burst' | 'explosion'
  | 'waveStart' | 'waveClear' | 'buy' | 'click' | 'error' | 'boss' | 'roar' | 'gameOver' | 'victory'
  | 'stall' | 'turbo' | 'freeze' | 'fireball' | 'countdown';

export interface AudioAPI {
  /** Resume/create the AudioContext; call from a user gesture. Safe to call repeatedly. */
  unlock(): void;
  play(name: SoundName, opts?: { volume?: number; pitch?: number }): void;
  /** Continuous engine hum: throttle -1..1, speedFrac 0..1. */
  setEngine(throttle: number, speedFrac: number): void;
  /** Continuous crunch/whoosh while plowing snow, intensity 0..1 (0 = silent). */
  setPlowing(intensity: number): void;
  /** Gentle procedural background music / wind. */
  setMusic(on: boolean): void;
  muted: boolean;
}

/* ------------------------------------------------------------------ UI */

export interface HudState {
  zoneName: string;
  wave: number; // 1-based
  totalWaves: number;
  enemiesRemaining: number;
  baseHp: number;
  baseMaxHp: number;
  plowHp: number;
  plowMaxHp: number;
  ballRadius: number;
  ballMaxRadius: number;
  coins: number;
  /** -1 when turbo is not owned. */
  turboCharge: number;
  stalledSeconds: number;
  snowFraction: number;
  boss: { name: string; hp: number; maxHp: number } | null;
  /** Seconds left in the pre-wave countdown, or 0. */
  countdown: number;
}

export interface RunSummary {
  zoneName: string;
  wavesCleared: number;
  totalWaves: number;
  coinsEarned: number;
  kills: number;
  strikes: number;
  biggestBall: number;
  firstClear: boolean;
  clearReward: number;
  unlockedZoneName: string | null;
}

export interface UIHandlers {
  onStartZone(zoneIndex: number): void;
  onResume(): void;
  onQuitToMenu(): void;
  onRetry(): void;
  onResetSave(): void;
  onToggleMute(): void;
}

export interface UIAPI {
  showMainMenu(): void;
  showZoneSelect(): void;
  /** Upgrade garage reachable from the main menu. */
  showGarage(): void;
  /** Between-wave upgrade shop. `nextWave` is 1-based. Calls onContinue when the player is ready. */
  showShop(nextWave: number, totalWaves: number, onContinue: () => void): void;
  showPause(): void;
  showGameOver(summary: RunSummary): void;
  showVictory(summary: RunSummary): void;
  hideOverlays(): void;
  setHudVisible(visible: boolean): void;
  updateHud(state: HudState): void;
  toast(text: string, kind?: 'info' | 'good' | 'bad' | 'big'): void;
  /** True if any blocking overlay (menu/shop/pause/...) is open. */
  readonly overlayOpen: boolean;
}

/* ------------------------------------------------------------------ context */

/** Shared context handed to every system's constructor.
 *  IMPORTANT: in constructors only touch renderer/scene/camera/events/input/progression/stats/zone —
 *  other systems may not be constructed yet. Access them lazily (inside methods / update). */
export interface GameContext {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  events: EventBus;
  input: Input;
  progression: Progression;
  /** Current computed stats; replaced (new object) when upgrades change. */
  stats: PlayerStats;
  zone: ZoneDef;
  world: WorldAPI;
  snow: SnowFieldAPI;
  base: BaseAPI;
  plow: PlowAPI;
  snowballs: SnowballManagerAPI;
  enemies: EnemyManagerAPI;
  waves: WaveDirectorAPI;
  pickups: PickupsAPI;
  fx: FxAPI;
  cameraRig: CameraRigAPI;
  audio: AudioAPI;
  ui: UIAPI;
  /** Seconds of game time elapsed (pauses with the game). */
  time: number;
}

export type { UpgradeId, EnemyType, ZoneDef };
