import * as THREE from 'three';
import { EventBus } from './events';
import { Input } from './input';
import { Progression } from './Progression';
import type { GameContext, HudState, RunSummary, UIHandlers } from './types';
import { ZONES } from '../config/zones';
import { ENEMIES } from '../config/enemies';
import { SnowField } from '../world/SnowField';
import { Environment } from '../world/Environment';
import { Base } from '../world/Base';
import { Plow } from '../entities/Plow';
import { SnowballManager } from '../entities/Snowballs';
import { EnemyManager } from '../entities/Enemies';
import { WaveDirector } from '../entities/Waves';
import { Pickups } from '../fx/Pickups';
import { Fx } from '../fx/Fx';
import { CameraRig } from '../fx/CameraRig';
import { AudioSystem } from '../audio/Audio';
import { UI } from '../ui/UI';

type State = 'menu' | 'countdown' | 'playing' | 'shop' | 'paused' | 'gameover' | 'victory';

const COUNTDOWN_SECONDS = 4;

export class Game {
  readonly ctx: GameContext;
  private renderer: THREE.WebGLRenderer;
  private lastT = performance.now();
  private state: State = 'menu';
  private pausedFrom: State = 'playing';
  private zoneIndex = 0;
  private waveIndex = 0;
  private countdown = 0;
  private lastCountdownInt = -1;
  private run = { kills: 0, strikes: 0, coins: 0, biggestBall: 0 };
  private hud: HudState;

  constructor(container: HTMLElement, uiRoot: HTMLElement) {
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    container.appendChild(renderer.domElement);
    this.renderer = renderer;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 500);
    const progression = new Progression();
    if (new URLSearchParams(location.search).has('debug')) progression.debugGrant();

    // Systems are constructed in order; constructors may only touch the "core" fields below.
    const ctx = {
      renderer,
      scene,
      camera,
      events: new EventBus(),
      input: new Input(),
      progression,
      stats: progression.computeStats(),
      zone: ZONES[0],
      time: 0,
    } as GameContext;
    this.ctx = ctx;

    ctx.audio = new AudioSystem();
    ctx.audio.muted = progression.data.muted;
    ctx.cameraRig = new CameraRig(ctx);
    ctx.fx = new Fx(ctx);
    ctx.world = new Environment(ctx);
    ctx.snow = new SnowField(ctx);
    ctx.base = new Base(ctx);
    ctx.plow = new Plow(ctx);
    ctx.snowballs = new SnowballManager(ctx);
    ctx.enemies = new EnemyManager(ctx);
    ctx.waves = new WaveDirector(ctx);
    ctx.pickups = new Pickups(ctx);

    const handlers: UIHandlers = {
      onStartZone: (i) => this.startRun(i),
      onResume: () => this.resume(),
      onQuitToMenu: () => this.toMenu(),
      onRetry: () => this.startRun(this.zoneIndex),
      onResetSave: () => {
        progression.resetSave();
        this.refreshStats();
      },
      onToggleMute: () => this.toggleMute(),
    };
    ctx.ui = new UI(ctx, uiRoot, handlers);

    this.hud = this.blankHud();
    this.wireEvents();

    // Menu backdrop: zone 0 scenery.
    ctx.world.setZone(ctx.zone);
    ctx.snow.reset(ctx.zone);
    ctx.base.reset(ctx.stats.baseMaxHp);
    ctx.plow.applyStats(ctx.stats);
    ctx.plow.reset();

    window.addEventListener('resize', () => this.onResize());
    const unlock = () => ctx.audio.unlock();
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Escape' || e.code === 'KeyP') this.togglePause();
      if (e.code === 'KeyM') this.toggleMute();
    });

    // Handy for automated playtesting / debugging in the console.
    (window as unknown as { __game: Game }).__game = this;

    this.toMenu();
    renderer.setAnimationLoop(() => this.frame());
  }

  /* ------------------------------------------------------------------ flow */

  private toMenu(): void {
    const { ctx } = this;
    this.state = 'menu';
    ctx.enemies.clear();
    ctx.snowballs.clear();
    ctx.pickups.clear();
    ctx.waves.clear();
    ctx.ui.setHudVisible(false);
    ctx.ui.showMainMenu();
    ctx.cameraRig.setMode('menu');
    ctx.audio.setEngine(0, 0);
    ctx.audio.setPlowing(0);
    ctx.audio.setMusic(true);
  }

  startRun(zoneIndex: number): void {
    const { ctx } = this;
    if (!ctx.progression.isZoneUnlocked(zoneIndex)) return;
    this.zoneIndex = zoneIndex;
    this.waveIndex = 0;
    this.run = { kills: 0, strikes: 0, coins: 0, biggestBall: 0 };
    ctx.zone = ZONES[zoneIndex];
    this.refreshStats();
    ctx.enemies.clear();
    ctx.snowballs.clear();
    ctx.pickups.clear();
    ctx.waves.clear();
    ctx.fx.clear();
    ctx.world.setZone(ctx.zone);
    ctx.snow.reset(ctx.zone);
    ctx.base.reset(ctx.stats.baseMaxHp);
    ctx.plow.reset();
    ctx.ui.hideOverlays();
    ctx.ui.setHudVisible(true);
    ctx.ui.toast(ctx.zone.name, 'big');
    ctx.cameraRig.setMode('follow');
    ctx.cameraRig.snap();
    this.beginCountdown();
  }

  private beginCountdown(): void {
    this.state = 'countdown';
    this.countdown = COUNTDOWN_SECONDS;
    this.lastCountdownInt = -1;
    this.ctx.ui.toast(`Wave ${this.waveIndex + 1} incoming — plow some snow!`, 'info');
  }

  private startWave(): void {
    const { ctx } = this;
    this.state = 'playing';
    ctx.waves.start(ctx.zone, this.waveIndex);
    ctx.events.emit('waveStarted', { wave: this.waveIndex + 1, total: ctx.zone.waves.length });
    ctx.audio.play('waveStart');
    ctx.ui.toast(`WAVE ${this.waveIndex + 1}`, 'big');
  }

  private waveCleared(): void {
    const { ctx } = this;
    ctx.pickups.collectAll();
    const bonus = Math.round((15 + 10 * this.waveIndex) * ctx.zone.coinMult);
    ctx.progression.addCoins(bonus);
    this.run.coins += bonus;
    ctx.snowballs.clear();
    ctx.audio.play('waveClear');
    const isLast = this.waveIndex >= ctx.zone.waves.length - 1;
    if (isLast) {
      this.victory();
      return;
    }
    // The shop header already announces the clear; a toast here would overlap it.
    this.state = 'shop';
    ctx.audio.setEngine(0, 0);
    ctx.audio.setPlowing(0);
    ctx.ui.showShop(this.waveIndex + 2, ctx.zone.waves.length, () => {
      this.refreshStats();
      ctx.base.maxHp = Math.max(ctx.base.maxHp, ctx.stats.baseMaxHp);
      ctx.base.repair(ctx.stats.baseRepair * ctx.base.maxHp);
      ctx.plow.hp = ctx.plow.maxHp;
      ctx.ui.hideOverlays();
      this.waveIndex++;
      this.beginCountdown();
    });
  }

  private victory(): void {
    const { ctx } = this;
    this.state = 'victory';
    const firstClear = ctx.progression.recordRun(this.zoneIndex, ctx.zone.waves.length, true, this.run.kills);
    const reward = firstClear ? ctx.zone.clearReward : Math.round(ctx.zone.clearReward * 0.4);
    ctx.progression.addCoins(reward);
    this.run.coins += reward;
    const next = ZONES[this.zoneIndex + 1];
    const summary: RunSummary = {
      ...this.summaryBase(ctx.zone.waves.length),
      firstClear,
      clearReward: reward,
      unlockedZoneName: firstClear && next ? next.name : null,
    };
    ctx.audio.setEngine(0, 0);
    ctx.audio.setPlowing(0);
    ctx.audio.play('victory');
    ctx.ui.setHudVisible(false);
    ctx.ui.showVictory(summary);
  }

  private gameOver(): void {
    const { ctx } = this;
    this.state = 'gameover';
    ctx.progression.recordRun(this.zoneIndex, this.waveIndex, false, this.run.kills);
    ctx.audio.setEngine(0, 0);
    ctx.audio.setPlowing(0);
    ctx.audio.play('gameOver');
    ctx.fx.shake(1.2);
    ctx.ui.setHudVisible(false);
    ctx.ui.showGameOver({ ...this.summaryBase(this.waveIndex), firstClear: false, clearReward: 0, unlockedZoneName: null });
  }

  private summaryBase(wavesCleared: number) {
    return {
      zoneName: this.ctx.zone.name,
      wavesCleared,
      totalWaves: this.ctx.zone.waves.length,
      coinsEarned: this.run.coins,
      kills: this.run.kills,
      strikes: this.run.strikes,
      biggestBall: this.run.biggestBall,
    };
  }

  private togglePause(): void {
    if (this.state === 'playing' || this.state === 'countdown') {
      this.pausedFrom = this.state;
      this.state = 'paused';
      this.ctx.audio.setEngine(0, 0);
      this.ctx.audio.setPlowing(0);
      this.ctx.ui.showPause();
    } else if (this.state === 'paused') {
      this.resume();
    }
  }

  private resume(): void {
    if (this.state !== 'paused') return;
    this.state = this.pausedFrom;
    this.ctx.ui.hideOverlays();
    this.ctx.input.clear();
  }

  private toggleMute(): void {
    const a = this.ctx.audio;
    a.muted = !a.muted;
    this.ctx.progression.setMuted(a.muted);
    this.ctx.ui.toast(a.muted ? 'Sound off' : 'Sound on', 'info');
  }

  private refreshStats(): void {
    const { ctx } = this;
    ctx.stats = ctx.progression.computeStats();
    ctx.plow.applyStats(ctx.stats);
  }

  private wireEvents(): void {
    const { events, ui } = this.ctx;
    events.on('enemyKilled', () => this.run.kills++);
    events.on('coinCollected', ({ amount }) => (this.run.coins += amount));
    events.on('snowballLaunched', ({ radius }) => (this.run.biggestBall = Math.max(this.run.biggestBall, radius)));
    events.on('strike', ({ count }) => {
      this.run.strikes++;
      const bonus = Math.round(count * 4 * this.ctx.zone.coinMult);
      this.ctx.progression.addCoins(bonus);
      this.run.coins += bonus;
      ui.toast(count >= 5 ? `AVALANCHE! ${count} in one ball! +${bonus}` : `STRIKE! x${count} +${bonus}`, 'big');
    });
    events.on('bossSpawned', ({ name }) => {
      ui.toast(`⚠ BOSS: ${name}`, 'bad');
      this.ctx.audio.play('boss');
    });
    events.on('plowStalled', ({ seconds }) => ui.toast(`Plow stalled! Rebooting in ${seconds}s`, 'bad'));
  }

  /* ------------------------------------------------------------------ loop */

  private frame(): void {
    const nowT = performance.now();
    const dt = Math.min((nowT - this.lastT) / 1000, 0.05);
    this.lastT = nowT;
    this.tick(dt);
    this.renderer.render(this.ctx.scene, this.ctx.camera);
  }

  /** Advance the simulation by dt seconds without rendering (also used by headless playtests). */
  tick(dt: number): void {
    const { ctx, state } = this;
    const active = state === 'playing' || state === 'countdown';

    if (active) {
      ctx.time += dt;
      ctx.plow.update(dt);
      ctx.snow.update(dt);
      ctx.snowballs.update(dt);
      if (state === 'playing') ctx.waves.update(dt);
      ctx.enemies.update(dt);
      ctx.base.update(dt);
      ctx.pickups.update(dt);

      if (ctx.base.hp <= 0) {
        this.gameOver();
      } else if (state === 'countdown') {
        this.countdown -= dt;
        const n = Math.ceil(this.countdown);
        if (n !== this.lastCountdownInt && n > 0 && n <= 3) ctx.audio.play('countdown');
        this.lastCountdownInt = n;
        if (this.countdown <= 0) this.startWave();
      } else if (ctx.waves.done) {
        this.waveCleared();
      }

      const speedFrac = Math.min(1, Math.abs(ctx.plow.speed) / ctx.stats.maxSpeed);
      ctx.audio.setEngine(ctx.plow.stalled ? 0 : ctx.input.throttle, speedFrac);
      this.updateHud();
    }

    ctx.fx.update(dt);
    ctx.world.update(dt);
    ctx.cameraRig.update(dt);
    ctx.input.endFrame();
  }

  private blankHud(): HudState {
    return {
      zoneName: '', wave: 1, totalWaves: 1, enemiesRemaining: 0, baseHp: 1, baseMaxHp: 1, plowHp: 1, plowMaxHp: 1,
      ballRadius: 0, ballMaxRadius: 1, coins: 0, turboCharge: -1, stalledSeconds: 0, snowFraction: 1, boss: null, countdown: 0,
    };
  }

  private updateHud(): void {
    const { ctx, hud } = this;
    hud.zoneName = ctx.zone.name;
    hud.wave = this.waveIndex + 1;
    hud.totalWaves = ctx.zone.waves.length;
    hud.enemiesRemaining = this.state === 'countdown' ? 0 : ctx.waves.remaining;
    hud.baseHp = ctx.base.hp;
    hud.baseMaxHp = ctx.base.maxHp;
    hud.plowHp = ctx.plow.hp;
    hud.plowMaxHp = ctx.plow.maxHp;
    hud.ballRadius = ctx.plow.heldBallRadius;
    hud.ballMaxRadius = ctx.stats.maxBallRadius;
    hud.coins = ctx.progression.coins;
    hud.turboCharge = ctx.stats.hasTurbo ? ctx.plow.turboCharge : -1;
    hud.stalledSeconds = ctx.plow.stalled ? ctx.plow.stallTimeLeft : 0;
    hud.snowFraction = ctx.snow.totalSnowFraction();
    const boss = ctx.enemies.boss;
    hud.boss = boss ? { name: ENEMIES[boss.type].name, hp: boss.hp, maxHp: boss.maxHp } : null;
    hud.countdown = this.state === 'countdown' ? Math.max(0, this.countdown) : 0;
    this.run.biggestBall = Math.max(this.run.biggestBall, hud.ballRadius);
    ctx.ui.updateHud(hud);
  }

  private onResize(): void {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.ctx.camera.aspect = w / h;
    this.ctx.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }
}
