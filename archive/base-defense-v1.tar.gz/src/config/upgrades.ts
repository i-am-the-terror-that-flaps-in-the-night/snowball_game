export type UpgradeId =
  | 'engine'
  | 'blade'
  | 'compactor'
  | 'hopper'
  | 'cannon'
  | 'packedIce'
  | 'rolling'
  | 'armor'
  | 'cabin'
  | 'snowMachine'
  | 'magnet'
  | 'turbo'
  | 'frostCore'
  | 'shatterShot'
  | 'explosiveCore';

export type UpgradeCategory = 'plow' | 'ball' | 'defense' | 'special';

export interface UpgradeDef {
  id: UpgradeId;
  name: string;
  icon: string;
  category: UpgradeCategory;
  description: string;
  maxLevel: number;
  baseCost: number;
  costGrowth: number;
  /** Short human-readable value at a given level, e.g. "12.2 m/s". */
  valueLabel: (level: number) => string;
}

export const UPGRADES: UpgradeDef[] = [
  { id: 'engine', name: 'V8 Engine', icon: '⚙️', category: 'plow', description: 'Top speed, acceleration and steering.', maxLevel: 5, baseCost: 40, costGrowth: 1.7, valueLabel: (l) => `${(9 + 1.6 * l).toFixed(1)} m/s` },
  { id: 'blade', name: 'Wide Blade', icon: '🔪', category: 'plow', description: 'A wider blade scoops a wider strip of snow.', maxLevel: 5, baseCost: 45, costGrowth: 1.7, valueLabel: (l) => `${(2.6 + 0.45 * l).toFixed(2)} m wide` },
  { id: 'compactor', name: 'Snow Compactor', icon: '🧊', category: 'ball', description: 'Packs more of the plowed snow into your snowball.', maxLevel: 5, baseCost: 50, costGrowth: 1.75, valueLabel: (l) => `${Math.round((0.09 + 0.03 * l) * 100)}% packing` },
  { id: 'hopper', name: 'Mega Hopper', icon: '⚪', category: 'ball', description: 'Raises the maximum snowball size.', maxLevel: 5, baseCost: 60, costGrowth: 1.8, valueLabel: (l) => `max ${(1.2 + 0.36 * l).toFixed(2)} m radius` },
  { id: 'cannon', name: 'Launch Cannon', icon: '💥', category: 'ball', description: 'Fires snowballs faster and farther.', maxLevel: 5, baseCost: 45, costGrowth: 1.7, valueLabel: (l) => `${18 + 4 * l} m/s launch` },
  { id: 'packedIce', name: 'Packed Ice', icon: '💎', category: 'ball', description: 'Snowballs hit much harder.', maxLevel: 5, baseCost: 70, costGrowth: 1.8, valueLabel: (l) => `x${(1 + 0.25 * l).toFixed(2)} damage` },
  { id: 'rolling', name: 'Rolling Growth', icon: '🌀', category: 'ball', description: 'Launched snowballs keep gathering snow as they roll.', maxLevel: 3, baseCost: 120, costGrowth: 2, valueLabel: (l) => `${[0, 30, 60, 100][l]}% pickup` },
  { id: 'armor', name: 'Armor Plating', icon: '🛡️', category: 'defense', description: 'More plow hit points.', maxLevel: 5, baseCost: 40, costGrowth: 1.65, valueLabel: (l) => `${100 + 30 * l} HP` },
  { id: 'cabin', name: 'Cabin Walls', icon: '🏠', category: 'defense', description: 'Tougher cocoa cabin, and more repair between waves.', maxLevel: 5, baseCost: 50, costGrowth: 1.7, valueLabel: (l) => `${300 + 100 * l} HP, ${Math.round((0.25 + 0.1 * l) * 100)}% repair` },
  { id: 'snowMachine', name: 'Snow Machine', icon: '🌨️', category: 'defense', description: 'Snow falls back onto plowed ground faster.', maxLevel: 3, baseCost: 90, costGrowth: 1.9, valueLabel: (l) => `x${(1 + l).toFixed(0)} snowfall` },
  { id: 'magnet', name: 'Coin Magnet', icon: '🧲', category: 'defense', description: 'Grab coins from farther away.', maxLevel: 3, baseCost: 35, costGrowth: 1.8, valueLabel: (l) => `${4 + 3 * l} m reach` },
  { id: 'turbo', name: 'Turbo Boost', icon: '🔥', category: 'special', description: 'Hold SHIFT for a burst of speed. Recharges.', maxLevel: 1, baseCost: 220, costGrowth: 1, valueLabel: (l) => (l ? 'Installed' : 'Locked') },
  { id: 'frostCore', name: 'Frost Core', icon: '❄️', category: 'special', description: 'Snowball hits freeze enemies, slowing them for 3s.', maxLevel: 1, baseCost: 280, costGrowth: 1, valueLabel: (l) => (l ? 'Installed' : 'Locked') },
  { id: 'shatterShot', name: 'Shatter Shot', icon: '✴️', category: 'special', description: 'Big snowballs burst into 3 smaller snowballs.', maxLevel: 1, baseCost: 380, costGrowth: 1, valueLabel: (l) => (l ? 'Installed' : 'Locked') },
  { id: 'explosiveCore', name: 'Avalanche Core', icon: '🌋', category: 'special', description: 'Snowballs explode on burst, damaging everything nearby.', maxLevel: 1, baseCost: 450, costGrowth: 1, valueLabel: (l) => (l ? 'Installed' : 'Locked') },
];

export const UPGRADE_BY_ID: Record<UpgradeId, UpgradeDef> = Object.fromEntries(UPGRADES.map((u) => [u.id, u])) as Record<UpgradeId, UpgradeDef>;

export function upgradeCost(def: UpgradeDef, currentLevel: number): number {
  return Math.round(def.baseCost * Math.pow(def.costGrowth, currentLevel));
}
