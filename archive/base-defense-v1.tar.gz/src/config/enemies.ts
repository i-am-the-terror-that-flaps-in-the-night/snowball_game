export type EnemyType = 'snowman' | 'penguin' | 'imp' | 'golem' | 'rival' | 'kingSnowman' | 'yeti';

export interface EnemyDef {
  type: EnemyType;
  name: string;
  hp: number;
  /** Walking speed, m/s. */
  speed: number;
  /** Collision radius, m. */
  radius: number;
  /** Damage per attack against the cabin (or plow for 'player' behavior). */
  damage: number;
  /** Seconds between attacks. */
  attackInterval: number;
  /** Damage dealt to the plow on contact (per contact, with ~0.8s cooldown per enemy). */
  contactDamage: number;
  /** Flat damage reduction per snowball hit. Rewards big snowballs. */
  armor: number;
  coins: number;
  /** 'base' walks to the cabin and attacks it; 'player' hunts the plow. */
  behavior: 'base' | 'player';
  isBoss: boolean;
  /** Main body color (hex). */
  color: number;
  /** Notes for the implementer on special behavior. */
  special: string;
}

export const ENEMIES: Record<EnemyType, EnemyDef> = {
  snowman: { type: 'snowman', name: 'Evil Snowman', hp: 30, speed: 2.2, radius: 0.9, damage: 8, attackInterval: 1.2, contactDamage: 6, armor: 0, coins: 5, behavior: 'base', isBoss: false, color: 0xf4f8ff, special: 'Basic grunt. Coal eyes, carrot nose, stick arms, angry eyebrows.' },
  penguin: { type: 'penguin', name: 'Sled Penguin', hp: 12, speed: 5, radius: 0.55, damage: 4, attackInterval: 0.8, contactDamage: 4, armor: 0, coins: 3, behavior: 'base', isBoss: false, color: 0x1d2433, special: 'Fast, weaves side to side (sine wobble) as it slides on its belly / sled.' },
  imp: { type: 'imp', name: 'Fire Imp', hp: 26, speed: 3, radius: 0.6, damage: 10, attackInterval: 1.0, contactDamage: 8, armor: 0, coins: 7, behavior: 'base', isBoss: false, color: 0xff5a1f, special: 'Melts snow in a 2.5m radius around itself (ctx.snow.melt) every frame, leaving a bare trail. Every 3s, if plow within 14m, lobs a fireball at the plow (10 dmg, dodgeable). Glows (emissive + small point light optional).' },
  golem: { type: 'golem', name: 'Ice Golem', hp: 160, speed: 1.4, radius: 1.5, damage: 25, attackInterval: 2.0, contactDamage: 18, armor: 12, coins: 20, behavior: 'base', isBoss: false, color: 0x8fd3ff, special: 'Slow armored tank of translucent ice blocks. Armor means tiny snowballs barely scratch it.' },
  rival: { type: 'rival', name: 'Rogue Plow', hp: 60, speed: 7, radius: 1.2, damage: 15, attackInterval: 1.5, contactDamage: 15, armor: 4, coins: 12, behavior: 'player', isBoss: false, color: 0x7a2a8a, special: 'Evil purple plow truck. Chases the player plow, rams it (contactDamage + knockback via plow.push) and steals 50% of the held snowball (plow.stealSnow(0.5)). Backs off for 2s after a ram.' },
  kingSnowman: { type: 'kingSnowman', name: 'King Frostbeard', hp: 450, speed: 1.6, radius: 2.0, damage: 35, attackInterval: 2.0, contactDamage: 25, armor: 5, coins: 80, behavior: 'base', isBoss: true, color: 0xeaf6ff, special: 'Giant crowned snowman boss. Every 8s summons 2 snowmen next to itself.' },
  yeti: { type: 'yeti', name: 'The Abominable', hp: 1200, speed: 1.8, radius: 2.4, damage: 40, attackInterval: 2.5, contactDamage: 30, armor: 8, coins: 150, behavior: 'base', isBoss: true, color: 0xdfe8f0, special: 'Shaggy yeti boss. Every 4s throws an ice boulder (arcing projectile, 25 dmg, 2m splash) at the plow if within 30m, else at the cabin. Below 50% HP: speed x1.5 and roars (camera shake).' },
};
