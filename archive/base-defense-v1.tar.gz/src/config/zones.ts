import type { EnemyType } from './enemies';

export interface SpawnGroup {
  type: EnemyType;
  count: number;
  /** Seconds after wave start before the first spawn of this group. */
  delay: number;
  /** Seconds between spawns within the group. */
  interval: number;
}

export interface WaveDef {
  groups: SpawnGroup[];
}

export interface ZoneDef {
  index: number;
  id: string;
  name: string;
  tagline: string;
  waves: WaveDef[];
  enemyHpMult: number;
  coinMult: number;
  /** Initial snow depth (m) on the field. */
  snowDepth: number;
  /** Multiplier on snow regeneration. */
  snowRegenMult: number;
  /** Coins for first clear (repeat clears pay 40%). */
  clearReward: number;
  // --- visuals ---
  skyTop: number;
  skyBottom: number;
  fogColor: number;
  fogNear: number;
  fogFar: number;
  sunColor: number;
  sunIntensity: number;
  ambientColor: number;
  ambientIntensity: number;
  snowTint: number;
  /** Falling snow particle density, 0..1. */
  snowfall: number;
  /** Decoration theme for Environment. */
  theme: 'meadow' | 'pines' | 'lake' | 'blizzard' | 'peak';
}

const g = (type: EnemyType, count: number, delay = 0, interval = 2.5): SpawnGroup => ({ type, count, delay, interval });

export const ZONES: ZoneDef[] = [
  {
    index: 0, id: 'meadow', name: 'Frosty Meadow', tagline: 'Gentle hills. Grumpy snowmen.',
    waves: [
      { groups: [g('snowman', 5, 0, 3)] },
      { groups: [g('snowman', 6, 0, 2.5), g('penguin', 4, 6, 1.5)] },
      { groups: [g('penguin', 8, 0, 1.2), g('snowman', 6, 4, 2)] },
      { groups: [g('snowman', 10, 0, 1.6), g('penguin', 8, 8, 1)] },
      { groups: [g('kingSnowman', 1, 2, 1), g('snowman', 6, 0, 3), g('penguin', 6, 10, 1.5)] },
    ],
    enemyHpMult: 1, coinMult: 1, snowDepth: 0.5, snowRegenMult: 1, clearReward: 150,
    skyTop: 0x4f8fd6, skyBottom: 0xdcefff, fogColor: 0xd6e9fb, fogNear: 60, fogFar: 170,
    sunColor: 0xfff1d6, sunIntensity: 2.6, ambientColor: 0xbcd7ff, ambientIntensity: 0.9, snowTint: 0xffffff, snowfall: 0.25, theme: 'meadow',
  },
  {
    index: 1, id: 'pines', name: 'Pine Ridge', tagline: 'Fire imps are melting the forest floor.',
    waves: [
      { groups: [g('snowman', 6, 0, 2), g('imp', 2, 6, 4)] },
      { groups: [g('imp', 4, 0, 3), g('penguin', 8, 3, 1)] },
      { groups: [g('snowman', 10, 0, 1.4), g('imp', 4, 5, 3)] },
      { groups: [g('imp', 6, 0, 2), g('penguin', 10, 2, 0.8), g('snowman', 6, 10, 2)] },
      { groups: [g('snowman', 12, 0, 1.2), g('imp', 6, 4, 2.2), g('penguin', 8, 12, 0.8)] },
      { groups: [g('yeti', 1, 2, 1), g('imp', 4, 8, 3), g('snowman', 8, 0, 2.5)] },
    ],
    enemyHpMult: 1.25, coinMult: 1.2, snowDepth: 0.55, snowRegenMult: 1, clearReward: 300,
    skyTop: 0x2f5d8a, skyBottom: 0xf3d7b6, fogColor: 0xd9c9b8, fogNear: 45, fogFar: 150,
    sunColor: 0xffc890, sunIntensity: 2.2, ambientColor: 0xc9b9ff, ambientIntensity: 0.8, snowTint: 0xfff6ee, snowfall: 0.35, theme: 'pines',
  },
  {
    index: 2, id: 'lake', name: 'Frozen Lake', tagline: 'Thin snow, thick ice golems, rogue plows.',
    waves: [
      { groups: [g('golem', 2, 0, 6), g('snowman', 6, 2, 2)] },
      { groups: [g('rival', 2, 0, 5), g('penguin', 10, 2, 0.8)] },
      { groups: [g('golem', 3, 0, 5), g('imp', 4, 3, 3), g('snowman', 8, 6, 1.5)] },
      { groups: [g('rival', 3, 0, 4), g('golem', 3, 5, 5), g('penguin', 10, 8, 0.7)] },
      { groups: [g('snowman', 14, 0, 1), g('golem', 4, 4, 4), g('imp', 4, 10, 3)] },
      { groups: [g('kingSnowman', 2, 2, 12), g('rival', 3, 6, 5), g('golem', 2, 12, 6)] },
    ],
    enemyHpMult: 1.55, coinMult: 1.4, snowDepth: 0.42, snowRegenMult: 0.8, clearReward: 500,
    skyTop: 0x6aa6c9, skyBottom: 0xe9f6ff, fogColor: 0xcfe6f2, fogNear: 55, fogFar: 160,
    sunColor: 0xeaf6ff, sunIntensity: 2.4, ambientColor: 0xa9dcff, ambientIntensity: 1.0, snowTint: 0xeef9ff, snowfall: 0.15, theme: 'lake',
  },
  {
    index: 3, id: 'blizzard', name: 'Blizzard Pass', tagline: 'Whiteout. Endless snow. Endless enemies.',
    waves: [
      { groups: [g('snowman', 12, 0, 1.2), g('penguin', 10, 4, 0.8)] },
      { groups: [g('rival', 3, 0, 3), g('imp', 6, 2, 2)] },
      { groups: [g('golem', 4, 0, 4), g('snowman', 12, 2, 1), g('penguin', 10, 10, 0.6)] },
      { groups: [g('imp', 8, 0, 1.5), g('rival', 4, 6, 3), g('golem', 3, 10, 4)] },
      { groups: [g('snowman', 16, 0, 0.8), g('penguin', 14, 4, 0.5), g('golem', 4, 8, 4)] },
      { groups: [g('rival', 5, 0, 3), g('imp', 8, 3, 1.5), g('golem', 4, 10, 4)] },
      { groups: [g('yeti', 1, 2, 1), g('kingSnowman', 1, 20, 1), g('snowman', 10, 0, 2), g('rival', 3, 12, 5)] },
    ],
    enemyHpMult: 1.9, coinMult: 1.6, snowDepth: 0.7, snowRegenMult: 2.2, clearReward: 750,
    skyTop: 0x8a99a8, skyBottom: 0xdfe5ea, fogColor: 0xe2e8ee, fogNear: 18, fogFar: 85,
    sunColor: 0xdfe8ff, sunIntensity: 1.4, ambientColor: 0xd5dde8, ambientIntensity: 1.3, snowTint: 0xf4f7fa, snowfall: 1.0, theme: 'blizzard',
  },
  {
    index: 4, id: 'peak', name: 'Yeti Peak', tagline: 'Home of the Abominable. Bring your biggest snowball.',
    waves: [
      { groups: [g('golem', 4, 0, 3), g('snowman', 14, 2, 0.8)] },
      { groups: [g('rival', 5, 0, 2.5), g('penguin', 16, 2, 0.5)] },
      { groups: [g('imp', 10, 0, 1.2), g('golem', 5, 6, 3)] },
      { groups: [g('kingSnowman', 1, 0, 1), g('rival', 4, 4, 3), g('snowman', 14, 6, 0.8)] },
      { groups: [g('golem', 6, 0, 2.5), g('imp', 8, 4, 1.5), g('penguin', 16, 8, 0.5)] },
      { groups: [g('yeti', 1, 0, 1), g('golem', 4, 6, 4), g('rival', 4, 10, 3)] },
      { groups: [g('snowman', 20, 0, 0.6), g('imp', 10, 4, 1.2), g('rival', 5, 8, 2.5), g('golem', 5, 12, 3)] },
      { groups: [g('yeti', 2, 2, 25), g('kingSnowman', 1, 12, 1), g('golem', 4, 6, 5), g('imp', 6, 14, 2)] },
    ],
    enemyHpMult: 2.3, coinMult: 1.8, snowDepth: 0.6, snowRegenMult: 1.3, clearReward: 1200,
    skyTop: 0x1b2347, skyBottom: 0xb46a8c, fogColor: 0x8a6f8f, fogNear: 40, fogFar: 140,
    sunColor: 0xffa7a0, sunIntensity: 1.9, ambientColor: 0x8f8fd8, ambientIntensity: 0.9, snowTint: 0xf6ecff, snowfall: 0.5, theme: 'peak',
  },
];
